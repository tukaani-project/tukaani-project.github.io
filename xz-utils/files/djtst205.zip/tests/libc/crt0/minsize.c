#include <crt0.h>

void   __crt0_load_environment_file(char *_app_name){}
void   __crt0_setup_arguments(void){}

int
main(void)
{
  return 0;
}
