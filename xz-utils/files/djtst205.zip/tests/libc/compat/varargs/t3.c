#include <varargs.h>
#include <stdio.h>

int
main(void)
{
  return 0;
}
