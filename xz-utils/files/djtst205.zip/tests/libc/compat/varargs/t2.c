#include <stdio.h>
#include <varargs.h>

int
main(void)
{
  return 0;
}
