int
main(void)
{
  *(int *)(-1) = 0;
  return 0;
}
