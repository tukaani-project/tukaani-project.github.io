/* -*-C-*- msinh.c */

#include "elefunt.h"

int
main()
{
    init();
    tsinh();
    return (EXIT_SUCCESS);
}
