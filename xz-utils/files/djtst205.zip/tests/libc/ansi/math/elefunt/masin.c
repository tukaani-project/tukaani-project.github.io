/* -*-C-*- masin.c */

#include "elefunt.h"

int
main()
{
    init();
    tasin();
    return (EXIT_SUCCESS);
}
