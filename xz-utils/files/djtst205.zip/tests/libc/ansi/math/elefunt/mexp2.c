/* -*-C-*- mexp.c */

#include "elefunt.h"

int
main()
{
    init();
    texp2();
    return (EXIT_SUCCESS);
}
