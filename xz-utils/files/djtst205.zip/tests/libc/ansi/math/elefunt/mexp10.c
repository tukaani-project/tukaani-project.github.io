/* -*-C-*- mexp.c */

#include "elefunt.h"

int
main()
{
    init();
    texp10();
    return (EXIT_SUCCESS);
}
