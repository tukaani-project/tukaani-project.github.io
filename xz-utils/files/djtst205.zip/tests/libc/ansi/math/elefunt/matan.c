/* -*-C-*- matan.c */

#include "elefunt.h"

int
main()
{
    init();
    tatan();
    return (EXIT_SUCCESS);
}
