This directory contains tests from original nmalloc package
adapted for DJGPP testsuite

Andris Pavenis <andris.pavenis@iki.fi>
