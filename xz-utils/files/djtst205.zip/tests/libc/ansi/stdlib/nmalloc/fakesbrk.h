void *fakesbrk(int delta);
