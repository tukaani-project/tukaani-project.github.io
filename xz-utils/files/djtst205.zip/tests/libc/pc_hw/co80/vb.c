#include <stdlib.h>
#include <pc.h>

int
main(int argc, char **argv)
{
  ScreenVisualBell();
  return 0;
}
