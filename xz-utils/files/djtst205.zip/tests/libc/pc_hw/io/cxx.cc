#include <sys/farptr.h>
#include <pc.h>

int
main(void)
{
  return 0;
}
