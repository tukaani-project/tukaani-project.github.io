typedef union
{
  long_double_t ldt;
  long double ld;
} test_long_double_union_t;

typedef union
{
  double_t dt;
  double d;
} test_double_union_t;

typedef union
{
  float_t ft;
  float f;
} test_float_union_t;
