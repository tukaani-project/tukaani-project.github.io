#include <crt0.h>
#if 0
void   __crt0_load_environment_file(char *_app_name){}
void   __crt0_setup_arguments(void){}
#endif
int
main(void)
{
printf("hi");
  return 0;
}
