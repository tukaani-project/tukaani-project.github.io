int
main(void)
{
  return 4;
}
