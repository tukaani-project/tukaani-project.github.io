#define TESTCRT0
#include "near.c"
