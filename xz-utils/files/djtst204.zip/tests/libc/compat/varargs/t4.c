#include <stdio.h>
#include <stdarg.h>

int
main(void)
{
  return 0;
}
