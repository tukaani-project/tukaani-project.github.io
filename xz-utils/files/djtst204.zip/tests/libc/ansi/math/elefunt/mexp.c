/* -*-C-*- mexp.c */

#include "elefunt.h"

int
main()
{
    init();
    texp();
    return (EXIT_SUCCESS);
}
