/* -*-C-*- mtan.c */

#include "elefunt.h"

int
main()
{
    init();
    ttan();
    return (EXIT_SUCCESS);
}
