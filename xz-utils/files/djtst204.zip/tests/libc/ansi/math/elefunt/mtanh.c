/* -*-C-*- mtanh.c */

#include "elefunt.h"

int
main()
{
    init();
    ttanh();
    return (EXIT_SUCCESS);
}
