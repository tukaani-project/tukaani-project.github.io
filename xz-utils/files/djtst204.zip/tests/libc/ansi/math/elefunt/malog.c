/* -*-C-*- malog.c */

#include "elefunt.h"

int
main()
{
    init();
    talog();
    return (EXIT_SUCCESS);
}
