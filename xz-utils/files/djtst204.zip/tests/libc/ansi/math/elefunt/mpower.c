/* -*-C-*- mpower.c */

#include "elefunt.h"

int
main()
{
    init();
    tpower();
    return (EXIT_SUCCESS);
}
