/*
 * Copyright (C) 2000 Andrew Zabolotny <bit@eltech.ru>
 *
 * Usage of this library is not restricted in any way.  No warranty.
 *
 * Sample DXE module.
 */


#include <string.h>

int my_strlen (const char *str)
{
  return strlen (str);
}
