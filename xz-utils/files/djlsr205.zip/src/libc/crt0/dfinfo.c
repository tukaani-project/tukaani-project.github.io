/* Copyright (C) 2015 DJ Delorie, see COPYING.DJ for details */
/* Copyright (C) 2013 DJ Delorie, see COPYING.DJ for details */
/* Copyright (C) 2011 DJ Delorie, see COPYING.DJ for details */
void __deregister_frame_info(const void *begin __attribute__((unused)));
void __deregister_frame_info(const void *begin __attribute__((unused)))
{
}
