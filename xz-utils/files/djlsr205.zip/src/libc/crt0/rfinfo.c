/* Copyright (C) 2015 DJ Delorie, see COPYING.DJ for details */
/* Copyright (C) 2012 DJ Delorie, see COPYING.DJ for details */
/* Copyright (C) 2011 DJ Delorie, see COPYING.DJ for details */
/* Copyright (C) 1998 DJ Delorie, see COPYING.DJ for details */
void __register_frame_info(const void *begin __attribute__((unused)),
                           const void *object __attribute__((unused)));
void __register_frame_info(const void *begin __attribute__((unused)),
                           const void *object __attribute__((unused)))
{
}
