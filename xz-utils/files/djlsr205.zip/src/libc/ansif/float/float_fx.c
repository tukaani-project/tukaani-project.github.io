/* Copyright (C) 1994 DJ Delorie, see COPYING.DJ for details */
#include <libc/ieee.h>

float_t __dj_float_max     = { 0x7fffff, 0xfe, 0x0 };
