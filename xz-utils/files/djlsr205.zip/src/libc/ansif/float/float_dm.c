/* Copyright (C) 1994 DJ Delorie, see COPYING.DJ for details */
#include <libc/ieee.h>

double_t __dj_double_min     = { 0x00000000, 0x00000, 0x001, 0x0 };
