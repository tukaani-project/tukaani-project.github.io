/* Copyright (C) 1994 DJ Delorie, see COPYING.DJ for details */
#include <libc/ieee.h>

float_t __dj_float_min     = { 0x000000, 0x01, 0x0 };
