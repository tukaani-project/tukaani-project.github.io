/* Copyright (C) 1994 DJ Delorie, see COPYING.DJ for details */
#include <libc/ieee.h>

double_t __dj_double_max     = { 0xffffffffU, 0xfffff, 0x7fe, 0x0 };
