/* Copyright (C) 2011 DJ Delorie, see COPYING.DJ for details */
/* Copyright (C) 1995 DJ Delorie, see COPYING.DJ for details */
#define __dj_include_sys_cdefs_h_  /* Do not include sys/cdefs.h.  It provides the _EXTERN_INLINE definition.  */
#define _EXTERN_INLINE
#include <sys/farptr.h>
