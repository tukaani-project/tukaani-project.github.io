/* Copyright (C) 2015 DJ Delorie, see COPYING.DJ for details */
/* Copyright (C) 2004 DJ Delorie, see COPYING.DJ for details */
/* Copyright (C) 2003 DJ Delorie, see COPYING.DJ for details */
#include <libc/ieee.h>

long_double_t __dj_huge_vall = { 0x00000000, 0x80000000, 0x7fff, 0x0 };
