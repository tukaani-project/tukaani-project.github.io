#define FP_INFINITE     0x00000001
#define FP_NAN          0x00000002
#define FP_NORMAL       0x00000004
#define FP_SUBNORMAL    0x00000008
#define FP_ZERO         0x00000010
#define FP_UNNORMAL     0x00010000
