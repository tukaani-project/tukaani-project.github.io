/* Copyright (C) 2003 DJ Delorie, see COPYING.DJ for details */
#include <libc/ieee.h>

float_t __dj_nan = { 0x7fffff, 0xff, 0x0 };
