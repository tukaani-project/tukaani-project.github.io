/* Copyright (C) 2003 DJ Delorie, see COPYING.DJ for details */
#define extern
#define __inline__
#include <time.h>
