/* Copyright (C) 2002 DJ Delorie, see COPYING.DJ for details */
#include <ctype.h>
#include <inlines/ctype.ha>

int (isblank)(int c)
{
  return isblank(c);
}
