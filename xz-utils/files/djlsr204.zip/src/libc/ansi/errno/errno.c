/* Copyright (C) 1994 DJ Delorie, see COPYING.DJ for details */
#include <errno.h>

int errno;
