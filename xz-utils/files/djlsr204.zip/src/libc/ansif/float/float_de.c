/* Copyright (C) 1995 DJ Delorie, see COPYING.DJ for details */
#include <libc/ieee.h>

double_t __dj_double_epsilon = { 0x00000000, 0x00000, 0x3cb, 0x0 };
