/* A Bison parser, made from djasm.y
   by GNU bison 1.35.  */

#define YYBISON 1  /* Identify Bison output.  */

# define	KID	257
# define	UID	258
# define	OP_OR	259
# define	OP_AND	260
# define	OP_NE	261
# define	OP_LE	262
# define	OP_GE	263
# define	OP_SHL	264
# define	OP_SHR	265
# define	OP_NEG	266
# define	OP_LNOT	267
# define	OP_NOT	268
# define	NUMBER	269
# define	REG8	270
# define	REG16	271
# define	REG32	272
# define	SREG	273
# define	STRING	274
# define	PC	275
# define	CRREG	276
# define	DRREG	277
# define	TRREG	278
# define	ARITH2	279
# define	ARITH2B	280
# define	ARITH2D	281
# define	ARITH2W	282
# define	LXS	283
# define	MOVSZX	284
# define	MOVSZXB	285
# define	MOVSZXW	286
# define	JCC	287
# define	JCCL	288
# define	JCXZ	289
# define	LOOP	290
# define	SETCC	291
# define	SHIFT	292
# define	SHIFTB	293
# define	SHIFTD	294
# define	SHIFTW	295
# define	DPSHIFT	296
# define	ONEBYTE	297
# define	TWOBYTE	298
# define	ASCADJ	299
# define	BITTEST	300
# define	GROUP3	301
# define	GROUP3B	302
# define	GROUP3D	303
# define	GROUP3W	304
# define	GROUP6	305
# define	GROUP7	306
# define	STRUCT	307
# define	ALIGN	308
# define	ARPL	309
# define	BOUND	310
# define	BSS	311
# define	BSF	312
# define	BSR	313
# define	CALL	314
# define	CALLF	315
# define	CALLFD	316
# define	COPYRIGHT	317
# define	DB	318
# define	DD	319
# define	DEC	320
# define	DECB	321
# define	DECD	322
# define	DECW	323
# define	DUP	324
# define	DW	325
# define	ENDS	326
# define	ENUM	327
# define	ENTER	328
# define	IN	329
# define	INC	330
# define	INCB	331
# define	INCD	332
# define	INCW	333
# define	INT	334
# define	INCLUDE	335
# define	JMPW	336
# define	JMPB	337
# define	JMPF	338
# define	JMPFD	339
# define	LAR	340
# define	LEA	341
# define	LINKCOFF	342
# define	LSL	343
# define	MOV	344
# define	MOVB	345
# define	MOVD	346
# define	MOVW	347
# define	IMUL	348
# define	IMULB	349
# define	IMULD	350
# define	IMULW	351
# define	ORG	352
# define	OUT	353
# define	POP	354
# define	POPW	355
# define	POPD	356
# define	PUSH	357
# define	PUSHW	358
# define	PUSHB	359
# define	PUSHD	360
# define	RCS_ID	361
# define	RET	362
# define	RETF	363
# define	RETD	364
# define	RETFD	365
# define	STACK	366
# define	START	367
# define	TEST	368
# define	TESTB	369
# define	TESTD	370
# define	TESTW	371
# define	TYPE	372
# define	XCHG	373

#line 5 "djasm.y"


#define YYDEBUG 1
  
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <fcntl.h>
#include <time.h>
#include <ctype.h>
#include <unistd.h>
#ifndef O_BINARY
#define O_BINARY 0
#endif
#undef _POSIX_SOURCE
#include "../../include/coff.h"

#define SMALL_EXE_HEADER 0
#if SMALL_EXE_HEADER
#define EXE_HEADER_SIZE 32
#define EXE_HEADER_BLOCKS 1
#else
#define EXE_HEADER_SIZE 512
#define EXE_HEADER_BLOCKS 32
#endif

#define YYERROR_VERBOSE

#define MAX(a,b) ((a)>(b)?(a):(b))
#define MIN(a,b) ((a)<(b)?(a):(b))

void djerror(char *s);
void yyerror(char *s);
void shxd_error(int opcode);

#define OUT_exe 0
#define OUT_com 1
#define OUT_bin 2
#define OUT_h   3
#define OUT_inc 4
#define OUT_s   5
#define OUT_sys 6
#define OUT_obj 7

char *ext_types[] = {
  "exe",
  "com",
  "bin",
  "h",
  "inc",
  "ah",
  "sys",
  "obj",
  0
};

char *INC_LEADER = "\t.db\t";
char *S_LEADER = "\t.byte\t";

int out_type = OUT_exe;
int image_type = OUT_exe;
char *outname = 0;

int i;
int lineno = 1;
char *inname;
int total_errors = 0;
char last_token[100];
int last_tret;
char *copyright = 0;

int last_align_begin=-1, last_align_end=-1;
int generated_bytes = -1;

char strbuf[200];
int strbuflen;

typedef struct {
  unsigned short line;
  unsigned short addr;
  char *name;
} lineaddr_s;

lineaddr_s *lineaddr=0;
int num_lineaddr=0;
int max_lineaddr=0;

unsigned char *outbin = 0;
int outsize = 0;
int pc = 0;
int bsspc = -1;
int stack_ptr = 0;
int start_ptr = 0;
int movacc = 0;
int main_obj = 1;

typedef struct Symbol {
  struct Symbol *next;
  char *name;
  int value;
  unsigned defined:1;
  unsigned external:1;
  unsigned public:1;
  struct Patch *patches;
  int first_used;
  int type;
} Symbol;

#define SYM_unknown	0
#define SYM_abs		1
#define SYM_data	2
#define SYM_code	4
#define SYMTYPES "?ADDTTTT"

Symbol pc_symbol = {0,".",0,1,0,0,0,0,SYM_code};

#define REL_abs		0
#define REL_abs32	1
#define REL_16		2
#define REL_8		3
#define REL_abs8	4

typedef struct Patch {
  struct Patch *next;
  int location;
  int lineno;
  char *filename;
  int rel;
} Patch;

Symbol *symtab = 0;
Symbol *get_symbol(char *name, int create);
Symbol *set_symbol(Symbol *sym, int value);
Symbol *zerosym;
int undefs = 0;

void destroy_symbol(Symbol *sym, int undef_error);
void destroy_locals(void);
void add_enum_element(Symbol *s);
void add_struct_element(Symbol *s);
void emit_struct(Symbol *ele, int tp, Symbol *struc);
void emit_struct_abs(Symbol *ele, int tp, Symbol *struc, int offset);
void build_struct(Symbol *ele, int tp, Symbol *struc);

struct {
  int regs;
  int offset;
  int addr16;
  int addr32;
  int nsyms;
  Symbol *syms[10];
} _modrm = { 0, 0, 0, 0, 0 };

unsigned char sreg_overrides[] = {
  0x26, 0x2e, 0x36, 0x3e, 0x64, 0x65
};

int struct_tp;
int struct_pc;
char *struct_sym;

int yylex(void);
int yylex1(void);

void emit(void *v, int len);
void emitb(int b);
void emitw(int w);
void emitd(long d);
void emits(Symbol *s, int offset, int rel);
void modrm(int mod, int reg, int rm);
void reg(int reg);
void addr32(int sib);
void sortsyms();

int istemp(char *symname, char which);
int islocal(char *symname);
void do_sreg_pop(int sreg);
void do_sreg_push(int sreg);
void do_align(int p2, int val);
void set_lineaddr();
void add_copyright(char *buf);
void add_rcs_ident(char *buf);

void set_out_type(char *type);
void set_image_type(char *type);
void do_include(char *fname);
void do_linkcoff(char *fname);

void write_THEADR(FILE *outfile, char *inname);
void write_LNAMES(FILE *outfile, ...);
void write_SEGDEF(FILE *outfile, int size, int name, int class, int overlay);
void write_EXTDEF(FILE *outfile, Symbol *symtab);
void write_PUBDEF(FILE *outfile, Symbol *symtab, int bss_start);
void write_LEDATA(FILE *outfile, int segment, unsigned char *outbin, int size,
		  Symbol *symtab);
void write_MODEND(FILE *outfile, int main_obj, int start_ptr);


#line 207 "djasm.y"
#ifndef YYSTYPE
typedef union {
  Symbol *sym;
  int i;
  struct {
    Symbol *sym;
    int ofs;
  } relsym;
} yystype;
# define YYSTYPE yystype
# define YYSTYPE_IS_TRIVIAL 1
#endif
#line 254 "djasm.y"

#define NO_ATTR -1

struct opcode {
  char *name;
  int token;
  int attr;
};

struct opcode opcodes[] = {
  {"aaa", ONEBYTE, 0x37},
  {"aad", ASCADJ, 0xd5},
  {"aam", ASCADJ, 0xd4},
  {"aas", ONEBYTE, 0x3f},
  {"cbw", ONEBYTE, 0x98},
  {"cwde", TWOBYTE, 0x6698},
  {"clc", ONEBYTE, 0xf8},
  {"cld", ONEBYTE, 0xfc},
  {"cli", ONEBYTE, 0xfa},
  {"clts", TWOBYTE, 0x0f06},
  {"cmc", ONEBYTE, 0xf5},
  {"cmpsb", ONEBYTE, 0xa6},
  {"cmpsw", ONEBYTE, 0xa7},
  {"cmpsd", TWOBYTE, 0x66a7},
  {"cpuid", TWOBYTE, 0x0fa2},
  {"cwd", ONEBYTE, 0x99},
  {"cdq", TWOBYTE, 0x6699},
  {"daa", ONEBYTE, 0x27},
  {"das", ONEBYTE, 0x2f},
  {"hlt", ONEBYTE, 0xf4},
  {"insb", ONEBYTE, 0x6c},
  {"insw", ONEBYTE, 0x6d},
  {"insd", TWOBYTE, 0x666d},
  {"into", ONEBYTE, 0xce},
  {"iret", ONEBYTE, 0xcf},
  {"iretd", TWOBYTE, 0x66cf},
  {"lahf", ONEBYTE, 0x9f},
  {"leave", ONEBYTE, 0xc9},
  {"lock", ONEBYTE, 0xf0},
  {"lodsb", ONEBYTE, 0xac},
  {"lodsw", ONEBYTE, 0xad},
  {"lodsd", TWOBYTE, 0x66ad},
  {"movsb", ONEBYTE, 0xa4},
  {"movsw", ONEBYTE, 0xa5},
  {"movsd", TWOBYTE, 0x66a5},
  {"nop", ONEBYTE, 0x90},
  {"outsb", ONEBYTE, 0x6e},
  {"outsw", ONEBYTE, 0x6f},
  {"outsd", TWOBYTE, 0x666f},
  {"popa", ONEBYTE, 0x61},
  {"popad", TWOBYTE, 0x6661},
  {"popf", ONEBYTE, 0x9d},
  {"popfd", TWOBYTE, 0x669d},
  {"pusha", ONEBYTE, 0x60},
  {"pushad", TWOBYTE, 0x6660},
  {"pushf", ONEBYTE, 0x9c},
  {"pushfd", TWOBYTE, 0x669c},
  {"rep", ONEBYTE, 0xf3},
  {"repe", ONEBYTE, 0xf3},
  {"repz", ONEBYTE, 0xf3},
  {"repne", ONEBYTE, 0xf2},
  {"repnz", ONEBYTE, 0xf2},
  {"sahf", ONEBYTE, 0x9e},
  {"scasb", ONEBYTE, 0xae},
  {"scasw", ONEBYTE, 0xaf},
  {"scasd", TWOBYTE, 0x66af},
  {"stc", ONEBYTE, 0xf9},
  {"std", ONEBYTE, 0xfd},
  {"sti", ONEBYTE, 0xfb},
  {"stosb", ONEBYTE, 0xaa},
  {"stosw", ONEBYTE, 0xab},
  {"stosd", TWOBYTE, 0x66ab},
  {"wait", ONEBYTE, 0x9b},
  {"fwait", ONEBYTE, 0x9b},
  {"wbinvd", TWOBYTE, 0x0f09},
  {"xlat", ONEBYTE, 0xd7},
  {"xlatb", ONEBYTE, 0xd7},

  {".addrsize", ONEBYTE, 0x67},
  {".opsize", ONEBYTE, 0x66},
  {".segcs", ONEBYTE, 0x2e},
  {".segds", ONEBYTE, 0x3e},
  {".seges", ONEBYTE, 0x26},
  {".segss", ONEBYTE, 0x36},
  {".segfs", ONEBYTE, 0x64},
  {".seggs", ONEBYTE, 0x65},

  {".align", ALIGN, NO_ATTR},
  {".bss", BSS, NO_ATTR},
  {".copyright", COPYRIGHT, NO_ATTR},
  {".db", DB, NO_ATTR},
  {".dd", DD, NO_ATTR},
  {".dup", DUP, NO_ATTR},
  {".dw", DW, NO_ATTR},
  {".ends", ENDS, NO_ATTR},
  {".enum", ENUM, NO_ATTR},
  {".id", RCS_ID, NO_ATTR},
  {".include", INCLUDE, NO_ATTR},
  {".linkcoff", LINKCOFF, NO_ATTR},
  {".org", ORG, NO_ATTR},
  {".stack", STACK, NO_ATTR},
  {".start", START, NO_ATTR},
  {".struct", STRUCT, 's'},
  {".type", TYPE, NO_ATTR},
  {".union", STRUCT, 'u'},

  {"adc", ARITH2, 2},
  {"adcb", ARITH2B, 2},
  {"adcd", ARITH2D, 2},
  {"adcw", ARITH2W, 2},
  {"add", ARITH2, 0},
  {"addb", ARITH2B, 0},
  {"addd", ARITH2D, 0},
  {"addw", ARITH2W, 0},
  {"and", ARITH2, 4},
  {"andb", ARITH2B, 4},
  {"andd", ARITH2D, 4},
  {"andw", ARITH2W, 4},
  {"arpl", ARPL, NO_ATTR},
  {"bound", BOUND, NO_ATTR},
  {"bsf", BSF, NO_ATTR},
  {"bsr", BSR, NO_ATTR},
  {"bt", BITTEST, 4},
  {"btc", BITTEST, 7},
  {"btr", BITTEST, 6},
  {"bts", BITTEST, 5},
  {"call", CALL, NO_ATTR},
  {"callf", CALLF, NO_ATTR},
  {"callfd", CALLFD, NO_ATTR},
  {"cmp", ARITH2, 7},
  {"cmpb", ARITH2B, 7},
  {"cmpd", ARITH2D, 7},
  {"cmpw", ARITH2W, 7},
  {"dec", DEC, NO_ATTR},
  {"decb", DECB, NO_ATTR},
  {"decd", DECD, NO_ATTR},
  {"decw", DECW, NO_ATTR},
  {"div", GROUP3, 6},
  {"divb", GROUP3B, 6},
  {"divd", GROUP3D, 6},
  {"divw", GROUP3W, 6},
  {"enter", ENTER, NO_ATTR},
  {"idiv", GROUP3, 7},
  {"idivb", GROUP3B, 7},
  {"idivd", GROUP3D, 7},
  {"idivw", GROUP3W, 7},
  {"imul", IMUL, NO_ATTR},
  {"imulb", IMULB, NO_ATTR},
  {"imuld", IMULD, NO_ATTR},
  {"imulw", IMULW, NO_ATTR},
  {"in", IN, NO_ATTR},
  {"inc", INC, NO_ATTR},
  {"incb", INCB, NO_ATTR},
  {"incd", INCD, NO_ATTR},
  {"incw", INCW, NO_ATTR},
  {"int", INT, NO_ATTR},

  {"jo", JCC, 0},
  {"jno", JCC, 1},
  {"jb", JCC, 2},
  {"jc", JCC, 2},
  {"jnae", JCC, 2},
  {"jnb", JCC, 3},
  {"jnc", JCC, 3},
  {"jae", JCC, 3},
  {"jz", JCC, 4},
  {"je", JCC, 4},
  {"jnz", JCC, 5},
  {"jne", JCC, 5},
  {"jbe", JCC, 6},
  {"jna", JCC, 6},
  {"jnbe", JCC, 7},
  {"ja", JCC, 7},
  {"js", JCC, 8},
  {"jns", JCC, 9},
  {"jp", JCC, 10},
  {"jpe", JCC, 10},
  {"jnp", JCC, 11},
  {"jpo", JCC, 11},
  {"jl", JCC, 12},
  {"jnge", JCC, 12},
  {"jnl", JCC, 13},
  {"jge", JCC, 13},
  {"jle", JCC, 14},
  {"jng", JCC, 14},
  {"jnle", JCC, 15},
  {"jg", JCC, 15},

  {"jol", JCCL, 0},
  {"jnol", JCCL, 1},
  {"jbl", JCCL, 2},
  {"jcl", JCCL, 2},
  {"jnael", JCCL, 2},
  {"jnbl", JCCL, 3},
  {"jncl", JCCL, 3},
  {"jael", JCCL, 3},
  {"jzl", JCCL, 4},
  {"jel", JCCL, 4},
  {"jnzl", JCCL, 5},
  {"jnel", JCCL, 5},
  {"jbel", JCCL, 6},
  {"jnal", JCCL, 6},
  {"jnbel", JCCL, 7},
  {"jal", JCCL, 7},
  {"jsl", JCCL, 8},
  {"jnsl", JCCL, 9},
  {"jpl", JCCL, 10},
  {"jpel", JCCL, 10},
  {"jnpl", JCCL, 11},
  {"jpol", JCCL, 11},
  {"jll", JCCL, 12},
  {"jngel", JCCL, 12},
  {"jnll", JCCL, 13},
  {"jgel", JCCL, 13},
  {"jlel", JCCL, 14},
  {"jngl", JCCL, 14},
  {"jnlel", JCCL, 15},
  {"jgl", JCCL, 15},

  {"jcxz", JCXZ, 0},
  {"jecxz", JCXZ, 1},

  {"jmp", JMPB, NO_ATTR},
  {"jmpf", JMPF, NO_ATTR},
  {"jmpfd", JMPFD, NO_ATTR},
  {"jmpl", JMPW, NO_ATTR},
  {"lar", LAR, NO_ATTR},
  {"lds", LXS, 0xc5},
  {"lea", LEA, NO_ATTR},
  {"les", LXS, 0xc4},
  {"lfs", LXS, 0x0fb4},
  {"lgs", LXS, 0x0fb5},
  {"lsl", LSL, NO_ATTR},
  {"lss", LXS, 0x0fb2},
  {"lgdt", GROUP7, 2},
  {"lidt", GROUP7, 3},
  {"lldt", GROUP6, 2},
  {"lmsw", GROUP7, 6},
  {"loop", LOOP, 0xe2},
  {"loope", LOOP, 0xe1},
  {"loopne", LOOP, 0xe0},
  {"loopnz", LOOP, 0xe0},
  {"loopz", LOOP, 0xe1},
  {"ltr", GROUP6, 3},
  {"mov", MOV, NO_ATTR},
  {"movb", MOVB, NO_ATTR},
  {"movd", MOVD, NO_ATTR},
  {"movw", MOVW, NO_ATTR},
  {"movsx", MOVSZX, 0xbe},
  {"movsxb", MOVSZXB, 0xbe},
  {"movsxw", MOVSZXW, 0xbe},
  {"movzx", MOVSZX, 0xb6},
  {"movzxb", MOVSZXB, 0xb6},
  {"movzxw", MOVSZXW, 0xb6},
  {"mul", GROUP3, 4},
  {"mulb", GROUP3B, 4},
  {"muld", GROUP3D, 4},
  {"mulw", GROUP3W, 4},
  {"not", GROUP3, 2},
  {"neg", GROUP3, 3},
  {"or", ARITH2, 1},
  {"orb", ARITH2B, 1},
  {"ord", ARITH2D, 1},
  {"orw", ARITH2W, 1},
  {"out", OUT, NO_ATTR},
  {"pop", POP, NO_ATTR},
  {"popw", POPW, NO_ATTR},
  {"popd", POPD, NO_ATTR},
  {"push", PUSH, NO_ATTR},
  {"pushb", PUSHB, NO_ATTR},
  {"pushw", PUSHW, NO_ATTR},
  {"pushd", PUSHD, NO_ATTR},
  {"rcl", SHIFT, 2},
  {"rclb", SHIFTB, 2},
  {"rcld", SHIFTD, 2},
  {"rclw", SHIFTW, 2},
  {"rcr", SHIFT, 3},
  {"rcrb", SHIFTB, 3},
  {"rcrd", SHIFTD, 3},
  {"rcrw", SHIFTW, 3},
  {"ret", RET, NO_ATTR},
  {"retd", RETD, NO_ATTR},
  {"retf", RETF, NO_ATTR},
  {"retfd", RETFD, NO_ATTR},
  {"rol", SHIFT, 0},
  {"rolb", SHIFTB, 0},
  {"rold", SHIFTD, 0},
  {"rolw", SHIFTW, 0},
  {"ror", SHIFT, 1},
  {"rorb", SHIFTB, 1},
  {"rord", SHIFTD, 1},
  {"rorw", SHIFTW, 1},
  {"sar", SHIFT, 7},
  {"sarb", SHIFTB, 7},
  {"sard", SHIFTD, 7},
  {"sarw", SHIFTW, 7},
  {"sbb", ARITH2, 3},
  {"sbbb", ARITH2B, 3},
  {"sbbd", ARITH2D, 3},
  {"sbbw", ARITH2W, 3},

  {"seto", SETCC, 0},
  {"setno", SETCC, 1},
  {"setb", SETCC, 2},
  {"setc", SETCC, 2},
  {"setnae", SETCC, 2},
  {"setnb", SETCC, 3},
  {"setnc", SETCC, 3},
  {"setae", SETCC, 3},
  {"setz", SETCC, 4},
  {"sete", SETCC, 4},
  {"setnz", SETCC, 5},
  {"setne", SETCC, 5},
  {"setbe", SETCC, 6},
  {"setna", SETCC, 6},
  {"setnbe", SETCC, 7},
  {"seta", SETCC, 7},
  {"sets", SETCC, 8},
  {"setns", SETCC, 9},
  {"setp", SETCC, 10},
  {"setpe", SETCC, 10},
  {"setnp", SETCC, 11},
  {"setpo", SETCC, 11},
  {"setl", SETCC, 12},
  {"setnge", SETCC, 12},
  {"setnl", SETCC, 13},
  {"setge", SETCC, 13},
  {"setle", SETCC, 14},
  {"setng", SETCC, 14},
  {"setnle", SETCC, 15},
  {"setg", SETCC, 15},

  {"sgdt", GROUP7, 0},
  {"sidt", GROUP7, 1},
  {"sldt", GROUP6, 0},
  {"sal", SHIFT, 4},
  {"salb", SHIFTB, 4},
  {"sald", SHIFTD, 4},
  {"salw", SHIFTW, 4},
  {"shl", SHIFT, 4},
  {"shlb", SHIFTB, 4},
  {"shld", SHIFTD, 4},
  {"shlw", SHIFTW, 4},
  {"dshl", DPSHIFT, 0xa4},
  {"shr", SHIFT, 5},
  {"shrb", SHIFTB, 5},
  {"shrd", SHIFTD, 5},
  {"shrw", SHIFTW, 5},
  {"dshr", DPSHIFT, 0xac},
  {"smsw", GROUP7, 4},
  {"str", GROUP6, 1},
  {"sub", ARITH2, 5},
  {"subb", ARITH2B, 5},
  {"subd", ARITH2D, 5},
  {"subw", ARITH2W, 5},
  {"test", TEST, NO_ATTR},
  {"testb", TESTB, NO_ATTR},
  {"testw", TESTW, NO_ATTR},
  {"testd", TESTD, NO_ATTR},
  {"verr", GROUP6, 4},
  {"verw", GROUP6, 5},
  {"xchg", XCHG, NO_ATTR},
  {"xor", ARITH2, 6},
  {"xorb", ARITH2B, 6},
  {"xord", ARITH2D, 6},
  {"xorw", ARITH2W, 6},

  {"al", REG8, 0},
  {"cl", REG8, 1},
  {"dl", REG8, 2},
  {"bl", REG8, 3},
  {"ah", REG8, 4},
  {"ch", REG8, 5},
  {"dh", REG8, 6},
  {"bh", REG8, 7},

  {"es", SREG, 0},
  {"cs", SREG, 1},
  {"ss", SREG, 2},
  {"ds", SREG, 3},
  {"fs", SREG, 4},
  {"gs", SREG, 5},

  {"ax", REG16, 0},
  {"cx", REG16, 1},
  {"dx", REG16, 2},
  {"bx", REG16, 3},
  {"sp", REG16, 4},
  {"bp", REG16, 5},
  {"si", REG16, 6},
  {"di", REG16, 7},

  {"eax", REG32, 0},
  {"ecx", REG32, 1},
  {"edx", REG32, 2},
  {"ebx", REG32, 3},
  {"esp", REG32, 4},
  {"ebp", REG32, 5},
  {"esi", REG32, 6},
  {"edi", REG32, 7},

  {"cr0", CRREG, 0},
  {"cr2", CRREG, 2},
  {"cr3", CRREG, 3},

  {"dr0", DRREG, 0},
  {"dr1", DRREG, 1},
  {"dr2", DRREG, 2},
  {"dr3", DRREG, 3},
  {"dr6", DRREG, 6},
  {"dr7", DRREG, 7},

  {"tr3", TRREG, 3},
  {"tr4", TRREG, 4},
  {"tr5", TRREG, 5},
  {"tr6", TRREG, 6},
  {"tr7", TRREG, 7},
};
#ifndef YYDEBUG
# define YYDEBUG 0
#endif



#define	YYFINAL		655
#define	YYFLAG		-32768
#define	YYNTBASE	140

/* YYTRANSLATE(YYLEX) -- Bison token number corresponding to YYLEX. */
#define YYTRANSLATE(x) ((unsigned)(x) <= 373 ? yytranslate[x] : 164)

/* YYTRANSLATE[YYLEX] -- Bison token number corresponding to YYLEX. */
static const short yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     131,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,   138,     2,     2,     2,    22,     9,     2,
     133,   134,    20,    18,   135,    19,     2,    21,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,   132,     2,
      11,    10,    12,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,   136,     2,   137,     7,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     6,     2,   139,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     3,     4,     5,
       8,    13,    14,    15,    16,    17,    23,    24,    25,    26,
      27,    28,    29,    30,    31,    32,    33,    34,    35,    36,
      37,    38,    39,    40,    41,    42,    43,    44,    45,    46,
      47,    48,    49,    50,    51,    52,    53,    54,    55,    56,
      57,    58,    59,    60,    61,    62,    63,    64,    65,    66,
      67,    68,    69,    70,    71,    72,    73,    74,    75,    76,
      77,    78,    79,    80,    81,    82,    83,    84,    85,    86,
      87,    88,    89,    90,    91,    92,    93,    94,    95,    96,
      97,    98,    99,   100,   101,   102,   103,   104,   105,   106,
     107,   108,   109,   110,   111,   112,   113,   114,   115,   116,
     117,   118,   119,   120,   121,   122,   123,   124,   125,   126,
     127,   128,   129,   130
};

#if YYDEBUG
static const short yyprhs[] =
{
       0,     0,     1,     5,    10,    15,    16,    19,    23,    24,
      31,    32,    39,    43,    50,    52,    54,    56,    58,    61,
      66,    71,    76,    81,    86,    91,    96,   101,   106,   111,
     116,   121,   126,   131,   136,   141,   146,   148,   151,   154,
     159,   164,   169,   174,   179,   184,   189,   194,   199,   204,
     209,   214,   219,   224,   229,   234,   239,   244,   247,   250,
     253,   256,   261,   266,   269,   271,   274,   277,   280,   283,
     286,   289,   292,   295,   298,   303,   308,   313,   318,   323,
     328,   333,   336,   339,   342,   345,   348,   351,   354,   357,
     360,   363,   366,   369,   374,   379,   384,   389,   396,   403,
     410,   417,   420,   423,   426,   429,   432,   435,   438,   441,
     444,   447,   450,   453,   456,   459,   462,   465,   468,   471,
     474,   479,   484,   489,   494,   499,   504,   507,   510,   515,
     520,   525,   530,   535,   540,   545,   550,   555,   560,   565,
     570,   575,   580,   585,   590,   595,   600,   605,   610,   615,
     620,   625,   630,   635,   640,   645,   650,   655,   660,   665,
     670,   675,   680,   685,   688,   693,   698,   703,   708,   713,
     718,   723,   726,   729,   732,   735,   738,   741,   744,   747,
     750,   753,   756,   759,   762,   764,   767,   769,   772,   774,
     777,   779,   782,   785,   788,   793,   798,   803,   808,   813,
     818,   823,   828,   833,   838,   843,   848,   855,   862,   869,
     876,   883,   890,   897,   904,   911,   918,   925,   932,   939,
     946,   953,   960,   962,   964,   969,   974,   979,   984,   989,
     994,   999,  1004,  1009,  1014,  1019,  1024,  1029,  1034,  1039,
    1042,  1045,  1050,  1055,  1060,  1065,  1070,  1075,  1080,  1085,
    1090,  1091,  1095,  1096,  1099,  1103,  1106,  1108,  1109,  1113,
    1114,  1118,  1119,  1121,  1125,  1127,  1131,  1133,  1137,  1139,
    1143,  1145,  1147,  1151,  1153,  1157,  1159,  1162,  1166,  1168,
    1172,  1174,  1177,  1181,  1183,  1187,  1192,  1196,  1202,  1204,
    1208,  1212,  1216,  1218,  1220,  1222,  1224,  1226,  1230,  1234,
    1238,  1240,  1242,  1244,  1248,  1252,  1256,  1260,  1264,  1268,
    1272,  1276,  1280,  1284,  1288,  1292,  1296,  1300,  1304,  1308,
    1312,  1316,  1319,  1322,  1325,  1329,  1331,  1333,  1336,  1338,
    1341,  1344
};
static const short yyrhs[] =
{
      -1,   140,   141,   131,     0,   140,    92,    31,   131,     0,
     140,    92,    26,   131,     0,     0,   161,   132,     0,   161,
      10,   160,     0,     0,    64,   161,   131,   142,   144,    83,
       0,     0,    84,   161,   131,   143,   147,    83,     0,   161,
      64,   161,     0,   161,    64,   161,   133,   160,   134,     0,
       1,     0,    54,     0,    55,     0,    68,     0,    30,   132,
       0,    37,   156,   135,   160,     0,    36,    27,   135,   160,
       0,    36,    27,   135,    27,     0,    36,   156,   135,    27,
       0,    36,    27,   135,   156,     0,    39,   156,   135,   162,
       0,    36,    28,   135,   162,     0,    36,    28,   135,    28,
       0,    36,   156,   135,    28,     0,    36,    28,   135,   156,
       0,    38,   156,   135,   162,     0,    36,    29,   135,   162,
       0,    36,    29,   135,    29,     0,    36,   156,   135,    29,
       0,    36,    29,   135,   156,     0,    66,    28,   135,    28,
       0,    66,   156,   135,    28,     0,    56,     0,    56,   160,
       0,    65,   160,     0,    65,   160,   135,   160,     0,    67,
      28,   135,   156,     0,    67,    29,   135,   156,     0,    57,
      28,   135,    28,     0,    57,   156,   135,    28,     0,    57,
      29,   135,    29,     0,    57,   156,   135,    29,     0,    57,
      28,   135,   160,     0,    57,   156,   135,   160,     0,    57,
      29,   135,   160,     0,    69,    28,   135,    28,     0,    69,
      28,   135,   156,     0,    69,    29,   135,    29,     0,    69,
      29,   135,   156,     0,    70,    28,   135,    28,     0,    70,
      28,   135,   156,     0,    70,    29,   135,    29,     0,    70,
      29,   135,   156,     0,    71,   161,     0,    71,    28,     0,
      71,   156,     0,    72,   156,     0,    72,   160,   132,   162,
       0,    73,   160,   132,   162,     0,    74,    31,     0,   118,
       0,    75,   151,     0,    82,   153,     0,    76,   155,     0,
      77,    27,     0,    78,   156,     0,    77,    28,     0,    77,
      29,     0,    80,   156,     0,    79,   156,     0,    85,   160,
     135,   160,     0,    86,    27,   135,   160,     0,    86,    28,
     135,   160,     0,    86,    29,   135,   160,     0,    86,    27,
     135,    28,     0,    86,    28,   135,    28,     0,    86,    29,
     135,    28,     0,    87,    27,     0,    88,   156,     0,    87,
      28,     0,    87,    29,     0,    90,   156,     0,    89,   156,
       0,   105,    27,     0,   106,   156,     0,   105,    28,     0,
     108,   156,     0,   105,    29,     0,   107,   156,     0,   105,
      28,   135,    28,     0,   105,    29,   135,    29,     0,   105,
      28,   135,   156,     0,   105,    29,   135,   156,     0,   105,
      28,   135,    28,   135,   160,     0,   105,    29,   135,    29,
     135,   160,     0,   105,    28,   135,   156,   135,   160,     0,
     105,    29,   135,   156,   135,   160,     0,    58,    27,     0,
      59,   156,     0,    58,    28,     0,    61,   156,     0,    58,
      29,     0,    60,   156,     0,    62,   156,     0,    62,    28,
       0,    63,   156,     0,    63,    28,     0,    91,   160,     0,
      44,   161,     0,    45,   161,     0,    46,   161,     0,    93,
     161,     0,    94,   161,     0,    94,    28,     0,    94,   156,
       0,    95,   156,     0,    95,   160,   132,   162,     0,    96,
     160,   132,   162,     0,    97,    28,   135,    28,     0,    97,
      28,   135,   156,     0,    98,    28,   135,   156,     0,    98,
      29,   135,   156,     0,    99,    31,     0,    47,   161,     0,
     100,    28,   135,    28,     0,   100,    28,   135,   156,     0,
      40,    28,   135,   156,     0,    40,    29,   135,   156,     0,
     102,   156,   135,   160,     0,   101,    27,   135,   160,     0,
     101,    27,   135,    27,     0,   101,   156,   135,    27,     0,
     101,    27,   135,   156,     0,   104,   156,   135,   162,     0,
     101,    28,   135,   162,     0,   101,    28,   135,    28,     0,
     101,   156,   135,    28,     0,   101,    28,   135,   156,     0,
     103,   156,   135,   162,     0,   101,    29,   135,   162,     0,
     101,    29,   135,    29,     0,   101,   156,   135,    29,     0,
     101,    29,   135,   156,     0,   101,   156,   135,    30,     0,
     101,    28,   135,    30,     0,   101,    30,   135,   156,     0,
     101,    30,   135,    28,     0,   101,    33,   135,    29,     0,
     101,    34,   135,    29,     0,   101,    35,   135,    29,     0,
     101,    29,   135,    33,     0,   101,    29,   135,    34,     0,
     101,    29,   135,    35,     0,    41,    28,   135,    27,     0,
      41,    29,   135,    27,     0,    41,    29,   135,    28,     0,
      42,    28,   135,   156,     0,    42,    29,   135,   156,     0,
      43,    29,   135,   156,     0,   109,   160,     0,   109,   160,
     135,   160,     0,   110,   160,   135,    27,     0,   110,   160,
     135,    28,     0,   110,   160,   135,    29,     0,   110,    28,
     135,    27,     0,   110,    28,   135,    28,     0,   110,    28,
     135,    29,     0,   111,    28,     0,   111,    29,     0,   111,
      30,     0,   112,   156,     0,   113,   156,     0,   114,    28,
       0,   114,    29,     0,   114,    30,     0,   115,   156,     0,
     117,   156,     0,   116,   160,     0,   115,   162,     0,   117,
     162,     0,   119,     0,   119,   160,     0,   120,     0,   120,
     160,     0,   121,     0,   121,   160,     0,   122,     0,   122,
     160,     0,    48,    27,     0,    48,   156,     0,    49,    27,
     135,   160,     0,    49,    27,   135,    27,     0,    50,   156,
     135,   160,     0,    50,   156,   135,    27,     0,    49,    28,
     135,   160,     0,    49,    28,   135,    27,     0,    52,   156,
     135,   160,     0,    52,   156,   135,    27,     0,    49,    29,
     135,   160,     0,    49,    29,   135,    27,     0,    51,   156,
     135,   160,     0,    51,   156,   135,    27,     0,    51,    28,
     135,    28,   135,   160,     0,    51,    28,   135,    28,   135,
      27,     0,    51,   156,   135,    28,   135,   160,     0,    51,
     156,   135,    28,   135,    27,     0,    51,    29,   135,    29,
     135,   160,     0,    51,    29,   135,    29,   135,    27,     0,
      51,   156,   135,    29,   135,   160,     0,    51,   156,   135,
      29,   135,    27,     0,    53,    28,   135,    28,   135,   160,
       0,    53,    28,   135,    28,   135,    27,     0,    53,   156,
     135,    28,   135,   160,     0,    53,   156,   135,    28,   135,
      27,     0,    53,    29,   135,    29,   135,   160,     0,    53,
      29,   135,    29,   135,    27,     0,    53,   156,   135,    29,
     135,   160,     0,    53,   156,   135,    29,   135,    27,     0,
     123,     0,   124,     0,   126,   156,   135,   160,     0,   125,
      27,   135,   160,     0,   125,    27,   135,    27,     0,   125,
     156,   135,    27,     0,   125,    27,   135,   156,     0,   128,
     156,   135,   162,     0,   125,    28,   135,   162,     0,   125,
      28,   135,    28,     0,   125,   156,   135,    28,     0,   125,
      28,   135,   156,     0,   127,   156,   135,   162,     0,   125,
      29,   135,   162,     0,   125,    29,   135,    29,     0,   125,
     156,   135,    29,     0,   125,    29,   135,   156,     0,   129,
      31,     0,   129,    26,     0,   130,    27,   135,    27,     0,
     130,    27,   135,   156,     0,   130,   156,   135,    27,     0,
     130,    28,   135,    28,     0,   130,    28,   135,   156,     0,
     130,   156,   135,    28,     0,   130,    29,   135,    29,     0,
     130,    29,   135,   156,     0,   130,   156,   135,    29,     0,
       0,   144,   145,   131,     0,     0,   161,   132,     0,   161,
      64,   161,     0,    64,   161,     0,   149,     0,     0,   161,
     146,   149,     0,     0,   147,   148,   131,     0,     0,   161,
       0,   161,    10,   160,     0,    75,     0,    75,   160,    81,
       0,    82,     0,    82,   160,    81,     0,    76,     0,    76,
     160,    81,     0,   160,     0,    31,     0,   160,    81,   160,
       0,   150,     0,   151,   135,   150,     0,   160,     0,     4,
     163,     0,   160,    81,   160,     0,   152,     0,   153,   135,
     152,     0,   160,     0,     4,   163,     0,   160,    81,   160,
       0,   154,     0,   155,   135,   154,     0,   158,   136,   157,
     137,     0,   136,   157,   137,     0,    30,   132,   136,   157,
     137,     0,   158,     0,   157,    18,   157,     0,   157,    19,
     160,     0,    30,   132,   158,     0,    28,     0,    29,     0,
     159,     0,     4,     0,   160,     0,    29,    20,   160,     0,
     160,    20,    29,     0,    29,    16,   160,     0,    26,     0,
       3,     0,    32,     0,   160,     5,   160,     0,   160,     6,
     160,     0,   160,     7,   160,     0,   160,     8,   160,     0,
     160,     9,   160,     0,   160,    10,   160,     0,   160,    12,
     160,     0,   160,    11,   160,     0,   160,    15,   160,     0,
     160,    14,   160,     0,   160,    13,   160,     0,   160,    16,
     160,     0,   160,    17,   160,     0,   160,    18,   160,     0,
     160,    19,   160,     0,   160,    20,   160,     0,   160,    21,
     160,     0,   160,    22,   160,     0,    19,   160,     0,   138,
     160,     0,   139,   160,     0,   133,   160,   134,     0,     3,
       0,     4,     0,     4,   163,     0,   160,     0,    18,   160,
       0,    19,   160,     0,     0
};

#endif

#if YYDEBUG
/* YYRLINE[YYN] -- source line where rule number YYN was defined. */
static const short yyrline[] =
{
       0,   679,   680,   681,   682,   686,   688,   689,   690,   690,
     702,   702,   711,   712,   713,   715,   716,   718,   720,   722,
     723,   729,   730,   731,   733,   734,   748,   749,   750,   752,
     753,   768,   769,   770,   772,   773,   775,   776,   778,   779,
     781,   782,   784,   785,   786,   787,   788,   789,   790,   792,
     793,   794,   795,   797,   798,   799,   800,   802,   803,   804,
     805,   806,   807,   809,   810,   812,   813,   814,   816,   817,
     818,   819,   820,   821,   823,   825,   826,   827,   828,   829,
     830,   832,   833,   834,   835,   836,   837,   839,   840,   841,
     842,   843,   844,   845,   846,   847,   848,   849,   859,   871,
     881,   893,   894,   895,   896,   897,   898,   900,   901,   902,
     903,   905,   907,   908,   910,   912,   913,   914,   915,   916,
     917,   918,   920,   921,   923,   924,   926,   927,   929,   930,
     932,   933,   935,   936,   937,   938,   944,   950,   951,   952,
     953,   959,   965,   966,   967,   968,   975,   982,   983,   984,
     985,   987,   988,   989,   990,   991,   992,   994,   995,   996,
     998,   999,  1000,  1002,  1003,  1005,  1006,  1007,  1008,  1009,
    1010,  1012,  1013,  1014,  1015,  1016,  1017,  1018,  1019,  1020,
    1021,  1022,  1023,  1024,  1026,  1027,  1028,  1029,  1030,  1031,
    1032,  1033,  1035,  1036,  1039,  1040,  1041,  1042,  1043,  1044,
    1045,  1046,  1047,  1048,  1049,  1050,  1060,  1061,  1062,  1063,
    1064,  1065,  1066,  1067,  1075,  1076,  1077,  1078,  1081,  1082,
    1083,  1084,  1086,  1087,  1089,  1090,  1091,  1092,  1093,  1095,
    1096,  1097,  1098,  1099,  1101,  1102,  1103,  1104,  1105,  1107,
    1108,  1110,  1111,  1112,  1113,  1118,  1119,  1120,  1126,  1127,
    1131,  1132,  1136,  1137,  1138,  1139,  1140,  1141,  1141,  1146,
    1147,  1151,  1152,  1153,  1157,  1163,  1169,  1175,  1181,  1187,
    1197,  1198,  1199,  1203,  1204,  1208,  1209,  1210,  1214,  1215,
    1219,  1220,  1221,  1225,  1226,  1230,  1231,  1232,  1236,  1237,
    1238,  1242,  1243,  1251,  1252,  1253,  1254,  1258,  1265,  1272,
    1282,  1283,  1284,  1285,  1286,  1287,  1288,  1289,  1290,  1291,
    1292,  1293,  1294,  1295,  1296,  1297,  1298,  1299,  1300,  1301,
    1302,  1303,  1304,  1305,  1306,  1310,  1311,  1315,  1316,  1320,
    1321,  1322
};
#endif


#if (YYDEBUG) || defined YYERROR_VERBOSE

/* YYTNAME[TOKEN_NUM] -- String name of the token TOKEN_NUM. */
static const char *const yytname[] =
{
  "$", "error", "$undefined.", "KID", "UID", "OP_OR", "'|'", "'^'", 
  "OP_AND", "'&'", "'='", "'<'", "'>'", "OP_NE", "OP_LE", "OP_GE", 
  "OP_SHL", "OP_SHR", "'+'", "'-'", "'*'", "'/'", "'%'", "OP_NEG", 
  "OP_LNOT", "OP_NOT", "NUMBER", "REG8", "REG16", "REG32", "SREG", 
  "STRING", "PC", "CRREG", "DRREG", "TRREG", "ARITH2", "ARITH2B", 
  "ARITH2D", "ARITH2W", "LXS", "MOVSZX", "MOVSZXB", "MOVSZXW", "JCC", 
  "JCCL", "JCXZ", "LOOP", "SETCC", "SHIFT", "SHIFTB", "SHIFTD", "SHIFTW", 
  "DPSHIFT", "ONEBYTE", "TWOBYTE", "ASCADJ", "BITTEST", "GROUP3", 
  "GROUP3B", "GROUP3D", "GROUP3W", "GROUP6", "GROUP7", "STRUCT", "ALIGN", 
  "ARPL", "BOUND", "BSS", "BSF", "BSR", "CALL", "CALLF", "CALLFD", 
  "COPYRIGHT", "DB", "DD", "DEC", "DECB", "DECD", "DECW", "DUP", "DW", 
  "ENDS", "ENUM", "ENTER", "IN", "INC", "INCB", "INCD", "INCW", "INT", 
  "INCLUDE", "JMPW", "JMPB", "JMPF", "JMPFD", "LAR", "LEA", "LINKCOFF", 
  "LSL", "MOV", "MOVB", "MOVD", "MOVW", "IMUL", "IMULB", "IMULD", "IMULW", 
  "ORG", "OUT", "POP", "POPW", "POPD", "PUSH", "PUSHW", "PUSHB", "PUSHD", 
  "RCS_ID", "RET", "RETF", "RETD", "RETFD", "STACK", "START", "TEST", 
  "TESTB", "TESTD", "TESTW", "TYPE", "XCHG", "'\\n'", "':'", "'('", "')'", 
  "','", "'['", "']'", "'!'", "'~'", "lines", "line", "@1", "@2", 
  "struct_lines", "struct_line", "@3", "enum_lines", "enum_line", 
  "struct_db", "dbitem", "dblist", "dwitem", "dwlist", "dditem", "ddlist", 
  "regmem", "regmemexpr", "regmemitem", "scaledindex", "const", "ID", 
  "constID", "offset", 0
};
#endif

/* YYR1[YYN] -- Symbol number of symbol that rule YYN derives. */
static const short yyr1[] =
{
       0,   140,   140,   140,   140,   141,   141,   141,   142,   141,
     143,   141,   141,   141,   141,   141,   141,   141,   141,   141,
     141,   141,   141,   141,   141,   141,   141,   141,   141,   141,
     141,   141,   141,   141,   141,   141,   141,   141,   141,   141,
     141,   141,   141,   141,   141,   141,   141,   141,   141,   141,
     141,   141,   141,   141,   141,   141,   141,   141,   141,   141,
     141,   141,   141,   141,   141,   141,   141,   141,   141,   141,
     141,   141,   141,   141,   141,   141,   141,   141,   141,   141,
     141,   141,   141,   141,   141,   141,   141,   141,   141,   141,
     141,   141,   141,   141,   141,   141,   141,   141,   141,   141,
     141,   141,   141,   141,   141,   141,   141,   141,   141,   141,
     141,   141,   141,   141,   141,   141,   141,   141,   141,   141,
     141,   141,   141,   141,   141,   141,   141,   141,   141,   141,
     141,   141,   141,   141,   141,   141,   141,   141,   141,   141,
     141,   141,   141,   141,   141,   141,   141,   141,   141,   141,
     141,   141,   141,   141,   141,   141,   141,   141,   141,   141,
     141,   141,   141,   141,   141,   141,   141,   141,   141,   141,
     141,   141,   141,   141,   141,   141,   141,   141,   141,   141,
     141,   141,   141,   141,   141,   141,   141,   141,   141,   141,
     141,   141,   141,   141,   141,   141,   141,   141,   141,   141,
     141,   141,   141,   141,   141,   141,   141,   141,   141,   141,
     141,   141,   141,   141,   141,   141,   141,   141,   141,   141,
     141,   141,   141,   141,   141,   141,   141,   141,   141,   141,
     141,   141,   141,   141,   141,   141,   141,   141,   141,   141,
     141,   141,   141,   141,   141,   141,   141,   141,   141,   141,
     144,   144,   145,   145,   145,   145,   145,   146,   145,   147,
     147,   148,   148,   148,   149,   149,   149,   149,   149,   149,
     150,   150,   150,   151,   151,   152,   152,   152,   153,   153,
     154,   154,   154,   155,   155,   156,   156,   156,   157,   157,
     157,   158,   158,   158,   158,   158,   158,   159,   159,   159,
     160,   160,   160,   160,   160,   160,   160,   160,   160,   160,
     160,   160,   160,   160,   160,   160,   160,   160,   160,   160,
     160,   160,   160,   160,   160,   161,   161,   162,   162,   163,
     163,   163
};

/* YYR2[YYN] -- Number of symbols composing right hand side of rule YYN. */
static const short yyr2[] =
{
       0,     0,     3,     4,     4,     0,     2,     3,     0,     6,
       0,     6,     3,     6,     1,     1,     1,     1,     2,     4,
       4,     4,     4,     4,     4,     4,     4,     4,     4,     4,
       4,     4,     4,     4,     4,     4,     1,     2,     2,     4,
       4,     4,     4,     4,     4,     4,     4,     4,     4,     4,
       4,     4,     4,     4,     4,     4,     4,     2,     2,     2,
       2,     4,     4,     2,     1,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     4,     4,     4,     4,     4,     4,
       4,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     4,     4,     4,     4,     6,     6,     6,
       6,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       4,     4,     4,     4,     4,     4,     2,     2,     4,     4,
       4,     4,     4,     4,     4,     4,     4,     4,     4,     4,
       4,     4,     4,     4,     4,     4,     4,     4,     4,     4,
       4,     4,     4,     4,     4,     4,     4,     4,     4,     4,
       4,     4,     4,     2,     4,     4,     4,     4,     4,     4,
       4,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     1,     2,     1,     2,     1,     2,
       1,     2,     2,     2,     4,     4,     4,     4,     4,     4,
       4,     4,     4,     4,     4,     4,     6,     6,     6,     6,
       6,     6,     6,     6,     6,     6,     6,     6,     6,     6,
       6,     6,     1,     1,     4,     4,     4,     4,     4,     4,
       4,     4,     4,     4,     4,     4,     4,     4,     4,     2,
       2,     4,     4,     4,     4,     4,     4,     4,     4,     4,
       0,     3,     0,     2,     3,     2,     1,     0,     3,     0,
       3,     0,     1,     3,     1,     3,     1,     3,     1,     3,
       1,     1,     3,     1,     3,     1,     2,     3,     1,     3,
       1,     2,     3,     1,     3,     4,     3,     5,     1,     3,
       3,     3,     1,     1,     1,     1,     1,     3,     3,     3,
       1,     1,     1,     3,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     3,
       3,     2,     2,     2,     3,     1,     1,     2,     1,     2,
       2,     0
};

/* YYDEFACT[S] -- default rule to reduce with in state S when YYTABLE
   doesn't specify something else to do.  Zero means the default is an
   error. */
static const short yydefact[] =
{
       1,     0,    14,   325,   326,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,    15,    16,    36,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,    17,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,    64,   184,   186,   188,
     190,   222,   223,     0,     0,     0,     0,     0,     0,     0,
       0,    18,   301,   295,     0,   300,     0,   292,   293,     0,
     302,     0,     0,     0,     0,     0,     0,   294,   296,   292,
     293,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   112,   113,   114,   127,   192,   193,     0,     0,     0,
       0,   292,   293,     0,     0,   292,   293,     0,    37,   292,
     293,     0,   101,   103,   105,   102,   106,   104,   108,   107,
     110,   109,     0,    38,   292,     0,     0,     0,     0,     0,
       0,     0,   301,   295,    58,    59,    57,    60,   296,     0,
      63,   271,   273,    65,   270,   331,   283,    67,   280,    68,
      70,    71,    69,    73,    72,   331,   278,    66,   275,     0,
       0,     0,     0,     0,    81,    83,    84,    82,    86,    85,
     111,     0,     0,   115,   117,   118,   116,   119,   296,     0,
       0,     0,     0,   126,     0,     0,   292,   293,     0,     0,
       0,     0,     0,     0,     0,     0,    87,    89,    91,    88,
      92,    90,   163,     0,     0,   171,   172,   173,   174,   175,
     176,   177,   178,   295,   179,   296,   182,   181,   180,   183,
     185,   187,   189,   191,     0,   292,   293,     0,     0,     0,
       0,   240,   239,     0,   292,   293,     0,     2,     0,     0,
       6,   321,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   288,   322,   323,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     8,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   281,     0,     0,   276,     0,
       0,    10,     0,     0,     0,     0,     4,     3,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     327,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     7,    12,    21,    23,    20,    26,    28,    25,
     299,   297,    31,    33,    30,     0,   291,   324,     0,     0,
       0,   286,    22,    27,    32,     0,   303,   304,   305,   306,
     307,   308,   310,   309,   313,   312,   311,   314,   315,   316,
     317,   298,   318,   319,   320,    19,   331,   328,    29,    24,
     130,   131,   157,   158,   159,   160,   161,   162,   195,   194,
     199,   198,   203,   202,   197,   196,     0,     0,   205,     0,
       0,   204,   201,   200,     0,     0,     0,     0,    42,    46,
      44,    48,    43,    45,    47,   250,    39,    34,    35,    40,
      41,    49,    50,    51,    52,    53,    54,    55,    56,    61,
      62,   274,   272,   329,   330,   284,   282,   279,   277,   259,
      74,    78,    75,    79,    76,    80,    77,   120,   121,   122,
     123,   124,   125,   128,   129,   134,   136,   133,   139,   148,
     141,   138,   144,   154,   155,   156,   146,   143,   150,   149,
     151,   152,   153,   135,   140,   145,   147,   132,   142,   137,
      93,    95,    94,    96,   164,   168,   169,   170,   165,   166,
     167,   226,   228,   225,   231,   233,   230,   236,   238,   235,
     227,   232,   237,   224,   234,   229,   241,   242,   244,   245,
     247,   248,   243,   246,   249,     0,     0,   289,   290,   285,
       0,     0,     0,     0,     0,     0,     0,     0,   252,   261,
       0,     0,     0,     0,     0,   287,   207,   206,   211,   210,
     209,   208,   213,   212,   215,   214,   219,   218,   217,   216,
     221,   220,     0,   264,   268,   266,     9,     0,   256,   257,
      11,     0,   262,    97,    99,    98,   100,    13,   255,     0,
       0,     0,   251,     0,   253,     0,   260,     0,   265,   269,
     267,   254,   258,   263,     0,     0
};

static const short yydefgoto[] =
{
       1,    99,   485,   509,   598,   627,   645,   599,   631,   628,
     182,   183,   196,   197,   186,   187,   115,   290,   116,   117,
     118,   100,   256,   390
};

static const short yypact[] =
{
  -32768,  1670,-32768,-32768,-32768,  -120,   101,   659,   659,   659,
      37,    79,   152,     0,   202,   202,   202,   202,   232,    43,
     659,   671,   659,   692,-32768,-32768,  1560,   704,   204,   659,
     659,   659,   722,   752,   202,  1560,   786,   195,-32768,   199,
     238,   819,   659,  1560,    -8,   831,   135,   218,   659,   659,
     659,  1279,   202,  1560,   221,   225,   659,   659,   659,  1560,
     -16,   202,   849,   659,  1560,    14,   250,    19,    17,    65,
     659,   659,   659,   228,   659,   659,   659,  1560,  1310,   241,
     659,   659,   260,   867,  1560,   867,-32768,  1560,  1560,  1560,
    1560,-32768,-32768,   513,   659,   659,   659,   -12,   532,   -79,
      -6,-32768,-32768,-32768,  1560,-32768,   -55,   -46,     5,   -31,
  -32768,  1560,  1260,  1560,  1560,   -32,    21,-32768,  1637,-32768,
      15,    18,    40,    52,    56,    61,    67,    78,    86,   103,
     128,-32768,-32768,-32768,-32768,-32768,-32768,   137,   156,   158,
     186,   224,    16,   229,   234,   248,    44,   249,  2365,   266,
      47,   273,-32768,-32768,-32768,-32768,-32768,-32768,    42,-32768,
      42,-32768,    69,  1815,   278,   280,   281,   282,   284,   285,
     287,   298,   144,   206,    42,-32768,-32768,-32768,  2035,  2053,
  -32768,-32768,-32768,   303,  2125,   267,-32768,   304,  2143,-32768,
  -32768,-32768,-32768,-32768,-32768,   267,-32768,   305,  2234,   222,
    1833,   321,   329,   330,-32768,-32768,-32768,-32768,-32768,-32768,
    2365,   271,   295,-32768,    42,-32768,-32768,-32768,  2071,  2089,
     331,   332,   333,-32768,   334,   335,   336,    57,   -98,   337,
     338,   339,   342,   343,   344,   345,-32768,   346,   347,-32768,
  -32768,-32768,  1851,   357,  1869,-32768,-32768,-32768,-32768,-32768,
  -32768,-32768,-32768,    99,-32768,  2107,-32768,  2365,-32768,-32768,
    2365,  2365,  2365,  2365,   358,   361,    58,   362,   363,   368,
     369,-32768,-32768,   373,   376,    94,   380,-32768,  1560,   202,
  -32768,-32768,   544,   879,  1560,  1560,   909,   917,  1887,   198,
     140,-32768,-32768,-32768,   288,  1260,  1560,  1560,  1560,  1560,
    1560,  1560,  1560,  1560,  1560,  1560,  1560,  1560,  1560,  1560,
    1560,  1324,  1560,  1560,  1560,  1322,  1322,   659,   659,   122,
     299,   659,   659,   659,  1341,  1344,  1356,  1375,   406,   327,
      27,  1377,   435,   454,   315,  1560,  1387,  1397,    87,-32768,
    1560,   492,   493,   659,   659,   947,   964,   994,  1006,  1322,
    1322,   831,  1560,  1560,  1560,-32768,   135,  1560,-32768,  1279,
    1560,-32768,  1560,  1405,  1408,  1419,-32768,-32768,  1322,  1322,
    1040,   659,   659,  1085,   577,  1121,   395,  1133,   495,   496,
     497,   214,  1560,  1322,  1322,  1163,  1171,  1560,   291,   312,
  -32768,   607,  1183,  1201,   348,  1560,  1322,  1322,   628,  1213,
    1248,   359,  2365,   394,-32768,-32768,  1797,    42,-32768,-32768,
    2365,  1931,     6,-32768,-32768,  1260,-32768,-32768,  1260,  1260,
    1560,-32768,-32768,-32768,-32768,   150,  1961,  1961,  1961,   433,
     433,  1944,  1944,  1944,  1944,  1944,  1944,   197,   197,   385,
     385,-32768,-32768,-32768,-32768,  2365,   267,  2365,-32768,-32768,
  -32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,  2365,
  -32768,  2365,-32768,  2365,-32768,  2365,   402,   403,-32768,   409,
     411,  2365,-32768,  2365,   414,   415,   417,   418,-32768,  2365,
  -32768,  2365,-32768,-32768,  2365,-32768,  2365,-32768,-32768,-32768,
  -32768,    42,-32768,     6,-32768,    42,-32768,     6,-32768,-32768,
  -32768,-32768,  2365,  2365,  2365,-32768,  2365,-32768,  2365,-32768,
    2365,-32768,  2365,-32768,  2365,-32768,  2365,-32768,-32768,    42,
  -32768,-32768,-32768,    42,-32768,-32768,-32768,  1797,    42,   -31,
  -32768,-32768,     6,-32768,-32768,-32768,-32768,-32768,    42,-32768,
  -32768,-32768,-32768,-32768,-32768,-32768,-32768,  2365,-32768,-32768,
     243,   419,   -11,   420,  2365,-32768,-32768,-32768,-32768,-32768,
  -32768,-32768,-32768,  1797,    42,-32768,-32768,     6,-32768,-32768,
  -32768,-32768,-32768,  2365,-32768,-32768,-32768,-32768,    42,-32768,
       6,-32768,-32768,-32768,-32768,  1560,   155,-32768,  1931,-32768,
    1427,  1439,  1449,  1466,  1485,  1502,  1529,  1548,   328,    13,
    1560,  1560,  1560,  1560,  1905,-32768,-32768,  2365,-32768,  2365,
  -32768,  2365,-32768,  2365,-32768,  2365,-32768,  2365,-32768,  2365,
  -32768,  2365,   202,  1560,  1560,  1560,-32768,   398,-32768,   -53,
  -32768,   399,   546,  2365,  2365,  2365,  2365,-32768,-32768,  2252,
    2270,  2288,-32768,   202,-32768,   -69,-32768,  1560,-32768,-32768,
  -32768,-32768,-32768,  2365,   557,-32768
};

static const short yypgoto[] =
{
  -32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,   -80,
     215,-32768,   208,-32768,   212,-32768,   114,  -267,   -73,-32768,
      -2,   -14,   126,  -177
};


#define	YYLAST		2387


static const short yytable[] =
{
     131,   132,   133,   134,   278,   284,   623,   624,   355,   285,
     211,   643,   101,   625,   271,   212,     3,     4,   358,   272,
     162,   284,   284,   180,   148,   285,   285,   176,   425,   130,
     102,   284,   284,   163,   287,   285,   285,   377,   199,   291,
     178,   179,   220,   184,   188,   224,   104,   213,   216,   198,
     223,   200,   277,   105,   468,   469,   470,   210,   279,   110,
     284,   218,   219,   284,   285,   124,   125,   285,   102,   103,
     137,   138,   139,   284,   284,   242,   244,   285,   285,   644,
     282,   255,   257,   255,   104,   260,   261,   262,   263,   283,
     102,   105,   225,   226,   227,   228,   630,   110,   229,   230,
     231,   287,   281,   294,   102,   103,   104,   126,   127,   288,
     284,   292,   293,   105,   285,   482,   483,   353,   354,   110,
     104,   121,   122,   123,   602,  -293,   280,   105,   106,   107,
     108,   109,   136,   110,   140,   143,   144,   147,   102,   185,
     286,   151,  -293,   155,   156,   157,   159,   161,   586,   452,
     165,   329,   587,   314,   104,   175,   177,   295,   419,   420,
     111,   105,   192,   193,   194,   113,   114,   110,   419,   420,
     207,   208,   209,   419,   420,   315,   215,   217,  -292,   333,
     128,   129,   337,   232,   233,   234,   235,   316,   239,   240,
     241,   317,   376,   393,   248,   249,   318,   254,   111,   258,
     339,   112,   319,   113,   114,     3,     4,   267,   268,   269,
     270,   259,   276,   320,   416,   309,   310,   335,   312,   313,
     111,   321,   291,   166,   167,   113,   114,   168,   169,   400,
    -331,   152,   153,   154,   111,   102,   103,   112,   322,   113,
     114,   543,   544,   545,   546,   189,   190,   191,   201,   202,
     203,   104,   204,   205,   206,   236,   237,   238,   105,   135,
     119,   120,   109,   323,   110,   403,   170,   171,   111,   245,
     246,   247,   324,   113,   114,  -325,   402,   421,   221,   222,
     406,   255,   410,   411,   255,   353,   354,   589,   250,   251,
     252,   325,   605,   326,   426,   427,   428,   429,   430,   431,
     432,   433,   434,   435,   436,   437,   438,   439,   440,   442,
     443,   444,   445,   447,   447,   422,   423,   424,   555,   556,
     557,   327,   459,   461,   463,   465,   453,   454,   471,   473,
     418,     3,     4,   442,   479,   481,   484,  -326,   486,   558,
     559,   560,   291,   476,   477,   416,   291,   447,   447,   184,
     502,   503,   504,   361,   188,   506,   467,   198,   508,   328,
     510,   512,   514,   516,   330,   111,   447,   447,   112,   331,
     113,   114,   527,   255,   255,   570,   571,   572,   600,  -292,
     547,   447,   447,   332,   334,   554,   582,   583,   584,   563,
     255,   255,   622,   573,   447,   447,   405,   408,   102,   253,
     413,   336,   366,   623,   624,   335,   312,   313,   338,   409,
     625,   626,   414,   341,   104,   342,   343,   344,   588,   345,
     346,   105,   347,   119,   532,   109,   367,   110,   533,   534,
     535,   450,   451,   348,   466,   455,   456,   457,   351,   356,
     359,   448,   449,   301,   302,   303,   304,   305,   306,   307,
     308,   309,   310,   335,   312,   313,   363,   489,   490,   492,
     494,   496,   498,   474,   364,   365,   370,   371,   372,   373,
     374,   375,   378,   379,   380,   499,   500,   381,   382,   383,
     384,   385,   386,   475,   520,   521,   522,   524,   526,   530,
     536,   539,   388,   391,   517,   518,   392,   394,   395,   551,
     553,   531,   537,   396,   397,   562,   565,   568,   398,   548,
     549,   399,   577,   579,   581,   401,   102,   103,   566,   569,
     487,   488,   574,   575,   540,   541,   542,   585,   111,   642,
     646,   112,   104,   113,   114,   102,   103,   590,   591,   105,
     264,   265,   266,   109,   592,   110,   593,   102,   103,   594,
     595,   104,   596,   597,   601,   603,   647,   655,   105,   273,
     274,   275,   109,   104,   110,   652,   501,   507,   505,     0,
     105,   404,   119,   120,   109,     0,   110,     0,     0,     0,
     102,   103,     0,   604,   629,   632,     0,     0,   607,   609,
     611,   613,   615,   617,   619,   621,   104,     0,   633,   634,
     635,   636,     0,   105,   525,   119,   120,   109,   638,   110,
     102,   103,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   639,   640,   641,     0,     0,   104,     0,     0,   651,
       0,   102,   103,   105,   561,   119,   120,   109,     0,   110,
       0,     0,     0,     0,     0,   653,   111,   104,     0,   112,
       0,   113,   114,     0,   105,   576,   119,   120,   109,     0,
     110,     0,   102,   103,     0,   111,     0,     0,   112,     0,
     113,   114,     0,     0,   102,   103,     0,   111,   104,     0,
     112,     0,   113,   114,     0,   105,     0,   119,   120,   109,
     104,   110,     0,     0,     0,   102,   103,   105,     0,   141,
     142,   109,     0,   110,     0,     0,     0,   102,   103,     0,
     111,   104,     0,   112,     0,   113,   114,     0,   105,     0,
     145,   146,   109,   104,   110,   102,   103,     0,     0,     0,
     105,     0,   149,   150,   109,     0,   110,     0,     0,     0,
     111,   104,     0,   112,     0,   113,   114,     0,   105,     0,
     158,   120,   109,     0,   110,   102,   103,     0,     0,     0,
       0,   111,     0,     0,   112,     0,   113,   114,     0,     0,
       0,   104,     0,     0,     0,     0,     0,     0,   105,     0,
     160,   120,   109,     0,   110,     0,     0,     0,     0,   102,
     103,     0,   111,     0,     0,   112,     0,   113,   114,     0,
       0,     0,     0,     0,   111,   104,     0,   112,     0,   113,
     114,     0,   105,     0,   164,   120,   109,     0,   110,     0,
       0,     0,   172,   173,     0,   111,     0,     0,   112,     0,
     113,   114,     0,     0,   102,     0,     0,   111,   104,     0,
     112,     0,   113,   114,     0,   105,     0,   174,   120,   109,
     104,   110,   172,   173,     0,   111,     0,   105,   112,     0,
     113,   114,   181,   110,     0,     0,     0,     0,   104,     0,
     102,   253,     0,     0,     0,   105,     0,   214,   120,   109,
       0,   110,   102,   253,     0,   111,   104,     0,   112,     0,
     113,   114,     0,   105,     0,   119,   120,   109,   104,   110,
       0,     0,     0,     0,     0,   105,     0,   407,   120,   109,
       0,   110,   102,   253,     0,     0,     0,     0,     0,   111,
     102,   103,   112,     0,   113,   114,     0,     0,   104,     0,
       0,     0,     0,     0,     0,   105,   104,   119,   412,   109,
       0,   110,     0,   105,     0,   119,   120,   289,     0,   110,
     102,   103,   111,     0,     0,   112,     0,   113,   114,     0,
       0,     0,     0,     0,   111,     0,   104,   102,   103,   113,
     114,     0,     0,   105,     0,   491,   120,   109,     0,   110,
       0,     0,   111,   104,     0,   112,     0,   113,   114,     0,
     105,     0,   119,   493,   109,     0,   110,   102,   103,     0,
     111,     0,     0,   112,     0,   113,   114,     0,     0,   102,
     103,     0,   111,   104,     0,   112,     0,   113,   114,     0,
     105,     0,   495,   120,   109,   104,   110,     0,     0,     0,
       0,     0,   105,     0,   119,   497,   109,     0,   110,     0,
       0,     0,   111,   102,   103,   112,     0,   113,   114,     0,
     111,     0,     0,   415,     0,   113,   114,     0,     0,   104,
       0,     0,     0,     0,     0,     0,   105,     0,   519,   120,
     109,     0,   110,     0,     0,     0,     0,     0,     0,     0,
     111,     0,     0,   112,     0,   113,   114,     0,   102,   103,
       0,     0,     0,     0,     0,     0,     0,   111,     0,     0,
     112,     0,   113,   114,   104,     0,     0,     0,     0,     0,
       0,   105,     0,   523,   120,   109,     0,   110,     0,     0,
       0,     0,     0,     0,   102,   253,     0,   111,     0,     0,
     112,     0,   113,   114,     0,     0,   102,   103,     0,   111,
     104,     0,   112,     0,   113,   114,     0,   105,     0,   528,
     120,   529,   104,   110,     0,     0,     0,     0,     0,   105,
       0,   538,   120,   109,     0,   110,   102,   103,     0,     0,
       0,     0,     0,   111,   102,   103,   112,     0,   113,   114,
       0,     0,   104,     0,     0,     0,   102,   253,     0,   105,
     104,   550,   120,   109,     0,   110,     0,   105,     0,   119,
     552,   109,   104,   110,   102,   253,     0,     0,     0,   105,
       0,   564,   120,   109,     0,   110,   102,   103,   111,     0,
     104,   112,     0,   113,   114,     0,     0,   105,     0,   119,
     567,   109,   104,   110,     0,     0,     0,     0,     0,   105,
       0,   578,   120,   109,     0,   110,     0,     0,     0,     0,
       0,   102,   103,     0,   111,     0,     0,   112,     0,   113,
     114,     0,     0,   102,   103,     0,   111,   104,     0,   112,
       0,   113,   114,     0,   105,     0,   119,   580,   109,   104,
     110,     0,   102,   195,     0,     0,   105,     0,   119,   120,
     289,     0,   110,     0,     0,     0,   111,     0,   104,   112,
       0,   113,   114,     0,   111,   105,     0,   112,     0,   113,
     114,   110,     0,   102,     0,     0,   111,     0,     0,   112,
       0,   113,   114,     0,     0,   102,   446,   102,     0,   104,
       0,     0,     0,     0,   111,     0,   105,   112,   243,   113,
     114,   104,   110,   104,   102,     0,   111,   102,   105,   112,
     105,   113,   114,   441,   110,     0,   110,     0,     0,   102,
     104,     0,     0,   104,     0,     0,     0,   105,   458,     0,
     105,   460,     0,   110,     0,   104,   110,     0,   102,     0,
     102,   111,   105,   462,   112,     0,   113,   114,   110,     0,
     102,     0,     0,   111,   104,     0,   104,     0,   113,   114,
     102,   105,   464,   105,   472,     0,   104,   110,   102,   110,
       0,   102,   111,   105,     0,   478,   104,   113,   114,   110,
       0,     0,   102,   105,   104,     0,   480,   104,     0,   110,
     102,   105,     0,   511,   105,     0,   513,   110,   104,     0,
     110,     0,   102,   111,     0,   105,   104,   515,   113,   114,
       0,   110,   102,   105,   606,   111,     0,   111,   104,   110,
     113,   114,   113,   114,     0,   105,   608,     0,   104,   102,
       0,   110,     0,     0,   111,   105,   610,   111,     0,   113,
     114,   110,   113,   114,     0,   104,     0,     0,   102,   111,
       0,     0,   105,   612,   113,   114,     0,     0,   110,     0,
       0,     0,     0,     0,   104,   102,     0,     0,   111,     0,
     111,   105,   614,   113,   114,   113,   114,   110,     0,     0,
     111,   104,     0,     0,     0,   113,   114,     0,   105,   616,
     111,     0,   102,     0,   110,   113,   114,     0,   111,     0,
       0,   111,     0,   113,   114,     0,   113,   114,   104,     0,
       0,   102,   111,     0,     0,   105,   618,   113,   114,     0,
     111,   110,     0,   102,     0,   113,   114,   104,     0,     0,
       0,     0,   111,     0,   105,   620,     0,   113,   114,   104,
     110,     0,   111,     0,     0,     0,   105,   113,   114,     0,
       0,     0,   110,     0,     0,     0,     0,     0,     0,   111,
       0,     0,     0,     0,   113,   114,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   111,     0,
       0,     0,     0,   113,   114,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   111,     0,     0,     0,     0,
     113,   114,   296,   297,   298,   299,   300,   301,   302,   303,
     304,   305,   306,   307,   308,   309,   310,   311,   312,   313,
       0,     0,   111,     0,     0,     0,     0,   113,   114,     0,
     654,     2,     0,     3,     4,     0,     0,     0,     0,     0,
       0,   111,     0,     0,     0,     0,   113,   114,     0,     0,
       0,     0,     0,   111,     0,     0,     0,     0,   113,   114,
       5,     0,     0,     0,     0,     0,     6,     7,     8,     9,
      10,    11,    12,    13,    14,    15,    16,    17,    18,    19,
      20,    21,    22,    23,    24,    25,    26,    27,    28,    29,
      30,    31,    32,    33,    34,    35,    36,    37,    38,    39,
      40,    41,    42,    43,    44,    45,    46,    47,    48,    49,
      50,     0,    51,     0,    52,    53,    54,    55,    56,    57,
      58,    59,    60,    61,    62,    63,    64,    65,    66,    67,
      68,    69,    70,    71,    72,    73,    74,    75,    76,    77,
      78,    79,    80,    81,    82,    83,    84,    85,    86,    87,
      88,    89,    90,    91,    92,    93,    94,    95,    96,    97,
      98,    -5,   296,   297,   298,   299,   300,   301,   302,   303,
     304,   305,   306,   307,   308,   309,   310,   311,   312,   313,
     296,   297,   298,   299,   300,   301,   302,   303,   304,   305,
     306,   307,   308,   309,   310,   335,   312,   313,   296,   297,
     298,   299,   300,   301,   302,   303,   304,   305,   306,   307,
     308,   309,   310,   335,   312,   313,   296,   297,   298,   299,
     300,   301,   302,   303,   304,   305,   306,   307,   308,   309,
     310,   335,   312,   313,   296,   297,   298,   299,   300,   301,
     302,   303,   304,   305,   306,   307,   308,   309,   310,   335,
     312,   313,   296,   297,   298,   299,   300,   301,   302,   303,
     304,   305,   306,   307,   308,   309,   310,   335,   312,   313,
     296,   297,   298,   299,   300,   301,   302,   303,   304,   305,
     306,   307,   308,   309,   310,   335,   312,   313,     0,     0,
       0,     0,     0,  -296,     0,     0,   296,   297,   298,   299,
     300,   301,   302,   303,   304,   305,   306,   307,   308,     0,
     340,   335,   312,   313,-32768,-32768,-32768,-32768,-32768,-32768,
     307,   308,   309,   310,   335,   312,   313,     0,   362,   299,
     300,   301,   302,   303,   304,   305,   306,   307,   308,   309,
     310,   335,   312,   313,     0,     0,   387,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   389,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   417,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   637,
     296,   297,   298,   299,   300,   301,   302,   303,   304,   305,
     306,   307,   308,   309,   310,   311,   312,   313,   296,   297,
     298,   299,   300,   301,   302,   303,   304,   305,   306,   307,
     308,   309,   310,   335,   312,   313,   296,   297,   298,   299,
     300,   301,   302,   303,   304,   305,   306,   307,   308,   309,
     310,   311,   312,   313,   296,   297,   298,   299,   300,   301,
     302,   303,   304,   305,   306,   307,   308,   309,   310,   335,
     312,   313,   296,   297,   298,   299,   300,   301,   302,   303,
     304,   305,   306,   307,   308,   309,   310,   311,   312,   313,
     296,   297,   298,   299,   300,   301,   302,   303,   304,   305,
     306,   307,   308,   309,   310,   335,   312,   313,   296,   297,
     298,   299,   300,   301,   302,   303,   304,   305,   306,   307,
     308,   309,   310,   335,   312,   313,     0,   349,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   350,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   368,     0,     0,   352,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   369,     0,     0,   357,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,  -328,   296,
     297,   298,   299,   300,   301,   302,   303,   304,   305,   306,
     307,   308,   309,   310,   335,   312,   313,   296,   297,   298,
     299,   300,   301,   302,   303,   304,   305,   306,   307,   308,
     309,   310,   335,   312,   313,   296,   297,   298,   299,   300,
     301,   302,   303,   304,   305,   306,   307,   308,   309,   310,
     335,   312,   313,   296,   297,   298,   299,   300,   301,   302,
     303,   304,   305,   306,   307,   308,   309,   310,   335,   312,
     313,     0,     0,     0,     0,   360,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   648,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   649,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   650,
     296,   297,   298,   299,   300,   301,   302,   303,   304,   305,
     306,   307,   308,   309,   310,   335,   312,   313
};

static const short yycheck[] =
{
      14,    15,    16,    17,    10,    16,    75,    76,   185,    20,
      26,    64,   132,    82,    26,    31,     3,     4,   195,    31,
      34,    16,    16,    31,    26,    20,    20,    41,   295,    29,
       3,    16,    16,    35,   132,    20,    20,   135,    52,   112,
      42,    43,    28,    45,    46,    28,    19,    61,    62,    51,
      31,    53,   131,    26,    27,    28,    29,    59,    64,    32,
      16,    63,    64,    16,    20,    28,    29,    20,     3,     4,
      27,    28,    29,    16,    16,    77,    78,    20,    20,   132,
     135,    83,    84,    85,    19,    87,    88,    89,    90,   135,
       3,    26,    27,    28,    29,    30,    83,    32,    33,    34,
      35,   132,   104,   135,     3,     4,    19,    28,    29,   111,
      16,   113,   114,    26,    20,    28,    29,    18,    19,    32,
      19,     7,     8,     9,   135,   136,   132,    26,    27,    28,
      29,    30,    18,    32,    20,    21,    22,    23,     3,     4,
     135,    27,   136,    29,    30,    31,    32,    33,   415,    27,
      36,   135,   419,   135,    19,    41,    42,   136,    18,    19,
     133,    26,    48,    49,    50,   138,   139,    32,    18,    19,
      56,    57,    58,    18,    19,   135,    62,    63,   136,   135,
      28,    29,   135,    69,    70,    71,    72,   135,    74,    75,
      76,   135,   135,   135,    80,    81,   135,    83,   133,    85,
     131,   136,   135,   138,   139,     3,     4,    93,    94,    95,
      96,    85,    98,   135,   287,    18,    19,    20,    21,    22,
     133,   135,   295,    28,    29,   138,   139,    28,    29,   135,
     131,    27,    28,    29,   133,     3,     4,   136,   135,   138,
     139,    27,    28,    29,    30,    27,    28,    29,    27,    28,
      29,    19,    27,    28,    29,    27,    28,    29,    26,    27,
      28,    29,    30,   135,    32,   279,    28,    29,   133,    28,
      29,    30,   135,   138,   139,   131,   278,   137,    28,    29,
     282,   283,   284,   285,   286,    18,    19,   137,    28,    29,
      30,   135,   137,   135,   296,   297,   298,   299,   300,   301,
     302,   303,   304,   305,   306,   307,   308,   309,   310,   311,
     312,   313,   314,   315,   316,    27,    28,    29,    27,    28,
      29,   135,   324,   325,   326,   327,    27,    28,   330,   331,
     132,     3,     4,   335,   336,   337,   338,   131,   340,    27,
      28,    29,   415,    28,    29,   418,   419,   349,   350,   351,
     352,   353,   354,   131,   356,   357,    29,   359,   360,   135,
     362,   363,   364,   365,   135,   133,   368,   369,   136,   135,
     138,   139,   374,   375,   376,    27,    28,    29,   135,   136,
     382,   383,   384,   135,   135,   387,    27,    28,    29,   391,
     392,   393,    64,   395,   396,   397,   282,   283,     3,     4,
     286,   135,   131,    75,    76,    20,    21,    22,   135,   283,
      82,    83,   286,   135,    19,   135,   135,   135,   420,   135,
     135,    26,   135,    28,    29,    30,   131,    32,    33,    34,
      35,   317,   318,   135,    28,   321,   322,   323,   135,   135,
     135,   315,   316,    10,    11,    12,    13,    14,    15,    16,
      17,    18,    19,    20,    21,    22,   135,   343,   344,   345,
     346,   347,   348,    28,   135,   135,   135,   135,   135,   135,
     135,   135,   135,   135,   135,   349,   350,   135,   135,   135,
     135,   135,   135,    29,   370,   371,   372,   373,   374,   375,
     376,   377,   135,   135,   368,   369,   135,   135,   135,   385,
     386,   375,   376,   135,   135,   391,   392,   393,   135,   383,
     384,   135,   398,   399,   400,   135,     3,     4,   392,   393,
      28,    28,   396,   397,    29,    29,    29,   133,   133,   131,
     131,   136,    19,   138,   139,     3,     4,   135,   135,    26,
      27,    28,    29,    30,   135,    32,   135,     3,     4,   135,
     135,    19,   135,   135,   135,   135,    10,     0,    26,    27,
      28,    29,    30,    19,    32,   645,   351,   359,   356,    -1,
      26,    27,    28,    29,    30,    -1,    32,    -1,    -1,    -1,
       3,     4,    -1,   585,   598,   599,    -1,    -1,   590,   591,
     592,   593,   594,   595,   596,   597,    19,    -1,   600,   601,
     602,   603,    -1,    26,    27,    28,    29,    30,   622,    32,
       3,     4,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   623,   624,   625,    -1,    -1,    19,    -1,    -1,   643,
      -1,     3,     4,    26,    27,    28,    29,    30,    -1,    32,
      -1,    -1,    -1,    -1,    -1,   647,   133,    19,    -1,   136,
      -1,   138,   139,    -1,    26,    27,    28,    29,    30,    -1,
      32,    -1,     3,     4,    -1,   133,    -1,    -1,   136,    -1,
     138,   139,    -1,    -1,     3,     4,    -1,   133,    19,    -1,
     136,    -1,   138,   139,    -1,    26,    -1,    28,    29,    30,
      19,    32,    -1,    -1,    -1,     3,     4,    26,    -1,    28,
      29,    30,    -1,    32,    -1,    -1,    -1,     3,     4,    -1,
     133,    19,    -1,   136,    -1,   138,   139,    -1,    26,    -1,
      28,    29,    30,    19,    32,     3,     4,    -1,    -1,    -1,
      26,    -1,    28,    29,    30,    -1,    32,    -1,    -1,    -1,
     133,    19,    -1,   136,    -1,   138,   139,    -1,    26,    -1,
      28,    29,    30,    -1,    32,     3,     4,    -1,    -1,    -1,
      -1,   133,    -1,    -1,   136,    -1,   138,   139,    -1,    -1,
      -1,    19,    -1,    -1,    -1,    -1,    -1,    -1,    26,    -1,
      28,    29,    30,    -1,    32,    -1,    -1,    -1,    -1,     3,
       4,    -1,   133,    -1,    -1,   136,    -1,   138,   139,    -1,
      -1,    -1,    -1,    -1,   133,    19,    -1,   136,    -1,   138,
     139,    -1,    26,    -1,    28,    29,    30,    -1,    32,    -1,
      -1,    -1,     3,     4,    -1,   133,    -1,    -1,   136,    -1,
     138,   139,    -1,    -1,     3,    -1,    -1,   133,    19,    -1,
     136,    -1,   138,   139,    -1,    26,    -1,    28,    29,    30,
      19,    32,     3,     4,    -1,   133,    -1,    26,   136,    -1,
     138,   139,    31,    32,    -1,    -1,    -1,    -1,    19,    -1,
       3,     4,    -1,    -1,    -1,    26,    -1,    28,    29,    30,
      -1,    32,     3,     4,    -1,   133,    19,    -1,   136,    -1,
     138,   139,    -1,    26,    -1,    28,    29,    30,    19,    32,
      -1,    -1,    -1,    -1,    -1,    26,    -1,    28,    29,    30,
      -1,    32,     3,     4,    -1,    -1,    -1,    -1,    -1,   133,
       3,     4,   136,    -1,   138,   139,    -1,    -1,    19,    -1,
      -1,    -1,    -1,    -1,    -1,    26,    19,    28,    29,    30,
      -1,    32,    -1,    26,    -1,    28,    29,    30,    -1,    32,
       3,     4,   133,    -1,    -1,   136,    -1,   138,   139,    -1,
      -1,    -1,    -1,    -1,   133,    -1,    19,     3,     4,   138,
     139,    -1,    -1,    26,    -1,    28,    29,    30,    -1,    32,
      -1,    -1,   133,    19,    -1,   136,    -1,   138,   139,    -1,
      26,    -1,    28,    29,    30,    -1,    32,     3,     4,    -1,
     133,    -1,    -1,   136,    -1,   138,   139,    -1,    -1,     3,
       4,    -1,   133,    19,    -1,   136,    -1,   138,   139,    -1,
      26,    -1,    28,    29,    30,    19,    32,    -1,    -1,    -1,
      -1,    -1,    26,    -1,    28,    29,    30,    -1,    32,    -1,
      -1,    -1,   133,     3,     4,   136,    -1,   138,   139,    -1,
     133,    -1,    -1,   136,    -1,   138,   139,    -1,    -1,    19,
      -1,    -1,    -1,    -1,    -1,    -1,    26,    -1,    28,    29,
      30,    -1,    32,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     133,    -1,    -1,   136,    -1,   138,   139,    -1,     3,     4,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   133,    -1,    -1,
     136,    -1,   138,   139,    19,    -1,    -1,    -1,    -1,    -1,
      -1,    26,    -1,    28,    29,    30,    -1,    32,    -1,    -1,
      -1,    -1,    -1,    -1,     3,     4,    -1,   133,    -1,    -1,
     136,    -1,   138,   139,    -1,    -1,     3,     4,    -1,   133,
      19,    -1,   136,    -1,   138,   139,    -1,    26,    -1,    28,
      29,    30,    19,    32,    -1,    -1,    -1,    -1,    -1,    26,
      -1,    28,    29,    30,    -1,    32,     3,     4,    -1,    -1,
      -1,    -1,    -1,   133,     3,     4,   136,    -1,   138,   139,
      -1,    -1,    19,    -1,    -1,    -1,     3,     4,    -1,    26,
      19,    28,    29,    30,    -1,    32,    -1,    26,    -1,    28,
      29,    30,    19,    32,     3,     4,    -1,    -1,    -1,    26,
      -1,    28,    29,    30,    -1,    32,     3,     4,   133,    -1,
      19,   136,    -1,   138,   139,    -1,    -1,    26,    -1,    28,
      29,    30,    19,    32,    -1,    -1,    -1,    -1,    -1,    26,
      -1,    28,    29,    30,    -1,    32,    -1,    -1,    -1,    -1,
      -1,     3,     4,    -1,   133,    -1,    -1,   136,    -1,   138,
     139,    -1,    -1,     3,     4,    -1,   133,    19,    -1,   136,
      -1,   138,   139,    -1,    26,    -1,    28,    29,    30,    19,
      32,    -1,     3,     4,    -1,    -1,    26,    -1,    28,    29,
      30,    -1,    32,    -1,    -1,    -1,   133,    -1,    19,   136,
      -1,   138,   139,    -1,   133,    26,    -1,   136,    -1,   138,
     139,    32,    -1,     3,    -1,    -1,   133,    -1,    -1,   136,
      -1,   138,   139,    -1,    -1,     3,     4,     3,    -1,    19,
      -1,    -1,    -1,    -1,   133,    -1,    26,   136,    28,   138,
     139,    19,    32,    19,     3,    -1,   133,     3,    26,   136,
      26,   138,   139,    29,    32,    -1,    32,    -1,    -1,     3,
      19,    -1,    -1,    19,    -1,    -1,    -1,    26,    27,    -1,
      26,    27,    -1,    32,    -1,    19,    32,    -1,     3,    -1,
       3,   133,    26,    27,   136,    -1,   138,   139,    32,    -1,
       3,    -1,    -1,   133,    19,    -1,    19,    -1,   138,   139,
       3,    26,    27,    26,    27,    -1,    19,    32,     3,    32,
      -1,     3,   133,    26,    -1,    28,    19,   138,   139,    32,
      -1,    -1,     3,    26,    19,    -1,    29,    19,    -1,    32,
       3,    26,    -1,    28,    26,    -1,    28,    32,    19,    -1,
      32,    -1,     3,   133,    -1,    26,    19,    28,   138,   139,
      -1,    32,     3,    26,    27,   133,    -1,   133,    19,    32,
     138,   139,   138,   139,    -1,    26,    27,    -1,    19,     3,
      -1,    32,    -1,    -1,   133,    26,    27,   133,    -1,   138,
     139,    32,   138,   139,    -1,    19,    -1,    -1,     3,   133,
      -1,    -1,    26,    27,   138,   139,    -1,    -1,    32,    -1,
      -1,    -1,    -1,    -1,    19,     3,    -1,    -1,   133,    -1,
     133,    26,    27,   138,   139,   138,   139,    32,    -1,    -1,
     133,    19,    -1,    -1,    -1,   138,   139,    -1,    26,    27,
     133,    -1,     3,    -1,    32,   138,   139,    -1,   133,    -1,
      -1,   133,    -1,   138,   139,    -1,   138,   139,    19,    -1,
      -1,     3,   133,    -1,    -1,    26,    27,   138,   139,    -1,
     133,    32,    -1,     3,    -1,   138,   139,    19,    -1,    -1,
      -1,    -1,   133,    -1,    26,    27,    -1,   138,   139,    19,
      32,    -1,   133,    -1,    -1,    -1,    26,   138,   139,    -1,
      -1,    -1,    32,    -1,    -1,    -1,    -1,    -1,    -1,   133,
      -1,    -1,    -1,    -1,   138,   139,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   133,    -1,
      -1,    -1,    -1,   138,   139,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,   133,    -1,    -1,    -1,    -1,
     138,   139,     5,     6,     7,     8,     9,    10,    11,    12,
      13,    14,    15,    16,    17,    18,    19,    20,    21,    22,
      -1,    -1,   133,    -1,    -1,    -1,    -1,   138,   139,    -1,
       0,     1,    -1,     3,     4,    -1,    -1,    -1,    -1,    -1,
      -1,   133,    -1,    -1,    -1,    -1,   138,   139,    -1,    -1,
      -1,    -1,    -1,   133,    -1,    -1,    -1,    -1,   138,   139,
      30,    -1,    -1,    -1,    -1,    -1,    36,    37,    38,    39,
      40,    41,    42,    43,    44,    45,    46,    47,    48,    49,
      50,    51,    52,    53,    54,    55,    56,    57,    58,    59,
      60,    61,    62,    63,    64,    65,    66,    67,    68,    69,
      70,    71,    72,    73,    74,    75,    76,    77,    78,    79,
      80,    -1,    82,    -1,    84,    85,    86,    87,    88,    89,
      90,    91,    92,    93,    94,    95,    96,    97,    98,    99,
     100,   101,   102,   103,   104,   105,   106,   107,   108,   109,
     110,   111,   112,   113,   114,   115,   116,   117,   118,   119,
     120,   121,   122,   123,   124,   125,   126,   127,   128,   129,
     130,   131,     5,     6,     7,     8,     9,    10,    11,    12,
      13,    14,    15,    16,    17,    18,    19,    20,    21,    22,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,     5,     6,
       7,     8,     9,    10,    11,    12,    13,    14,    15,    16,
      17,    18,    19,    20,    21,    22,     5,     6,     7,     8,
       9,    10,    11,    12,    13,    14,    15,    16,    17,    18,
      19,    20,    21,    22,     5,     6,     7,     8,     9,    10,
      11,    12,    13,    14,    15,    16,    17,    18,    19,    20,
      21,    22,     5,     6,     7,     8,     9,    10,    11,    12,
      13,    14,    15,    16,    17,    18,    19,    20,    21,    22,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    -1,    -1,
      -1,    -1,    -1,   136,    -1,    -1,     5,     6,     7,     8,
       9,    10,    11,    12,    13,    14,    15,    16,    17,    -1,
     135,    20,    21,    22,    10,    11,    12,    13,    14,    15,
      16,    17,    18,    19,    20,    21,    22,    -1,   135,     8,
       9,    10,    11,    12,    13,    14,    15,    16,    17,    18,
      19,    20,    21,    22,    -1,    -1,   135,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   135,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   134,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   134,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,     5,     6,
       7,     8,     9,    10,    11,    12,    13,    14,    15,    16,
      17,    18,    19,    20,    21,    22,     5,     6,     7,     8,
       9,    10,    11,    12,    13,    14,    15,    16,    17,    18,
      19,    20,    21,    22,     5,     6,     7,     8,     9,    10,
      11,    12,    13,    14,    15,    16,    17,    18,    19,    20,
      21,    22,     5,     6,     7,     8,     9,    10,    11,    12,
      13,    14,    15,    16,    17,    18,    19,    20,    21,    22,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,     5,     6,
       7,     8,     9,    10,    11,    12,    13,    14,    15,    16,
      17,    18,    19,    20,    21,    22,    -1,   132,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,   132,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   132,    -1,    -1,    81,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   132,    -1,    -1,    81,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   131,     5,
       6,     7,     8,     9,    10,    11,    12,    13,    14,    15,
      16,    17,    18,    19,    20,    21,    22,     5,     6,     7,
       8,     9,    10,    11,    12,    13,    14,    15,    16,    17,
      18,    19,    20,    21,    22,     5,     6,     7,     8,     9,
      10,    11,    12,    13,    14,    15,    16,    17,    18,    19,
      20,    21,    22,     5,     6,     7,     8,     9,    10,    11,
      12,    13,    14,    15,    16,    17,    18,    19,    20,    21,
      22,    -1,    -1,    -1,    -1,    81,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    81,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    81,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    81,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22
};
/* -*-C-*-  Note some compilers choke on comments on `#line' lines.  */
#line 3 "c:/djgpp/lib/bison.sim"

/* Skeleton output parser for bison,

   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002 Free Software
   Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330,
   Boston, MA 02111-1307, USA.  */

/* As a special exception, when this file is copied by Bison into a
   Bison output file, you may use that output file without restriction.
   This special exception was added by the Free Software Foundation
   in version 1.24 of Bison.  */

/* This is the parser code that is written into each bison parser when
   the %semantic_parser declaration is not specified in the grammar.
   It was written by Richard Stallman by simplifying the hairy parser
   used when %semantic_parser is specified.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

#if ! defined (yyoverflow) || defined (YYERROR_VERBOSE)

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# if YYSTACK_USE_ALLOCA
#  define YYSTACK_ALLOC alloca
# else
#  ifndef YYSTACK_USE_ALLOCA
#   if defined (alloca) || defined (_ALLOCA_H)
#    define YYSTACK_ALLOC alloca
#   else
#    ifdef __GNUC__
#     define YYSTACK_ALLOC __builtin_alloca
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's `empty if-body' warning. */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (0)
# else
#  if defined (__STDC__) || defined (__cplusplus)
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   define YYSIZE_T size_t
#  endif
#  define YYSTACK_ALLOC malloc
#  define YYSTACK_FREE free
# endif
#endif /* ! defined (yyoverflow) || defined (YYERROR_VERBOSE) */


#if (! defined (yyoverflow) \
     && (! defined (__cplusplus) \
	 || (YYLTYPE_IS_TRIVIAL && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  short yyss;
  YYSTYPE yyvs;
# if YYLSP_NEEDED
  YYLTYPE yyls;
# endif
};

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAX (sizeof (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# if YYLSP_NEEDED
#  define YYSTACK_BYTES(N) \
     ((N) * (sizeof (short) + sizeof (YYSTYPE) + sizeof (YYLTYPE))	\
      + 2 * YYSTACK_GAP_MAX)
# else
#  define YYSTACK_BYTES(N) \
     ((N) * (sizeof (short) + sizeof (YYSTYPE))				\
      + YYSTACK_GAP_MAX)
# endif

/* Copy COUNT objects from FROM to TO.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if 1 < __GNUC__
#   define YYCOPY(To, From, Count) \
      __builtin_memcpy (To, From, (Count) * sizeof (*(From)))
#  else
#   define YYCOPY(To, From, Count)		\
      do					\
	{					\
	  register YYSIZE_T yyi;		\
	  for (yyi = 0; yyi < (Count); yyi++)	\
	    (To)[yyi] = (From)[yyi];		\
	}					\
      while (0)
#  endif
# endif

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack)					\
    do									\
      {									\
	YYSIZE_T yynewbytes;						\
	YYCOPY (&yyptr->Stack, Stack, yysize);				\
	Stack = &yyptr->Stack;						\
	yynewbytes = yystacksize * sizeof (*Stack) + YYSTACK_GAP_MAX;	\
	yyptr += yynewbytes / sizeof (*yyptr);				\
      }									\
    while (0)

#endif


#if ! defined (YYSIZE_T) && defined (__SIZE_TYPE__)
# define YYSIZE_T __SIZE_TYPE__
#endif
#if ! defined (YYSIZE_T) && defined (size_t)
# define YYSIZE_T size_t
#endif
#if ! defined (YYSIZE_T)
# if defined (__STDC__) || defined (__cplusplus)
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# endif
#endif
#if ! defined (YYSIZE_T)
# define YYSIZE_T unsigned int
#endif

#define yyerrok		(yyerrstatus = 0)
#define yyclearin	(yychar = YYEMPTY)
#define YYEMPTY		-2
#define YYEOF		0
#define YYACCEPT	goto yyacceptlab
#define YYABORT 	goto yyabortlab
#define YYERROR		goto yyerrlab1
/* Like YYERROR except do call yyerror.  This remains here temporarily
   to ease the transition to the new meaning of YYERROR, for GCC.
   Once GCC version 2 has supplanted version 1, this can go.  */
#define YYFAIL		goto yyerrlab
#define YYRECOVERING()  (!!yyerrstatus)
#define YYBACKUP(Token, Value)					\
do								\
  if (yychar == YYEMPTY && yylen == 1)				\
    {								\
      yychar = (Token);						\
      yylval = (Value);						\
      yychar1 = YYTRANSLATE (yychar);				\
      YYPOPSTACK;						\
      goto yybackup;						\
    }								\
  else								\
    { 								\
      yyerror ("syntax error: cannot back up");			\
      YYERROR;							\
    }								\
while (0)

#define YYTERROR	1
#define YYERRCODE	256


/* YYLLOC_DEFAULT -- Compute the default location (before the actions
   are run).

   When YYLLOC_DEFAULT is run, CURRENT is set the location of the
   first token.  By default, to implement support for ranges, extend
   its range to the last symbol.  */

#ifndef YYLLOC_DEFAULT
# define YYLLOC_DEFAULT(Current, Rhs, N)       	\
   Current.last_line   = Rhs[N].last_line;	\
   Current.last_column = Rhs[N].last_column;
#endif


/* YYLEX -- calling `yylex' with the right arguments.  */

#if YYPURE
# if YYLSP_NEEDED
#  ifdef YYLEX_PARAM
#   define YYLEX		yylex (&yylval, &yylloc, YYLEX_PARAM)
#  else
#   define YYLEX		yylex (&yylval, &yylloc)
#  endif
# else /* !YYLSP_NEEDED */
#  ifdef YYLEX_PARAM
#   define YYLEX		yylex (&yylval, YYLEX_PARAM)
#  else
#   define YYLEX		yylex (&yylval)
#  endif
# endif /* !YYLSP_NEEDED */
#else /* !YYPURE */
# define YYLEX			yylex ()
#endif /* !YYPURE */


/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)			\
do {						\
  if (yydebug)					\
    YYFPRINTF Args;				\
} while (0)
/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args)
#endif /* !YYDEBUG */

/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef	YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   SIZE_MAX < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#if YYMAXDEPTH == 0
# undef YYMAXDEPTH
#endif

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif

#ifdef YYERROR_VERBOSE

# ifndef yystrlen
#  if defined (__GLIBC__) && defined (_STRING_H)
#   define yystrlen strlen
#  else
/* Return the length of YYSTR.  */
static YYSIZE_T
#   if defined (__STDC__) || defined (__cplusplus)
yystrlen (const char *yystr)
#   else
yystrlen (yystr)
     const char *yystr;
#   endif
{
  register const char *yys = yystr;

  while (*yys++ != '\0')
    continue;

  return yys - yystr - 1;
}
#  endif
# endif

# ifndef yystpcpy
#  if defined (__GLIBC__) && defined (_STRING_H) && defined (_GNU_SOURCE)
#   define yystpcpy stpcpy
#  else
/* Copy YYSRC to YYDEST, returning the address of the terminating '\0' in
   YYDEST.  */
static char *
#   if defined (__STDC__) || defined (__cplusplus)
yystpcpy (char *yydest, const char *yysrc)
#   else
yystpcpy (yydest, yysrc)
     char *yydest;
     const char *yysrc;
#   endif
{
  register char *yyd = yydest;
  register const char *yys = yysrc;

  while ((*yyd++ = *yys++) != '\0')
    continue;

  return yyd - 1;
}
#  endif
# endif
#endif

#line 315 "c:/djgpp/lib/bison.sim"


/* The user can define YYPARSE_PARAM as the name of an argument to be passed
   into yyparse.  The argument should have type void *.
   It should actually point to an object.
   Grammar actions can access the variable by casting it
   to the proper pointer type.  */

#ifdef YYPARSE_PARAM
# if defined (__STDC__) || defined (__cplusplus)
#  define YYPARSE_PARAM_ARG void *YYPARSE_PARAM
#  define YYPARSE_PARAM_DECL
# else
#  define YYPARSE_PARAM_ARG YYPARSE_PARAM
#  define YYPARSE_PARAM_DECL void *YYPARSE_PARAM;
# endif
#else /* !YYPARSE_PARAM */
# define YYPARSE_PARAM_ARG
# define YYPARSE_PARAM_DECL
#endif /* !YYPARSE_PARAM */

/* Prevent warning if -Wstrict-prototypes.  */
#ifdef __GNUC__
# ifdef YYPARSE_PARAM
int yyparse (void *);
# else
int yyparse (void);
# endif
#endif

/* YY_DECL_VARIABLES -- depending whether we use a pure parser,
   variables are global, or local to YYPARSE.  */

#define YY_DECL_NON_LSP_VARIABLES			\
/* The lookahead symbol.  */				\
int yychar;						\
							\
/* The semantic value of the lookahead symbol. */	\
YYSTYPE yylval;						\
							\
/* Number of parse errors so far.  */			\
int yynerrs;

#if YYLSP_NEEDED
# define YY_DECL_VARIABLES			\
YY_DECL_NON_LSP_VARIABLES			\
						\
/* Location data for the lookahead symbol.  */	\
YYLTYPE yylloc;
#else
# define YY_DECL_VARIABLES			\
YY_DECL_NON_LSP_VARIABLES
#endif


/* If nonreentrant, generate the variables here. */

#if !YYPURE
YY_DECL_VARIABLES
#endif  /* !YYPURE */

int
yyparse (YYPARSE_PARAM_ARG)
     YYPARSE_PARAM_DECL
{
  /* If reentrant, generate the variables here. */
#if YYPURE
  YY_DECL_VARIABLES
#endif  /* !YYPURE */

  register int yystate;
  register int yyn;
  int yyresult;
  /* Number of tokens to shift before error messages enabled.  */
  int yyerrstatus;
  /* Lookahead token as an internal (translated) token number.  */
  int yychar1 = 0;

  /* Three stacks and their tools:
     `yyss': related to states,
     `yyvs': related to semantic values,
     `yyls': related to locations.

     Refer to the stacks thru separate pointers, to allow yyoverflow
     to reallocate them elsewhere.  */

  /* The state stack. */
  short	yyssa[YYINITDEPTH];
  short *yyss = yyssa;
  register short *yyssp;

  /* The semantic value stack.  */
  YYSTYPE yyvsa[YYINITDEPTH];
  YYSTYPE *yyvs = yyvsa;
  register YYSTYPE *yyvsp;

#if YYLSP_NEEDED
  /* The location stack.  */
  YYLTYPE yylsa[YYINITDEPTH];
  YYLTYPE *yyls = yylsa;
  YYLTYPE *yylsp;
#endif

#if YYLSP_NEEDED
# define YYPOPSTACK   (yyvsp--, yyssp--, yylsp--)
#else
# define YYPOPSTACK   (yyvsp--, yyssp--)
#endif

  YYSIZE_T yystacksize = YYINITDEPTH;


  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;
#if YYLSP_NEEDED
  YYLTYPE yyloc;
#endif

  /* When reducing, the number of symbols on the RHS of the reduced
     rule. */
  int yylen;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY;		/* Cause a token to be read.  */

  /* Initialize stack pointers.
     Waste one element of value and location stack
     so that they stay on the same level as the state stack.
     The wasted elements are never initialized.  */

  yyssp = yyss;
  yyvsp = yyvs;
#if YYLSP_NEEDED
  yylsp = yyls;
#endif
  goto yysetstate;

/*------------------------------------------------------------.
| yynewstate -- Push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
 yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed. so pushing a state here evens the stacks.
     */
  yyssp++;

 yysetstate:
  *yyssp = yystate;

  if (yyssp >= yyss + yystacksize - 1)
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYSIZE_T yysize = yyssp - yyss + 1;

#ifdef yyoverflow
      {
	/* Give user a chance to reallocate the stack. Use copies of
	   these so that the &'s don't force the real ones into
	   memory.  */
	YYSTYPE *yyvs1 = yyvs;
	short *yyss1 = yyss;

	/* Each stack pointer address is followed by the size of the
	   data in use in that stack, in bytes.  */
# if YYLSP_NEEDED
	YYLTYPE *yyls1 = yyls;
	/* This used to be a conditional around just the two extra args,
	   but that might be undefined if yyoverflow is a macro.  */
	yyoverflow ("parser stack overflow",
		    &yyss1, yysize * sizeof (*yyssp),
		    &yyvs1, yysize * sizeof (*yyvsp),
		    &yyls1, yysize * sizeof (*yylsp),
		    &yystacksize);
	yyls = yyls1;
# else
	yyoverflow ("parser stack overflow",
		    &yyss1, yysize * sizeof (*yyssp),
		    &yyvs1, yysize * sizeof (*yyvsp),
		    &yystacksize);
# endif
	yyss = yyss1;
	yyvs = yyvs1;
      }
#else /* no yyoverflow */
# ifndef YYSTACK_RELOCATE
      goto yyoverflowlab;
# else
      /* Extend the stack our own way.  */
      if (yystacksize >= YYMAXDEPTH)
	goto yyoverflowlab;
      yystacksize *= 2;
      if (yystacksize > YYMAXDEPTH)
	yystacksize = YYMAXDEPTH;

      {
	short *yyss1 = yyss;
	union yyalloc *yyptr =
	  (union yyalloc *) YYSTACK_ALLOC (YYSTACK_BYTES (yystacksize));
	if (! yyptr)
	  goto yyoverflowlab;
	YYSTACK_RELOCATE (yyss);
	YYSTACK_RELOCATE (yyvs);
# if YYLSP_NEEDED
	YYSTACK_RELOCATE (yyls);
# endif
# undef YYSTACK_RELOCATE
	if (yyss1 != yyssa)
	  YYSTACK_FREE (yyss1);
      }
# endif
#endif /* no yyoverflow */

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;
#if YYLSP_NEEDED
      yylsp = yyls + yysize - 1;
#endif

      YYDPRINTF ((stderr, "Stack size increased to %lu\n",
		  (unsigned long int) yystacksize));

      if (yyssp >= yyss + yystacksize - 1)
	YYABORT;
    }

  YYDPRINTF ((stderr, "Entering state %d\n", yystate));

  goto yybackup;


/*-----------.
| yybackup.  |
`-----------*/
yybackup:

/* Do appropriate processing given the current state.  */
/* Read a lookahead token if we need one and don't already have one.  */
/* yyresume: */

  /* First try to decide what to do without reference to lookahead token.  */

  yyn = yypact[yystate];
  if (yyn == YYFLAG)
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* yychar is either YYEMPTY or YYEOF
     or a valid token in external form.  */

  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token: "));
      yychar = YYLEX;
    }

  /* Convert token to internal form (in yychar1) for indexing tables with */

  if (yychar <= 0)		/* This means end of input. */
    {
      yychar1 = 0;
      yychar = YYEOF;		/* Don't call YYLEX any more */

      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else
    {
      yychar1 = YYTRANSLATE (yychar);

#if YYDEBUG
     /* We have to keep this `#if YYDEBUG', since we use variables
	which are defined only if `YYDEBUG' is set.  */
      if (yydebug)
	{
	  YYFPRINTF (stderr, "Next token is %d (%s",
		     yychar, yytname[yychar1]);
	  /* Give the individual parser a way to print the precise
	     meaning of a token, for further debugging info.  */
# ifdef YYPRINT
	  YYPRINT (stderr, yychar, yylval);
# endif
	  YYFPRINTF (stderr, ")\n");
	}
#endif
    }

  yyn += yychar1;
  if (yyn < 0 || yyn > YYLAST || yycheck[yyn] != yychar1)
    goto yydefault;

  yyn = yytable[yyn];

  /* yyn is what to do for this token type in this state.
     Negative => reduce, -yyn is rule number.
     Positive => shift, yyn is new state.
       New state is final state => don't bother to shift,
       just return success.
     0, or most negative number => error.  */

  if (yyn < 0)
    {
      if (yyn == YYFLAG)
	goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }
  else if (yyn == 0)
    goto yyerrlab;

  if (yyn == YYFINAL)
    YYACCEPT;

  /* Shift the lookahead token.  */
  YYDPRINTF ((stderr, "Shifting token %d (%s), ",
	      yychar, yytname[yychar1]));

  /* Discard the token being shifted unless it is eof.  */
  if (yychar != YYEOF)
    yychar = YYEMPTY;

  *++yyvsp = yylval;
#if YYLSP_NEEDED
  *++yylsp = yylloc;
#endif

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  yystate = yyn;
  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- Do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     `$$ = $1'.

     Otherwise, the following line sets YYVAL to the semantic value of
     the lookahead token.  This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];

#if YYLSP_NEEDED
  /* Similarly for the default location.  Let the user run additional
     commands if for instance locations are ranges.  */
  yyloc = yylsp[1-yylen];
  YYLLOC_DEFAULT (yyloc, (yylsp - yylen), yylen);
#endif

#if YYDEBUG
  /* We have to keep this `#if YYDEBUG', since we use variables which
     are defined only if `YYDEBUG' is set.  */
  if (yydebug)
    {
      int yyi;

      YYFPRINTF (stderr, "Reducing via rule %d (line %d), ",
		 yyn, yyrline[yyn]);

      /* Print the symbols being reduced, and their result.  */
      for (yyi = yyprhs[yyn]; yyrhs[yyi] > 0; yyi++)
	YYFPRINTF (stderr, "%s ", yytname[yyrhs[yyi]]);
      YYFPRINTF (stderr, " -> %s\n", yytname[yyr1[yyn]]);
    }
#endif

  switch (yyn) {

case 2:
#line 680 "djasm.y"
{ lineno++; pc_symbol.value=pc; ;
    break;}
case 3:
#line 681 "djasm.y"
{ strbuf[strbuflen]=0; do_include(strbuf); ;
    break;}
case 4:
#line 682 "djasm.y"
{ strbuf[strbuflen]=0; do_include(strbuf); ;
    break;}
case 6:
#line 688 "djasm.y"
{ set_symbol(yyvsp[-1].sym, pc)->type |= (pc?SYM_data:SYM_code); ;
    break;}
case 7:
#line 689 "djasm.y"
{ set_symbol(yyvsp[-2].sym, yyvsp[0].i)->type = SYM_abs; ;
    break;}
case 8:
#line 690 "djasm.y"
{ struct_pc=0;
					  struct_tp=yyvsp[-2].i;
					  struct_sym=yyvsp[-1].sym->name;
					  lineno++;
					  yyval.sym=symtab;
					  symtab=symtab->next;
					;
    break;}
case 9:
#line 698 "djasm.y"
{ set_symbol(yyvsp[-4].sym, struct_pc)->type = SYM_abs;
					  yyvsp[-2].sym->next=symtab;
					  symtab=yyvsp[-2].sym;
	  				;
    break;}
case 10:
#line 702 "djasm.y"
{ struct_pc=0;
					  struct_sym=yyvsp[-1].sym->name;
					  lineno++;
					  yyval.sym=symtab;
					  if (symtab==yyvsp[-1].sym)
					      symtab=symtab->next;
					;
    break;}
case 12:
#line 711 "djasm.y"
{ emit_struct(yyvsp[-2].sym,yyvsp[-1].i,yyvsp[0].sym); ;
    break;}
case 13:
#line 712 "djasm.y"
{ emit_struct_abs(yyvsp[-5].sym,yyvsp[-4].i,yyvsp[-3].sym,yyvsp[-1].i); ;
    break;}
case 15:
#line 715 "djasm.y"
{ emitb(yyvsp[0].i); ;
    break;}
case 16:
#line 716 "djasm.y"
{ emitb(yyvsp[0].i>>8); emitb(yyvsp[0].i & 0xff); ;
    break;}
case 17:
#line 718 "djasm.y"
{ bsspc = pc; generated_bytes = last_align_end == pc ? last_align_begin : pc; ;
    break;}
case 18:
#line 720 "djasm.y"
{ emitb(sreg_overrides[yyvsp[-1].i]); ;
    break;}
case 19:
#line 722 "djasm.y"
{ emitb(0x80), reg(yyvsp[-3].i); emitb(yyvsp[0].i); ;
    break;}
case 20:
#line 723 "djasm.y"
{ if (yyvsp[-2].i)
					      {emitb(0x80), modrm(3, yyvsp[-3].i, yyvsp[-2].i);}
					  else
					      modrm (0,yyvsp[-3].i,4); 
					  emitb	(yyvsp[0].i);
					;
    break;}
case 21:
#line 729 "djasm.y"
{ emitb(yyvsp[-3].i*8); modrm(3, yyvsp[0].i, yyvsp[-2].i); ;
    break;}
case 22:
#line 730 "djasm.y"
{ emitb(yyvsp[-3].i*8); reg(yyvsp[0].i); ;
    break;}
case 23:
#line 731 "djasm.y"
{ emitb(yyvsp[-3].i*8+2); reg(yyvsp[-2].i); ;
    break;}
case 24:
#line 733 "djasm.y"
{ emitb(0x81); reg(yyvsp[-3].i); emits(yyvsp[0].relsym.sym,yyvsp[0].relsym.ofs,REL_abs); ;
    break;}
case 25:
#line 734 "djasm.y"
{ if (yyvsp[-2].i) {
					      int v=yyvsp[0].relsym.ofs+yyvsp[0].relsym.sym->value;
					      if (yyvsp[0].relsym.sym->defined && v>=-128 && v<=127) {
						  emitb(0x83); modrm(3, yyvsp[-3].i, yyvsp[-2].i);
						  emits(yyvsp[0].relsym.sym,yyvsp[0].relsym.ofs,REL_abs8);
					      } else {
						  emitb(0x81); modrm(3, yyvsp[-3].i, yyvsp[-2].i);
						  emits(yyvsp[0].relsym.sym,yyvsp[0].relsym.ofs,REL_abs);
					      }
					  } else {
					      modrm (0,yyvsp[-3].i,5);
					      emits(yyvsp[0].relsym.sym,yyvsp[0].relsym.ofs,REL_abs);
					  }
					;
    break;}
case 26:
#line 748 "djasm.y"
{ emitb(yyvsp[-3].i*8+1); modrm(3, yyvsp[0].i, yyvsp[-2].i); ;
    break;}
case 27:
#line 749 "djasm.y"
{ emitb(yyvsp[-3].i*8+1); reg(yyvsp[0].i); ;
    break;}
case 28:
#line 750 "djasm.y"
{ emitb(yyvsp[-3].i*8+3); reg(yyvsp[-2].i); ;
    break;}
case 29:
#line 752 "djasm.y"
{ emitb(0x66); emitb(0x81); reg(yyvsp[-3].i); emits(yyvsp[0].relsym.sym,yyvsp[0].relsym.ofs,REL_abs32); ;
    break;}
case 30:
#line 753 "djasm.y"
{ emitb(0x66);
					  if (yyvsp[-2].i) {
					      int v=yyvsp[0].relsym.ofs+yyvsp[0].relsym.sym->value;
					      if (yyvsp[0].relsym.sym->defined && v>=-128 && v<=127) {
						  emitb(0x83); modrm(3, yyvsp[-3].i, yyvsp[-2].i);
						  emits(yyvsp[0].relsym.sym,yyvsp[0].relsym.ofs,REL_abs8);
					      } else {
						  emitb(0x81); modrm(3, yyvsp[-3].i, yyvsp[-2].i);
						  emits(yyvsp[0].relsym.sym,yyvsp[0].relsym.ofs,REL_abs32);
					      }
					  } else {
					      modrm (0,yyvsp[-3].i,5);
					      emits(yyvsp[0].relsym.sym,yyvsp[0].relsym.ofs,REL_abs32);
					  }
					;
    break;}
case 31:
#line 768 "djasm.y"
{ emitb(0x66); emitb(yyvsp[-3].i*8+1); modrm(3, yyvsp[0].i, yyvsp[-2].i); ;
    break;}
case 32:
#line 769 "djasm.y"
{ emitb(0x66); emitb(yyvsp[-3].i*8+1); reg(yyvsp[0].i); ;
    break;}
case 33:
#line 770 "djasm.y"
{ emitb(0x66); emitb(yyvsp[-3].i*8+3); reg(yyvsp[-2].i); ;
    break;}
case 34:
#line 772 "djasm.y"
{ emitb(0x63); modrm(3,yyvsp[0].i,yyvsp[-2].i); ;
    break;}
case 35:
#line 773 "djasm.y"
{ emitb(0x63); reg(yyvsp[0].i); ;
    break;}
case 36:
#line 775 "djasm.y"
{ emitb(yyvsp[0].i); emitb(0x0a); ;
    break;}
case 37:
#line 776 "djasm.y"
{ emitb(yyvsp[-1].i); emitb(yyvsp[0].i); ;
    break;}
case 38:
#line 778 "djasm.y"
{ do_align(yyvsp[0].i,0x90); ;
    break;}
case 39:
#line 779 "djasm.y"
{ do_align(yyvsp[-2].i,yyvsp[0].i); ;
    break;}
case 40:
#line 781 "djasm.y"
{ emitb(0x62); reg(yyvsp[-2].i); ;
    break;}
case 41:
#line 782 "djasm.y"
{ emitb(0x66); emitb(0x62); reg(yyvsp[-2].i); ;
    break;}
case 42:
#line 784 "djasm.y"
{ emitb(0x0f); emitb(yyvsp[-3].i*8+0x83); modrm(3, yyvsp[0].i, yyvsp[-2].i); ;
    break;}
case 43:
#line 785 "djasm.y"
{ emitb(0x0f); emitb(yyvsp[-3].i*8+0x83); reg(yyvsp[0].i); ;
    break;}
case 44:
#line 786 "djasm.y"
{ emitb(0x66); emitb(0x0f); emitb(yyvsp[-3].i*8+0x83); modrm(3, yyvsp[0].i, yyvsp[-2].i); ;
    break;}
case 45:
#line 787 "djasm.y"
{ emitb(0x66); emitb(0x0f); emitb(yyvsp[-3].i*8+0x83); reg(yyvsp[0].i); ;
    break;}
case 46:
#line 788 "djasm.y"
{ emitb(0x0f); emitb(0xba); modrm(3, yyvsp[-3].i, yyvsp[-2].i); emitb(yyvsp[0].i); ;
    break;}
case 47:
#line 789 "djasm.y"
{ emitb(0x0f); emitb(0xba); reg(yyvsp[-3].i); emitb(yyvsp[0].i); ;
    break;}
case 48:
#line 790 "djasm.y"
{ emitb(0x66); emitb(0x0f); emitb(0xba); modrm(3, yyvsp[-3].i, yyvsp[-2].i); emitb(yyvsp[0].i); ;
    break;}
case 49:
#line 792 "djasm.y"
{ emitb(0x0f); emitb(0xbc); modrm(3, yyvsp[0].i, yyvsp[-2].i); ;
    break;}
case 50:
#line 793 "djasm.y"
{ emitb(0x0f); emitb(0xbc); reg(yyvsp[-2].i); ;
    break;}
case 51:
#line 794 "djasm.y"
{ emitb(0x66); emitb(0x0f); emitb(0xbc); modrm(3, yyvsp[0].i, yyvsp[-2].i); ;
    break;}
case 52:
#line 795 "djasm.y"
{ emitb(0x66); emitb(0x0f); emitb(0xbc); reg(yyvsp[-2].i); ;
    break;}
case 53:
#line 797 "djasm.y"
{ emitb(0x0f); emitb(0xbd); modrm(3, yyvsp[0].i, yyvsp[-2].i); ;
    break;}
case 54:
#line 798 "djasm.y"
{ emitb(0x0f); emitb(0xbd); reg(yyvsp[-2].i); ;
    break;}
case 55:
#line 799 "djasm.y"
{ emitb(0x66); emitb(0x0f); emitb(0xbd); modrm(3, yyvsp[0].i, yyvsp[-2].i); ;
    break;}
case 56:
#line 800 "djasm.y"
{ emitb(0x66); emitb(0x0f); emitb(0xbd); reg(yyvsp[-2].i); ;
    break;}
case 57:
#line 802 "djasm.y"
{ emitb(0xe8); emits(yyvsp[0].sym,0,REL_16); yyvsp[0].sym->type |= SYM_code; ;
    break;}
case 58:
#line 803 "djasm.y"
{ emitb(0xff); modrm(3,2,yyvsp[0].i); ;
    break;}
case 59:
#line 804 "djasm.y"
{ emitb(0xff); reg(2); ;
    break;}
case 60:
#line 805 "djasm.y"
{ emitb(0xff); reg(3); ;
    break;}
case 61:
#line 806 "djasm.y"
{ emitb(0x9a); emits(yyvsp[0].relsym.sym,yyvsp[0].relsym.ofs,REL_abs); emitw(yyvsp[-2].i); ;
    break;}
case 62:
#line 807 "djasm.y"
{ emitb(0x66); emitb(0x9a); emits(yyvsp[0].relsym.sym,yyvsp[0].relsym.ofs,REL_abs32); emitw(yyvsp[-2].i); ;
    break;}
case 63:
#line 809 "djasm.y"
{ strbuf[strbuflen] = 0; add_copyright(strbuf); ;
    break;}
case 64:
#line 810 "djasm.y"
{ strbuf[strbuflen] = 0; add_rcs_ident(strbuf); ;
    break;}
case 68:
#line 816 "djasm.y"
{ emitb(0xfe); modrm(3, 1, yyvsp[0].i); ;
    break;}
case 69:
#line 817 "djasm.y"
{ emitb(0xfe); reg(1); ;
    break;}
case 70:
#line 818 "djasm.y"
{ emitb(0x48 + yyvsp[0].i); ;
    break;}
case 71:
#line 819 "djasm.y"
{ emitb(0x66); emitb(0x48 + yyvsp[0].i); ;
    break;}
case 72:
#line 820 "djasm.y"
{ emitb(0xff); reg(1); ;
    break;}
case 73:
#line 821 "djasm.y"
{ emitb(0x66); emitb(0xff); reg(1); ;
    break;}
case 74:
#line 823 "djasm.y"
{ emitb(0xc8); emitw(yyvsp[-2].i); emitb(yyvsp[0].i); ;
    break;}
case 75:
#line 825 "djasm.y"
{ emitb(0xe4); emitb(yyvsp[0].i); ;
    break;}
case 76:
#line 826 "djasm.y"
{ emitb(0xe5); emitb(yyvsp[0].i); ;
    break;}
case 77:
#line 827 "djasm.y"
{ emitb(0x66); emitb(0xe5); emitb(yyvsp[0].i);;
    break;}
case 78:
#line 828 "djasm.y"
{ emitb(0xec); ;
    break;}
case 79:
#line 829 "djasm.y"
{ emitb(0xed); ;
    break;}
case 80:
#line 830 "djasm.y"
{ emitb(0x66); emitb(0xed); ;
    break;}
case 81:
#line 832 "djasm.y"
{ emitb(0xfe); modrm(3, 0, yyvsp[0].i); ;
    break;}
case 82:
#line 833 "djasm.y"
{ emitb(0xfe); reg(0); ;
    break;}
case 83:
#line 834 "djasm.y"
{ emitb(0x40 + yyvsp[0].i); ;
    break;}
case 84:
#line 835 "djasm.y"
{ emitb(0x66); emitb(0x40 + yyvsp[0].i); ;
    break;}
case 85:
#line 836 "djasm.y"
{ emitb(0xff); reg(0); ;
    break;}
case 86:
#line 837 "djasm.y"
{ emitb(0x66); emitb(0xff); reg(0); ;
    break;}
case 87:
#line 839 "djasm.y"
{ emitb(0xf6); modrm(3, 5, yyvsp[0].i); ;
    break;}
case 88:
#line 840 "djasm.y"
{ emitb(0xf6); reg(5); ;
    break;}
case 89:
#line 841 "djasm.y"
{ emitb(0xf7); modrm(3, 5, yyvsp[0].i); ;
    break;}
case 90:
#line 842 "djasm.y"
{ emitb(0xf7); reg(5); ;
    break;}
case 91:
#line 843 "djasm.y"
{ emitb(0x66); emitb(0xf7); modrm(3, 5, yyvsp[0].i); ;
    break;}
case 92:
#line 844 "djasm.y"
{ emitb(0x66); emitb(0xf7); reg(5); ;
    break;}
case 93:
#line 845 "djasm.y"
{ emitb(0x0f); emitb(0xaf); modrm(3, yyvsp[-2].i, yyvsp[0].i);;
    break;}
case 94:
#line 846 "djasm.y"
{ emitb(0x66); emitb(0x0f); emitb(0xaf); modrm(3, yyvsp[-2].i, yyvsp[0].i);;
    break;}
case 95:
#line 847 "djasm.y"
{ emitb(0x0f); emitb(0xaf); reg(yyvsp[-2].i); ;
    break;}
case 96:
#line 848 "djasm.y"
{ emitb(0x66); emitb(0x0f); emitb(0xaf); reg(yyvsp[-2].i); ;
    break;}
case 97:
#line 849 "djasm.y"
{ if (yyvsp[0].i>=-128 && yyvsp[0].i<=127)
					      emitb(0x6b);
					  else
					      emitb(0x69);
					  modrm(3, yyvsp[-4].i, yyvsp[-2].i);
					  if (yyvsp[0].i>=-128 && yyvsp[0].i<=127)
					      emitb(yyvsp[0].i);
					  else
					      emitw(yyvsp[0].i);
					;
    break;}
case 98:
#line 859 "djasm.y"
{ emitb(0x66);
					  if (yyvsp[0].i>=-128 && yyvsp[0].i<=127)
					      emitb(0x6b);
					  else
					      emitb(0x69);
					  modrm(3, yyvsp[-4].i, yyvsp[-2].i);
					  if (yyvsp[0].i>=-128 && yyvsp[0].i<=127)
					      emitb(yyvsp[0].i&0xff);
					  else
					      emitd(yyvsp[0].i);
					;
    break;}
case 99:
#line 871 "djasm.y"
{ if (yyvsp[0].i>=-128 && yyvsp[0].i<=127)
					      emitb(0x6b);
					  else
					      emitb(0x69);
					  reg(yyvsp[-4].i);
					  if (yyvsp[0].i>=-128 && yyvsp[0].i<=127)
					      emitb(yyvsp[0].i);
					  else
					      emitw(yyvsp[0].i);
					;
    break;}
case 100:
#line 881 "djasm.y"
{ emitb(0x66);
					  if (yyvsp[0].i>=-128 && yyvsp[0].i<=127)
					      emitb(0x6b);
					  else
					      emitb(0x69);
					  reg(yyvsp[-4].i);
					  if (yyvsp[0].i>=-128 && yyvsp[0].i<=127)
					      emitb(yyvsp[0].i&0xff);
					  else
					      emitd(yyvsp[0].i);
					;
    break;}
case 101:
#line 893 "djasm.y"
{ emitb(0xf6); modrm(3, yyvsp[-1].i, yyvsp[0].i); ;
    break;}
case 102:
#line 894 "djasm.y"
{ emitb(0xf6); reg(yyvsp[-1].i); ;
    break;}
case 103:
#line 895 "djasm.y"
{ emitb(0xf7); modrm(3, yyvsp[-1].i, yyvsp[0].i); ;
    break;}
case 104:
#line 896 "djasm.y"
{ emitb(0xf7); reg(yyvsp[-1].i); ;
    break;}
case 105:
#line 897 "djasm.y"
{ emitb(0x66); emitb(0xf7); modrm(3, yyvsp[-1].i, yyvsp[0].i); ;
    break;}
case 106:
#line 898 "djasm.y"
{ emitb(0x66); emitb(0xf7); reg(yyvsp[-1].i); ;
    break;}
case 107:
#line 900 "djasm.y"
{ emitb(0x0f); emitb(0x00); reg(yyvsp[-1].i); ;
    break;}
case 108:
#line 901 "djasm.y"
{ emitb(0x0f); emitb(0x00); modrm(3, yyvsp[-1].i, yyvsp[0].i); ;
    break;}
case 109:
#line 902 "djasm.y"
{ emitb(0x0f); emitb(0x01); reg(yyvsp[-1].i); ;
    break;}
case 110:
#line 903 "djasm.y"
{ emitb(0x0f); emitb(0x01); modrm(3, yyvsp[-1].i, yyvsp[0].i); ;
    break;}
case 111:
#line 905 "djasm.y"
{ if (yyvsp[0].i == 3) emitb(0xcc); else emitb(0xcd), emitb(yyvsp[0].i); ;
    break;}
case 112:
#line 907 "djasm.y"
{ emitb(0x70+yyvsp[-1].i); emits(yyvsp[0].sym,0,REL_8); yyvsp[0].sym->type |= SYM_code; ;
    break;}
case 113:
#line 908 "djasm.y"
{ emitb(0x0f); emitb(0x80+yyvsp[-1].i); emits(yyvsp[0].sym,0,REL_16); yyvsp[0].sym->type |= SYM_code; ;
    break;}
case 114:
#line 910 "djasm.y"
{ if (yyvsp[-1].i) emitb(0x66); emitb(0xe3); emits(yyvsp[0].sym,0,REL_8); yyvsp[0].sym->type |= SYM_code; ;
    break;}
case 115:
#line 912 "djasm.y"
{ emitb(0xe9); emits(yyvsp[0].sym,0,REL_16); yyvsp[0].sym->type |= SYM_code; ;
    break;}
case 116:
#line 913 "djasm.y"
{ emitb(0xeb); emits(yyvsp[0].sym,0,REL_8); yyvsp[0].sym->type |= SYM_code; ;
    break;}
case 117:
#line 914 "djasm.y"
{ emitb(0xff); modrm(3,4,yyvsp[0].i); ;
    break;}
case 118:
#line 915 "djasm.y"
{ emitb(0xff); reg(4); ;
    break;}
case 119:
#line 916 "djasm.y"
{ emitb(0xff); reg(5); ;
    break;}
case 120:
#line 917 "djasm.y"
{ emitb(0xea); emits(yyvsp[0].relsym.sym,yyvsp[0].relsym.ofs,REL_abs); emitw(yyvsp[-2].i); ;
    break;}
case 121:
#line 918 "djasm.y"
{ emitb(0x66); emitb(0xea); emits(yyvsp[0].relsym.sym,yyvsp[0].relsym.ofs,REL_abs32); emitw(yyvsp[-2].i); ;
    break;}
case 122:
#line 920 "djasm.y"
{ emitb(0x0f); emitb(0x02); modrm(3, yyvsp[0].i, yyvsp[-2].i); ;
    break;}
case 123:
#line 921 "djasm.y"
{ emitb(0x0f); emitb(0x02); reg(yyvsp[-2].i); ;
    break;}
case 124:
#line 923 "djasm.y"
{ emitb(0x8d); reg(yyvsp[-2].i); ;
    break;}
case 125:
#line 924 "djasm.y"
{ emitb(0x66); emitb(0x8d); reg(yyvsp[-2].i); ;
    break;}
case 126:
#line 926 "djasm.y"
{ strbuf[strbuflen]=0; do_linkcoff(strbuf); ;
    break;}
case 127:
#line 927 "djasm.y"
{ emitb(yyvsp[-1].i); emits(yyvsp[0].sym,0,REL_8); ;
    break;}
case 128:
#line 929 "djasm.y"
{ emitb(0x0f); emitb(0x03); modrm(3, yyvsp[0].i, yyvsp[-2].i); ;
    break;}
case 129:
#line 930 "djasm.y"
{ emitb(0x0f); emitb(0x03); reg(yyvsp[-2].i); ;
    break;}
case 130:
#line 932 "djasm.y"
{ if (yyvsp[-3].i>>8) emitb(yyvsp[-3].i>>8); emitb(yyvsp[-3].i & 0xff); reg(yyvsp[-2].i); ;
    break;}
case 131:
#line 933 "djasm.y"
{ emitb(0x66); if (yyvsp[-3].i>>8) emitb(yyvsp[-3].i>>8); emitb(yyvsp[-3].i & 0xff); reg(yyvsp[-2].i); ;
    break;}
case 132:
#line 935 "djasm.y"
{ emitb(0xc6), reg(0); emitb(yyvsp[0].i); ;
    break;}
case 133:
#line 936 "djasm.y"
{ emitb(0xb0+yyvsp[-2].i); emitb(yyvsp[0].i); ;
    break;}
case 134:
#line 937 "djasm.y"
{ emitb(0x88), modrm(3, yyvsp[0].i, yyvsp[-2].i); ;
    break;}
case 135:
#line 938 "djasm.y"
{ if (yyvsp[0].i==0 && _modrm.regs==0)
					      movacc=0xa2;
					  else
					      emitb(0x88); 
					  reg(yyvsp[0].i); 
					;
    break;}
case 136:
#line 944 "djasm.y"
{ if (yyvsp[-2].i==0 && _modrm.regs==0)
					      movacc=0xa0;
					  else
					      emitb(0x8a);
					  reg(yyvsp[-2].i);
					;
    break;}
case 137:
#line 950 "djasm.y"
{ emitb(0xc7); reg(0); emits(yyvsp[0].relsym.sym,yyvsp[0].relsym.ofs,REL_abs); ;
    break;}
case 138:
#line 951 "djasm.y"
{ emitb(0xb8+yyvsp[-2].i); emits(yyvsp[0].relsym.sym,yyvsp[0].relsym.ofs,REL_abs); ;
    break;}
case 139:
#line 952 "djasm.y"
{ emitb(0x89); modrm(3, yyvsp[0].i, yyvsp[-2].i); ;
    break;}
case 140:
#line 953 "djasm.y"
{ if (yyvsp[0].i==0 && _modrm.regs==0)
					      movacc=0xa3;
					  else
					      emitb(0x89);
					  reg(yyvsp[0].i); 
					;
    break;}
case 141:
#line 959 "djasm.y"
{ if (yyvsp[-2].i==0 && _modrm.regs==0)
					      movacc=0xa1;
					  else
					      emitb(0x8b);
					  reg(yyvsp[-2].i);
					;
    break;}
case 142:
#line 965 "djasm.y"
{ emitb(0x66); emitb(0xc7); reg(0); emits(yyvsp[0].relsym.sym,yyvsp[0].relsym.ofs,REL_abs32); ;
    break;}
case 143:
#line 966 "djasm.y"
{ emitb(0x66); emitb(0xb8+yyvsp[-2].i); emits(yyvsp[0].relsym.sym,yyvsp[0].relsym.ofs,REL_abs32); ;
    break;}
case 144:
#line 967 "djasm.y"
{ emitb(0x66); emitb(0x89); modrm(3, yyvsp[0].i, yyvsp[-2].i); ;
    break;}
case 145:
#line 968 "djasm.y"
{ emitb(0x66);
					  if (yyvsp[0].i==0 && _modrm.regs==0)
					      movacc=0xa3;
					  else
					      emitb(0x89);
					  reg(yyvsp[0].i);
					;
    break;}
case 146:
#line 975 "djasm.y"
{ emitb(0x66);
					  if (yyvsp[-2].i==0 && _modrm.regs==0)
					      movacc=0xa1;
					  else
					      emitb(0x8b);
					  reg(yyvsp[-2].i);
					;
    break;}
case 147:
#line 982 "djasm.y"
{ emitb(0x8c); reg(yyvsp[0].i); ;
    break;}
case 148:
#line 983 "djasm.y"
{ emitb(0x8c); modrm(3, yyvsp[0].i, yyvsp[-2].i); ;
    break;}
case 149:
#line 984 "djasm.y"
{ emitb(0x8e); reg(yyvsp[-2].i); ;
    break;}
case 150:
#line 985 "djasm.y"
{ emitb(0x8e); modrm(3, yyvsp[-2].i, yyvsp[0].i); ;
    break;}
case 151:
#line 987 "djasm.y"
{ emitb(0x0f); emitb(0x22); modrm(3, yyvsp[-2].i, yyvsp[0].i); ;
    break;}
case 152:
#line 988 "djasm.y"
{ emitb(0x0f); emitb(0x23); modrm(3, yyvsp[-2].i, yyvsp[0].i); ;
    break;}
case 153:
#line 989 "djasm.y"
{ emitb(0x0f); emitb(0x26); modrm(3, yyvsp[-2].i, yyvsp[0].i); ;
    break;}
case 154:
#line 990 "djasm.y"
{ emitb(0x0f); emitb(0x20); modrm(3, yyvsp[0].i, yyvsp[-2].i); ;
    break;}
case 155:
#line 991 "djasm.y"
{ emitb(0x0f); emitb(0x21); modrm(3, yyvsp[0].i, yyvsp[-2].i); ;
    break;}
case 156:
#line 992 "djasm.y"
{ emitb(0x0f); emitb(0x24); modrm(3, yyvsp[0].i, yyvsp[-2].i); ;
    break;}
case 157:
#line 994 "djasm.y"
{ emitb(0x0f); emitb(yyvsp[-3].i); modrm(3, yyvsp[-2].i, yyvsp[0].i); ;
    break;}
case 158:
#line 995 "djasm.y"
{ emitb(0x66); emitb(0x0f); emitb(yyvsp[-3].i); modrm(3, yyvsp[-2].i, yyvsp[0].i); ;
    break;}
case 159:
#line 996 "djasm.y"
{ emitb(0x66); emitb(0x0f); emitb(yyvsp[-3].i+1); modrm(3, yyvsp[-2].i, yyvsp[0].i); ;
    break;}
case 160:
#line 998 "djasm.y"
{ emitb(0x0f); emitb(yyvsp[-3].i); reg(yyvsp[-2].i); ;
    break;}
case 161:
#line 999 "djasm.y"
{ emitb(0x66); emitb(0x0f); emitb(yyvsp[-3].i); reg(yyvsp[-2].i); ;
    break;}
case 162:
#line 1000 "djasm.y"
{ emitb(0x66); emitb(0x0f); emitb(yyvsp[-3].i+1); reg(yyvsp[-2].i); ;
    break;}
case 163:
#line 1002 "djasm.y"
{ if (pc > yyvsp[0].i) djerror ("Backwards org directive"); else while (pc < yyvsp[0].i) emitb(0x90); ;
    break;}
case 164:
#line 1003 "djasm.y"
{ if (pc > yyvsp[-2].i) djerror ("Backwards org directive"); else while (pc < yyvsp[-2].i) emitb(yyvsp[0].i); ;
    break;}
case 165:
#line 1005 "djasm.y"
{ emitb(0xe6); emitb(yyvsp[-2].i); ;
    break;}
case 166:
#line 1006 "djasm.y"
{ emitb(0xe7); emitb(yyvsp[-2].i); ;
    break;}
case 167:
#line 1007 "djasm.y"
{ emitb(0x66); emitb(0xe7); emitb(yyvsp[-2].i);;
    break;}
case 168:
#line 1008 "djasm.y"
{ emitb(0xee); ;
    break;}
case 169:
#line 1009 "djasm.y"
{ emitb(0xef); ;
    break;}
case 170:
#line 1010 "djasm.y"
{ emitb(0x66); emitb(0xef); ;
    break;}
case 171:
#line 1012 "djasm.y"
{ emitb(0x58 + yyvsp[0].i); ;
    break;}
case 172:
#line 1013 "djasm.y"
{ emitb(0x66); emitb(0x58 + yyvsp[0].i); ;
    break;}
case 173:
#line 1014 "djasm.y"
{ do_sreg_pop(yyvsp[0].i); ;
    break;}
case 174:
#line 1015 "djasm.y"
{ emitb(0x8f); reg(0); ;
    break;}
case 175:
#line 1016 "djasm.y"
{ emitb(0x66); emitb(0x8f); reg(0); ;
    break;}
case 176:
#line 1017 "djasm.y"
{ emitb(0x50 + yyvsp[0].i); ;
    break;}
case 177:
#line 1018 "djasm.y"
{ emitb(0x66); emitb(0x50 + yyvsp[0].i); ;
    break;}
case 178:
#line 1019 "djasm.y"
{ do_sreg_push(yyvsp[0].i); ;
    break;}
case 179:
#line 1020 "djasm.y"
{ emitb(0xff); reg(6); ;
    break;}
case 180:
#line 1021 "djasm.y"
{ emitb(0x66); emitb(0xff); reg(6); ;
    break;}
case 181:
#line 1022 "djasm.y"
{ emitb(0x6a); emitb(yyvsp[0].i); ;
    break;}
case 182:
#line 1023 "djasm.y"
{ emitb(0x68); emits(yyvsp[0].relsym.sym,yyvsp[0].relsym.ofs,REL_abs); ;
    break;}
case 183:
#line 1024 "djasm.y"
{ emitb(0x66); emitb(0x68); emits(yyvsp[0].relsym.sym,yyvsp[0].relsym.ofs,REL_abs32); ;
    break;}
case 184:
#line 1026 "djasm.y"
{ emitb(0xc3); ;
    break;}
case 185:
#line 1027 "djasm.y"
{ emitb(0xc2); emitw(yyvsp[0].i); ;
    break;}
case 186:
#line 1028 "djasm.y"
{ emitb(0xcb); ;
    break;}
case 187:
#line 1029 "djasm.y"
{ emitb(0xca); emitw(yyvsp[0].i); ;
    break;}
case 188:
#line 1030 "djasm.y"
{ emitb(0x66); emitb(0xc3); ;
    break;}
case 189:
#line 1031 "djasm.y"
{ emitb(0x66); emitb(0xc2); emitd(yyvsp[0].i); ;
    break;}
case 190:
#line 1032 "djasm.y"
{ emitb(0x66); emitb(0xcb); ;
    break;}
case 191:
#line 1033 "djasm.y"
{ emitb(0x66); emitb(0xca); emitd(yyvsp[0].i); ;
    break;}
case 192:
#line 1035 "djasm.y"
{ emitb(0x0f); emitb(0x90+yyvsp[-1].i); modrm(3, 0, yyvsp[0].i); ;
    break;}
case 193:
#line 1036 "djasm.y"
{ emitb(0x0f); emitb(0x90+yyvsp[-1].i); reg(0); ;
    break;}
case 194:
#line 1039 "djasm.y"
{ emitb(yyvsp[0].i == 1 ? 0xd0 : 0xc0); modrm(3, yyvsp[-3].i, yyvsp[-2].i); if (yyvsp[0].i != 1) emitb(yyvsp[0].i); ;
    break;}
case 195:
#line 1040 "djasm.y"
{ if (yyvsp[0].i != 1) djerror ("Non-constant shift count must be `cl'"); emitb(0xd2); modrm(3, yyvsp[-3].i, yyvsp[-2].i); ;
    break;}
case 196:
#line 1041 "djasm.y"
{ emitb(yyvsp[0].i == 1 ? 0xd0 : 0xc0); reg(yyvsp[-3].i); if (yyvsp[0].i != 1) emitb(yyvsp[0].i); ;
    break;}
case 197:
#line 1042 "djasm.y"
{ if (yyvsp[0].i != 1) djerror ("Non-constant shift count must be `cl'"); emitb(0xd2); reg(yyvsp[-3].i); ;
    break;}
case 198:
#line 1043 "djasm.y"
{ emitb(yyvsp[0].i == 1 ? 0xd1 : 0xc1); modrm(3, yyvsp[-3].i, yyvsp[-2].i); if (yyvsp[0].i != 1) emitb(yyvsp[0].i); ;
    break;}
case 199:
#line 1044 "djasm.y"
{ if (yyvsp[0].i != 1) djerror ("Non-constant shift count must be `cl'"); emitb(0xd3); modrm(3, yyvsp[-3].i, yyvsp[-2].i); ;
    break;}
case 200:
#line 1045 "djasm.y"
{ emitb(yyvsp[0].i == 1 ? 0xd1 : 0xc1); reg(yyvsp[-3].i); if (yyvsp[0].i != 1) emitb(yyvsp[0].i); ;
    break;}
case 201:
#line 1046 "djasm.y"
{ if (yyvsp[0].i != 1) djerror ("Non-constant shift count must be `cl'"); emitb(0xd3); reg(yyvsp[-3].i); ;
    break;}
case 202:
#line 1047 "djasm.y"
{ emitb(0x66); emitb(yyvsp[0].i == 1 ? 0xd1 : 0xc1); modrm(3, yyvsp[-3].i, yyvsp[-2].i); if (yyvsp[0].i != 1) emitb(yyvsp[0].i); ;
    break;}
case 203:
#line 1048 "djasm.y"
{ if (yyvsp[0].i != 1) djerror ("Non-constant shift count must be `cl'"); emitb(0x66); emitb(0xd3); modrm(3, yyvsp[-3].i, yyvsp[-2].i); ;
    break;}
case 204:
#line 1049 "djasm.y"
{ emitb(0x66); emitb(yyvsp[0].i == 1 ? 0xd1 : 0xc1); reg(yyvsp[-3].i); if (yyvsp[0].i != 1) emitb(yyvsp[0].i); ;
    break;}
case 205:
#line 1050 "djasm.y"
{ if (yyvsp[0].i != 1) djerror ("Non-constant shift count must be `cl'"); emitb(0x66); emitb(0xd3); reg(yyvsp[-3].i); ;
    break;}
case 206:
#line 1060 "djasm.y"
{ shxd_error(yyvsp[-5].i); ;
    break;}
case 207:
#line 1061 "djasm.y"
{ shxd_error(yyvsp[-5].i); ;
    break;}
case 208:
#line 1062 "djasm.y"
{ shxd_error(yyvsp[-5].i); ;
    break;}
case 209:
#line 1063 "djasm.y"
{ shxd_error(yyvsp[-5].i); ;
    break;}
case 210:
#line 1064 "djasm.y"
{ shxd_error(yyvsp[-5].i); ;
    break;}
case 211:
#line 1065 "djasm.y"
{ shxd_error(yyvsp[-5].i); ;
    break;}
case 212:
#line 1066 "djasm.y"
{ shxd_error(yyvsp[-5].i); ;
    break;}
case 213:
#line 1067 "djasm.y"
{ shxd_error(yyvsp[-5].i); ;
    break;}
case 214:
#line 1075 "djasm.y"
{ emitb(0x0f); emitb(yyvsp[-5].i); modrm(3, yyvsp[-2].i, yyvsp[-4].i); emitb(yyvsp[0].i); ;
    break;}
case 215:
#line 1076 "djasm.y"
{ if (yyvsp[0].i != 1) djerror ("Non-constant shift count must be `cl'"); emitb(0x0f); emitb(yyvsp[-5].i+1); modrm(3, yyvsp[-2].i, yyvsp[-4].i); ;
    break;}
case 216:
#line 1077 "djasm.y"
{ emitb(0x0f); emitb(yyvsp[-5].i); reg(yyvsp[-2].i); emitb(yyvsp[0].i); ;
    break;}
case 217:
#line 1078 "djasm.y"
{ if (yyvsp[0].i != 1) djerror ("Non-constant shift count must be `cl'"); emitb(0x0f); emitb(yyvsp[-5].i+1); reg(yyvsp[-2].i); ;
    break;}
case 218:
#line 1081 "djasm.y"
{ emitb(0x66); emitb(0x0f); emitb(yyvsp[-5].i); modrm(3, yyvsp[-2].i, yyvsp[-4].i); emitb(yyvsp[0].i); ;
    break;}
case 219:
#line 1082 "djasm.y"
{ if (yyvsp[0].i != 1) djerror ("Non-constant shift count must be `cl'"); emitb(0x66); emitb(0x0f); emitb(yyvsp[-5].i+1); modrm(3, yyvsp[-2].i, yyvsp[-4].i); ;
    break;}
case 220:
#line 1083 "djasm.y"
{ emitb(0x66); emitb(0x0f); emitb(yyvsp[-5].i); reg(yyvsp[-2].i); emitb(yyvsp[0].i); ;
    break;}
case 221:
#line 1084 "djasm.y"
{ if (yyvsp[0].i != 1) djerror ("Non-constant shift count must be `cl'"); emitb(0x66); emitb(0x0f); emitb(yyvsp[-5].i+1); reg(yyvsp[-2].i); ;
    break;}
case 222:
#line 1086 "djasm.y"
{ stack_ptr = pc; ;
    break;}
case 223:
#line 1087 "djasm.y"
{ start_ptr = pc; main_obj=1; ;
    break;}
case 224:
#line 1089 "djasm.y"
{ emitb(0xf6), reg(0); emitb(yyvsp[0].i); ;
    break;}
case 225:
#line 1090 "djasm.y"
{ emitb(0xf6), modrm(3, 0, yyvsp[-2].i); emitb(yyvsp[0].i); ;
    break;}
case 226:
#line 1091 "djasm.y"
{ emitb(0x84), modrm(3, yyvsp[0].i, yyvsp[-2].i); ;
    break;}
case 227:
#line 1092 "djasm.y"
{ emitb(0x84), reg(yyvsp[0].i); ;
    break;}
case 228:
#line 1093 "djasm.y"
{ emitb(0x84), reg(yyvsp[-2].i); ;
    break;}
case 229:
#line 1095 "djasm.y"
{ emitb(0xf7); reg(0); emits(yyvsp[0].relsym.sym,yyvsp[0].relsym.ofs,REL_abs); ;
    break;}
case 230:
#line 1096 "djasm.y"
{ emitb(0xf7); modrm(3, 0, yyvsp[-2].i); emits(yyvsp[0].relsym.sym,yyvsp[0].relsym.ofs,REL_abs); ;
    break;}
case 231:
#line 1097 "djasm.y"
{ emitb(0x85); modrm(3, yyvsp[0].i, yyvsp[-2].i); ;
    break;}
case 232:
#line 1098 "djasm.y"
{ emitb(0x85); reg(yyvsp[0].i); ;
    break;}
case 233:
#line 1099 "djasm.y"
{ emitb(0x85); reg(yyvsp[-2].i); ;
    break;}
case 234:
#line 1101 "djasm.y"
{ emitb(0x66); emitb(0xf7); reg(0); emits(yyvsp[0].relsym.sym,yyvsp[0].relsym.ofs,REL_abs32); ;
    break;}
case 235:
#line 1102 "djasm.y"
{ emitb(0x66); emitb(0xf7); modrm(3, 0, yyvsp[-2].i); emits(yyvsp[0].relsym.sym,yyvsp[0].relsym.ofs,REL_abs32); ;
    break;}
case 236:
#line 1103 "djasm.y"
{ emitb(0x66); emitb(0x85); modrm(3, yyvsp[0].i, yyvsp[-2].i); ;
    break;}
case 237:
#line 1104 "djasm.y"
{ emitb(0x66); emitb(0x85); reg(yyvsp[0].i); ;
    break;}
case 238:
#line 1105 "djasm.y"
{ emitb(0x66); emitb(0x85); reg(yyvsp[-2].i); ;
    break;}
case 239:
#line 1107 "djasm.y"
{ strbuf[strbuflen] = 0; set_image_type(strbuf); ;
    break;}
case 240:
#line 1108 "djasm.y"
{ if (yyvsp[0].i == 'h') set_out_type("h"); ;
    break;}
case 241:
#line 1110 "djasm.y"
{ emitb(0x86); modrm(3, yyvsp[-2].i, yyvsp[0].i); ;
    break;}
case 242:
#line 1111 "djasm.y"
{ emitb(0x86); reg(yyvsp[-2].i); ;
    break;}
case 243:
#line 1112 "djasm.y"
{ emitb(0x86); reg(yyvsp[0].i); ;
    break;}
case 244:
#line 1113 "djasm.y"
{ if ((yyvsp[-2].i==0) ^	(yyvsp[0].i==0))
					      emitb(0x90+yyvsp[-2].i+yyvsp[0].i);
					  else
					      {emitb(0x87); modrm(3, yyvsp[-2].i, yyvsp[0].i); }
					;
    break;}
case 245:
#line 1118 "djasm.y"
{ emitb(0x87); reg(yyvsp[-2].i); ;
    break;}
case 246:
#line 1119 "djasm.y"
{ emitb(0x87); reg(yyvsp[0].i); ;
    break;}
case 247:
#line 1120 "djasm.y"
{ emitb(0x66);
					  if ((yyvsp[-2].i==0) ^	(yyvsp[0].i==0))
					      emitb(0x90+yyvsp[-2].i+yyvsp[0].i);
					  else
					      {emitb(0x87); modrm(3, yyvsp[-2].i, yyvsp[0].i); }
					;
    break;}
case 248:
#line 1126 "djasm.y"
{ emitb(0x66); emitb(0x87); reg(yyvsp[-2].i); ;
    break;}
case 249:
#line 1127 "djasm.y"
{ emitb(0x66); emitb(0x87); reg(yyvsp[0].i); ;
    break;}
case 251:
#line 1132 "djasm.y"
{ lineno++; ;
    break;}
case 253:
#line 1137 "djasm.y"
{ add_struct_element(yyvsp[-1].sym); ;
    break;}
case 254:
#line 1138 "djasm.y"
{ build_struct(yyvsp[-2].sym,yyvsp[-1].i,yyvsp[0].sym); ;
    break;}
case 255:
#line 1139 "djasm.y"
{ build_struct(0,yyvsp[-1].i,yyvsp[0].sym); ;
    break;}
case 257:
#line 1141 "djasm.y"
{ add_struct_element(yyvsp[0].sym); ;
    break;}
case 260:
#line 1147 "djasm.y"
{ lineno++; ;
    break;}
case 262:
#line 1152 "djasm.y"
{ add_enum_element(yyvsp[0].sym); ;
    break;}
case 263:
#line 1153 "djasm.y"
{ struct_pc = yyvsp[0].i; add_enum_element(yyvsp[-2].sym); ;
    break;}
case 264:
#line 1157 "djasm.y"
{ if (struct_tp=='s') {
					      struct_pc++;
					  } else {
					      struct_pc=MAX(struct_pc,1);
					  }
					;
    break;}
case 265:
#line 1163 "djasm.y"
{ if (struct_tp=='s') {
					      struct_pc+=yyvsp[-1].i;
					  } else {
					      struct_pc=MAX(struct_pc,yyvsp[-1].i);
					  }
					;
    break;}
case 266:
#line 1169 "djasm.y"
{ if (struct_tp=='s') {
					      struct_pc+=2;
					  } else {
					      struct_pc=MAX(struct_pc,2);
					  }
					;
    break;}
case 267:
#line 1175 "djasm.y"
{ if (struct_tp=='s') {
					      struct_pc+=2*yyvsp[-1].i;
					  } else {
					      struct_pc=MAX(struct_pc,2*yyvsp[-1].i);
					  }
					;
    break;}
case 268:
#line 1181 "djasm.y"
{ if (struct_tp=='s') {
					      struct_pc+=4;
					  } else {
					      struct_pc=MAX(struct_pc,4);
					  }
					;
    break;}
case 269:
#line 1187 "djasm.y"
{ if (struct_tp=='s') {
					      struct_pc+=4*yyvsp[-1].i;
					  } else {
					      struct_pc=MAX(struct_pc,4*yyvsp[-1].i);
					  }
					;
    break;}
case 270:
#line 1197 "djasm.y"
{ emitb(yyvsp[0].i); ;
    break;}
case 271:
#line 1198 "djasm.y"
{ emit(strbuf, strbuflen); ;
    break;}
case 272:
#line 1199 "djasm.y"
{ for (i=0; i<yyvsp[-2].i; i++) emitb(yyvsp[0].i); ;
    break;}
case 275:
#line 1208 "djasm.y"
{ emitw(yyvsp[0].i); ;
    break;}
case 276:
#line 1209 "djasm.y"
{ emits(yyvsp[-1].sym,yyvsp[0].i,REL_abs); ;
    break;}
case 277:
#line 1210 "djasm.y"
{ for (i=0; i<yyvsp[-2].i; i++) emitw(yyvsp[0].i); ;
    break;}
case 280:
#line 1219 "djasm.y"
{ emitd(yyvsp[0].i); ;
    break;}
case 281:
#line 1220 "djasm.y"
{ emits(yyvsp[-1].sym,yyvsp[0].i,REL_abs32); ;
    break;}
case 282:
#line 1221 "djasm.y"
{ for (i=0; i<yyvsp[-2].i; i++) emitd(yyvsp[0].i); ;
    break;}
case 287:
#line 1232 "djasm.y"
{ emitb(sreg_overrides[yyvsp[-4].i]); ;
    break;}
case 290:
#line 1238 "djasm.y"
{ _modrm.offset -= yyvsp[0].i; ;
    break;}
case 291:
#line 1242 "djasm.y"
{ emitb(sreg_overrides[yyvsp[-2].i]); ;
    break;}
case 292:
#line 1243 "djasm.y"
{ if (_modrm.addr32) {
					      _modrm.nsyms = _modrm.addr32 = _modrm.addr16 = _modrm.offset = _modrm.regs = 0;
					      djerror("Cannot mix 16 and 32 bit addressing");
					  } else {
					      _modrm.regs |= (1<<yyvsp[0].i);
					      _modrm.addr16=1;
					  }
					;
    break;}
case 293:
#line 1251 "djasm.y"
{ addr32((1<<yyvsp[0].i)|0x100); ;
    break;}
case 294:
#line 1252 "djasm.y"
{ addr32(yyvsp[0].i); ;
    break;}
case 295:
#line 1253 "djasm.y"
{ _modrm.syms[_modrm.nsyms++] = yyvsp[0].sym; ;
    break;}
case 296:
#line 1254 "djasm.y"
{ _modrm.offset += yyvsp[0].i; ;
    break;}
case 297:
#line 1258 "djasm.y"
{ if (yyvsp[0].i==1 || yyvsp[0].i==2 || yyvsp[0].i==4 || yyvsp[0].i==8)
					      yyval.i = (1<<(yyvsp[-2].i)) | (yyvsp[0].i<<8);
					  else {
					      _modrm.nsyms = _modrm.addr32 = _modrm.addr16 = _modrm.offset = _modrm.regs = 0;
					      djerror("Scale must be 1,2,4 or 8");
					  }
					;
    break;}
case 298:
#line 1265 "djasm.y"
{ if (yyvsp[-2].i==1 || yyvsp[-2].i==2 || yyvsp[-2].i==4 || yyvsp[-2].i==8)
					      yyval.i = (1<<(yyvsp[0].i)) | (yyvsp[-2].i<<8);
					  else {
					      _modrm.nsyms = _modrm.addr32 = _modrm.addr16 = _modrm.offset = _modrm.regs = 0;
					      djerror("Scale must be 1,2,4 or 8");
					  }
					;
    break;}
case 299:
#line 1272 "djasm.y"
{ if (yyvsp[0].i>=0 && yyvsp[0].i<=3)
					      yyval.i = (1<<(yyvsp[-2].i)) | (0x100<<yyvsp[0].i);
					  else {
					      _modrm.nsyms = _modrm.addr32 = _modrm.addr16 = _modrm.offset = _modrm.regs = 0;
					      djerror("Shift must be 0,1,2 or 3");
					  }
					;
    break;}
case 300:
#line 1282 "djasm.y"
{ yyval.i = yyvsp[0].i; ;
    break;}
case 301:
#line 1283 "djasm.y"
{ yyval.i = yyvsp[0].sym->value; ;
    break;}
case 302:
#line 1284 "djasm.y"
{ yyval.i = pc_symbol.value; ;
    break;}
case 303:
#line 1285 "djasm.y"
{ yyval.i = yyvsp[-2].i || yyvsp[0].i; ;
    break;}
case 304:
#line 1286 "djasm.y"
{ yyval.i = yyvsp[-2].i | yyvsp[0].i; ;
    break;}
case 305:
#line 1287 "djasm.y"
{ yyval.i = yyvsp[-2].i ^ yyvsp[0].i; ;
    break;}
case 306:
#line 1288 "djasm.y"
{ yyval.i = yyvsp[-2].i && yyvsp[0].i; ;
    break;}
case 307:
#line 1289 "djasm.y"
{ yyval.i = yyvsp[-2].i & yyvsp[0].i; ;
    break;}
case 308:
#line 1290 "djasm.y"
{ yyval.i = yyvsp[-2].i == yyvsp[0].i; ;
    break;}
case 309:
#line 1291 "djasm.y"
{ yyval.i = yyvsp[-2].i > yyvsp[0].i; ;
    break;}
case 310:
#line 1292 "djasm.y"
{ yyval.i = yyvsp[-2].i < yyvsp[0].i; ;
    break;}
case 311:
#line 1293 "djasm.y"
{ yyval.i = yyvsp[-2].i >= yyvsp[0].i; ;
    break;}
case 312:
#line 1294 "djasm.y"
{ yyval.i = yyvsp[-2].i <= yyvsp[0].i; ;
    break;}
case 313:
#line 1295 "djasm.y"
{ yyval.i = yyvsp[-2].i != yyvsp[0].i; ;
    break;}
case 314:
#line 1296 "djasm.y"
{ yyval.i = yyvsp[-2].i << yyvsp[0].i; ;
    break;}
case 315:
#line 1297 "djasm.y"
{ yyval.i = yyvsp[-2].i >> yyvsp[0].i; ;
    break;}
case 316:
#line 1298 "djasm.y"
{ yyval.i = yyvsp[-2].i + yyvsp[0].i; ;
    break;}
case 317:
#line 1299 "djasm.y"
{ yyval.i = yyvsp[-2].i - yyvsp[0].i; ;
    break;}
case 318:
#line 1300 "djasm.y"
{ yyval.i = yyvsp[-2].i * yyvsp[0].i; ;
    break;}
case 319:
#line 1301 "djasm.y"
{ yyval.i = yyvsp[-2].i / yyvsp[0].i; ;
    break;}
case 320:
#line 1302 "djasm.y"
{ yyval.i = yyvsp[-2].i % yyvsp[0].i; ;
    break;}
case 321:
#line 1303 "djasm.y"
{ yyval.i = -yyvsp[0].i; ;
    break;}
case 322:
#line 1304 "djasm.y"
{ yyval.i = !yyvsp[0].i; ;
    break;}
case 323:
#line 1305 "djasm.y"
{ yyval.i = ~yyvsp[0].i; ;
    break;}
case 324:
#line 1306 "djasm.y"
{ yyval.i = yyvsp[-1].i; ;
    break;}
case 325:
#line 1310 "djasm.y"
{ yyval.sym = yyvsp[0].sym; ;
    break;}
case 326:
#line 1311 "djasm.y"
{ yyval.sym = yyvsp[0].sym; ;
    break;}
case 327:
#line 1315 "djasm.y"
{ yyval.relsym.sym = yyvsp[-1].sym; yyval.relsym.ofs = yyvsp[0].i; ;
    break;}
case 328:
#line 1316 "djasm.y"
{ yyval.relsym.sym = zerosym; yyval.relsym.ofs = yyvsp[0].i; ;
    break;}
case 329:
#line 1320 "djasm.y"
{ yyval.i = yyvsp[0].i; ;
    break;}
case 330:
#line 1321 "djasm.y"
{ yyval.i = -yyvsp[0].i; ;
    break;}
case 331:
#line 1322 "djasm.y"
{ yyval.i = 0; ;
    break;}
}

#line 705 "c:/djgpp/lib/bison.sim"


  yyvsp -= yylen;
  yyssp -= yylen;
#if YYLSP_NEEDED
  yylsp -= yylen;
#endif

#if YYDEBUG
  if (yydebug)
    {
      short *yyssp1 = yyss - 1;
      YYFPRINTF (stderr, "state stack now");
      while (yyssp1 != yyssp)
	YYFPRINTF (stderr, " %d", *++yyssp1);
      YYFPRINTF (stderr, "\n");
    }
#endif

  *++yyvsp = yyval;
#if YYLSP_NEEDED
  *++yylsp = yyloc;
#endif

  /* Now `shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTBASE] + *yyssp;
  if (yystate >= 0 && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTBASE];

  goto yynewstate;


/*------------------------------------.
| yyerrlab -- here on detecting error |
`------------------------------------*/
yyerrlab:
  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;

#ifdef YYERROR_VERBOSE
      yyn = yypact[yystate];

      if (yyn > YYFLAG && yyn < YYLAST)
	{
	  YYSIZE_T yysize = 0;
	  char *yymsg;
	  int yyx, yycount;

	  yycount = 0;
	  /* Start YYX at -YYN if negative to avoid negative indexes in
	     YYCHECK.  */
	  for (yyx = yyn < 0 ? -yyn : 0;
	       yyx < (int) (sizeof (yytname) / sizeof (char *)); yyx++)
	    if (yycheck[yyx + yyn] == yyx)
	      yysize += yystrlen (yytname[yyx]) + 15, yycount++;
	  yysize += yystrlen ("parse error, unexpected ") + 1;
	  yysize += yystrlen (yytname[YYTRANSLATE (yychar)]);
	  yymsg = (char *) YYSTACK_ALLOC (yysize);
	  if (yymsg != 0)
	    {
	      char *yyp = yystpcpy (yymsg, "parse error, unexpected ");
	      yyp = yystpcpy (yyp, yytname[YYTRANSLATE (yychar)]);

	      if (yycount < 5)
		{
		  yycount = 0;
		  for (yyx = yyn < 0 ? -yyn : 0;
		       yyx < (int) (sizeof (yytname) / sizeof (char *));
		       yyx++)
		    if (yycheck[yyx + yyn] == yyx)
		      {
			const char *yyq = ! yycount ? ", expecting " : " or ";
			yyp = yystpcpy (yyp, yyq);
			yyp = yystpcpy (yyp, yytname[yyx]);
			yycount++;
		      }
		}
	      yyerror (yymsg);
	      YYSTACK_FREE (yymsg);
	    }
	  else
	    yyerror ("parse error; also virtual memory exhausted");
	}
      else
#endif /* defined (YYERROR_VERBOSE) */
	yyerror ("parse error");
    }
  goto yyerrlab1;


/*--------------------------------------------------.
| yyerrlab1 -- error raised explicitly by an action |
`--------------------------------------------------*/
yyerrlab1:
  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse lookahead token after an
	 error, discard it.  */

      /* return failure if at end of input */
      if (yychar == YYEOF)
	YYABORT;
      YYDPRINTF ((stderr, "Discarding token %d (%s).\n",
		  yychar, yytname[yychar1]));
      yychar = YYEMPTY;
    }

  /* Else will try to reuse lookahead token after shifting the error
     token.  */

  yyerrstatus = 3;		/* Each real token shifted decrements this */

  goto yyerrhandle;


/*-------------------------------------------------------------------.
| yyerrdefault -- current state does not do anything special for the |
| error token.                                                       |
`-------------------------------------------------------------------*/
yyerrdefault:
#if 0
  /* This is wrong; only states that explicitly want error tokens
     should shift them.  */

  /* If its default is to accept any token, ok.  Otherwise pop it.  */
  yyn = yydefact[yystate];
  if (yyn)
    goto yydefault;
#endif


/*---------------------------------------------------------------.
| yyerrpop -- pop the current state because it cannot handle the |
| error token                                                    |
`---------------------------------------------------------------*/
yyerrpop:
  if (yyssp == yyss)
    YYABORT;
  yyvsp--;
  yystate = *--yyssp;
#if YYLSP_NEEDED
  yylsp--;
#endif

#if YYDEBUG
  if (yydebug)
    {
      short *yyssp1 = yyss - 1;
      YYFPRINTF (stderr, "Error: state stack now");
      while (yyssp1 != yyssp)
	YYFPRINTF (stderr, " %d", *++yyssp1);
      YYFPRINTF (stderr, "\n");
    }
#endif

/*--------------.
| yyerrhandle.  |
`--------------*/
yyerrhandle:
  yyn = yypact[yystate];
  if (yyn == YYFLAG)
    goto yyerrdefault;

  yyn += YYTERROR;
  if (yyn < 0 || yyn > YYLAST || yycheck[yyn] != YYTERROR)
    goto yyerrdefault;

  yyn = yytable[yyn];
  if (yyn < 0)
    {
      if (yyn == YYFLAG)
	goto yyerrpop;
      yyn = -yyn;
      goto yyreduce;
    }
  else if (yyn == 0)
    goto yyerrpop;

  if (yyn == YYFINAL)
    YYACCEPT;

  YYDPRINTF ((stderr, "Shifting error token, "));

  *++yyvsp = yylval;
#if YYLSP_NEEDED
  *++yylsp = yylloc;
#endif

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturn;

/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturn;

/*---------------------------------------------.
| yyoverflowab -- parser overflow comes here.  |
`---------------------------------------------*/
yyoverflowlab:
  yyerror ("parser stack overflow");
  yyresult = 2;
  /* Fall through.  */

yyreturn:
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif
  return yyresult;
}
#line 1325 "djasm.y"
 /***********************************************************************/

typedef struct FileStack {
  struct FileStack *prev;
  FILE *f;
  int line;
  char *name;
} FileStack;

FileStack *file_stack = 0;

FILE *infile;
FILE *outfile;

int scmp_a(void const *a, void const *b)
{
  return strcmp((*(Symbol **)a)->name, (*(Symbol **)b)->name);
}

int scmp_n(void const *a, void const *b)
{
  return (*(Symbol **)a)->value - (*(Symbol **)b)->value;
}

static int
opcode_compare (const void *e1, const void *e2)
{
  return strcmp (((struct opcode *)e1)->name, ((struct opcode *)e2)->name);
}

int main(int argc, char **argv)
{
  Symbol *s;
  Patch *p;
  unsigned char exe[EXE_HEADER_SIZE+4];
  int symcount = 0;
  int min_uninit;
  time_t now;
  char *outfilename, *leader;
  char *current_map_file;

  /* Sort the opcodes now so that we can use `bsearch' later.  */
  qsort (opcodes,
	 sizeof (opcodes) / sizeof (opcodes[0]),
	 sizeof (opcodes[0]),
	 opcode_compare);
  zerosym = set_symbol (get_symbol ("__zero__", 1), 0);

  if (argc < 2)
  {
    fprintf(stderr,"usage: djasm infile [outfile] [mapfile]\n");
    exit(1);
  }
  inname = argv[1];
  infile = fopen(argv[1], "r");
  if (infile == 0)
  {
    fprintf(stderr, "Error: cannot open file %s for reading\n", argv[1]);
    perror("The error was");
    exit(1);
  }
  yyparse();
  fclose(infile);
  if (bsspc == -1)
  {
    bsspc = pc;
    generated_bytes = last_align_end==pc ? last_align_begin : pc;
  }

  sortsyms(scmp_a);

  for (s=symtab; s; s=s->next)
  {
    if (!istemp(s->name, 0))
      symcount++;
    if (!s->defined && s->patches)
    {
      for (p=s->patches; p; p=p->next)
	fprintf(stderr,"%s:%d: undefined symbol `%s'\n", p->filename, p->lineno, s->name);
      undefs++;
    }
  }
  if (undefs)
    return 1;
  if (total_errors)
  {
    fprintf(stderr, "%s: %d errors\n", inname, total_errors);
    return 1;
  }

  printf("%#x bytes generated, %#x bytes in file, %#x bytes total, %d symbols\n",
    generated_bytes, bsspc, pc, symcount);

  min_uninit = (pc-bsspc+15)/16;

  memset(exe, 0, EXE_HEADER_SIZE+4);
  exe[0] = 0x4d;		/* MAGIC */
  exe[1] = 0x5a;
  exe[2] = bsspc;		/* bytes in last page */
  exe[3] = (bsspc>>8)&1;
  exe[4] = (bsspc+1023)>>9;	/* number of sectors */
  exe[5] = (bsspc+1023)>>17;
  exe[6] = 0;			/* relocation entries */
  exe[7] = 0;
  exe[8] = EXE_HEADER_BLOCKS;	/* blocks in header */
  exe[9] = 0;
  exe[10] = min_uninit;		/* min uninitialized paragraphs */
  exe[11] = (min_uninit>>8);
  exe[12] = 0xff;		/* max uninitialized paragraphs */
  exe[13] = 0xff;
  exe[14] = 0;			/* relative SS */
  exe[15] = 0;
  exe[16] = stack_ptr;		/* SP */
  exe[17] = stack_ptr>>8;
  exe[18] = 0;			/* checksum */
  exe[19] = 0;
  exe[20] = start_ptr;		/* IP */
  exe[21] = start_ptr >> 8;
  exe[22] = 0;			/* relative CS */
  exe[23] = 0;

  /* These must be zero, otherwise they are interpreted as an offset to 
     a "new executable" header. */
  exe[60] = 0;
  exe[61] = 0;
  exe[62] = 0;
  exe[63] = 0;
#define INFO_TEXT_START (64)

  time(&now);

  sprintf(exe+INFO_TEXT_START, "\r\n%s generated from %s by djasm, on %.24s\r\n", argv[2], argv[1], ctime(&now));
  if (copyright)
    strncat(exe+INFO_TEXT_START, copyright, (512-3-INFO_TEXT_START)-strlen(exe+INFO_TEXT_START)); /* -3 for the following line: */
  strcat(exe+INFO_TEXT_START, "\r\n\032");

  if (argv[2] == 0)
  {
    char *dot=0, *sl=0, *cp;
    outfilename = (char *)malloc(strlen(argv[1])+5);
    strcpy(outfilename, argv[1]);
    for (cp=outfilename; *cp; cp++)
    {
      if (*cp == ':' || *cp == '\\' || *cp == '/')
      {
        sl = cp+1;
        dot = 0;
      }
      if (*cp == '.')
        dot = cp;
    }
    if (!dot)
    {
      dot = cp;
      *dot = '.';
    }
    strcpy(dot+1, ext_types[out_type]);
  }
  else
  {
    char *dot=0, *sl=0, *cp;
    outfilename = argv[2];
    for (cp=outfilename; *cp; cp++)
    {
      if (*cp == ':' || *cp == '\\' || *cp == '/')
      {
        sl = cp+1;
        dot = 0;
      }
      if (*cp == '.')
        dot = cp;
    }
    if (!dot)
    {
      sl = (char *)malloc(strlen(outfilename)+5);
      strcpy(sl, outfilename);
      outfilename = sl;
      dot = outfilename + strlen(outfilename);
      *dot = '.';
      strcpy(dot+1, ext_types[out_type]);
    }
    else
      set_out_type(dot+1);
  }

  switch (out_type)
  {
    case OUT_exe:
    case OUT_com:
    case OUT_bin:
    case OUT_sys:
    case OUT_obj:
      outfile = fopen(outfilename, "wb");
      break;
    case OUT_h:
    case OUT_inc:
    case OUT_s:
      outfile = fopen(outfilename, "w");
      break;
  }
  if (outfile == 0)
  {
    fprintf(stderr, "Error: cannot open file %s for writing\n", outfilename);
    perror("The error was");
    exit(1);
  }

  switch (out_type)
  {
    case OUT_exe:
      fwrite(exe, EXE_HEADER_SIZE, 1, outfile);
      fwrite(outbin, bsspc, 1, outfile);
      break;

    case OUT_com:
      fwrite(outbin+256, bsspc-256, 1, outfile);
      break;

    case OUT_bin:
    case OUT_sys:
      fwrite(outbin, bsspc, 1, outfile);
      break;

    case OUT_h:
      if (image_type == OUT_exe)
        for (i=0; i<EXE_HEADER_SIZE; i++)
        {
          fprintf(outfile, "0x%02x,", exe[i]);
          if ((i&15) == 15)
            fputc('\n', outfile);
        }
      for (i=((image_type==OUT_com)?0x100:0); i<bsspc; i++)
      {
        fprintf(outfile, "0x%02x", outbin[i]);
        if (i<bsspc-1)
          fputc(',', outfile);
        if ((i&15) == 15)
          fputc('\n', outfile);
      }
      if (i&15)
        fputc('\n', outfile);
      break;

    case OUT_inc:
    case OUT_s:
      if (out_type == OUT_inc)
        leader = INC_LEADER;
      else
        leader = S_LEADER;
      fputs(leader, outfile);
      if (image_type == OUT_exe)
        for (i=0; i<EXE_HEADER_SIZE; i++)
        {
          fprintf(outfile, "0x%02x", exe[i]);
          if ((i&15) == 15)
          {
            fputc('\n', outfile);
            fputs(leader, outfile);
          }
          else
            fputc(',', outfile);
        }
      for (i=((image_type==OUT_com)?0x100:0); i<bsspc; i++)
      {
        fprintf(outfile, "0x%02x", outbin[i]);
        if ((i&15) == 15)
        {
          fputc('\n', outfile);
          if (i<bsspc-1)
            fputs(leader, outfile);
        }
        else
          if (i<bsspc-1)
            fputc(',', outfile);
      }
      if (i&15)
        fputc('\n', outfile);
      break;
    case OUT_obj:
      write_THEADR(outfile,inname);
      write_LNAMES(outfile,"","CODE","BSS","TEXT","DATA",0);
      write_SEGDEF(outfile,bsspc,4,2,1);	/* text and data */
      write_SEGDEF(outfile,pc-bsspc,5,3,1);	/* .bss */
      write_EXTDEF(outfile,symtab);
      write_PUBDEF(outfile,symtab,bsspc);
      write_LEDATA(outfile,1,outbin,bsspc,symtab);
      write_MODEND(outfile,main_obj,start_ptr);
      break;
  }
  fclose(outfile);
  
  if (argc > 3)
  {
    FILE *mapfile = fopen(argv[3], "w");
    fprintf(mapfile, "%#x bytes generated, %#x bytes in file, %#x bytes total, %d symbols\n",
      generated_bytes, bsspc, pc, symcount);

    fprintf(mapfile, "\nStart Stop  Length Name Class\n");
    fprintf(mapfile, "%04XH %04XH %04XH  code code\n", 0, pc-1, pc);

    fprintf(mapfile, "\nAddress    Symbols by Name\n\n");
    for (s = symtab; s; s=s->next)
      if (!istemp(s->name, 0))
        fprintf(mapfile, "0000:%04X  %s (%c)\n", s->value, s->name, SYMTYPES[s->type]);
    fprintf(mapfile, "\nAddress    Symbols by Value\n\n");
    sortsyms(scmp_n);
    for (s = symtab; s; s=s->next)
      if (!istemp(s->name, 0))
        fprintf(mapfile, "0000:%04X  %s (%c)\n", s->value, s->name, SYMTYPES[s->type]);
    current_map_file = 0;
    for (i=0; i<num_lineaddr; i++)
    {
      if (current_map_file != lineaddr[i].name)
      {
	current_map_file = lineaddr[i].name;
	if ((i & 3) != 3)
	  fprintf(mapfile, "\n");
	fprintf(mapfile, "\nLine numbers for (%s)\n", current_map_file);
	num_lineaddr-=i;
	lineaddr+=i;
	i=0;
      }
      fprintf(mapfile, "%5d 0000:%04X", lineaddr[i].line, lineaddr[i].addr);
      if ((i & 3) == 3)
        fputc('\n', mapfile);
      else
        fputc(' ', mapfile);
    }
    fputc('\n', mapfile);
    fclose(mapfile);
  }
  return 0;
}

void djerror(char *s)
{
  fprintf(stderr, "%s:%d: %s\n", inname, lineno, s);
  strbuf[strbuflen] = 0;
  total_errors++;
}

void yyerror(char *s)
{
  djerror(s);
  fprintf(stderr, "%s:%d: Last token was `%s' (%s)\n", inname, lineno, last_token, yytname[(unsigned char)yytranslate[last_tret]]);
}

void
shxd_error(int opcode)
{
  char *bad_op;
  char *good_op;
  char msg[80];

  if (opcode == 4)
  {
    bad_op = "shld";
    good_op = "dshl";
  }
  else
  {
    bad_op = "shrd";
    good_op = "dshr";
  }
  sprintf(msg, "Obsolete use of `%s' detected.  Use `%s' instead.", bad_op, good_op);
  djerror(msg);
}

Symbol *get_symbol(char *name, int create)
{
  Symbol *s;
  for (s=symtab; s; s=s->next)
    if (strcmp(name, s->name) == 0)
      return s;
  if (!create)
    return 0;
  s = (Symbol *)malloc(sizeof(Symbol));
  s->next = symtab;
  symtab = s;
  s->name = (char *)malloc(strlen(name)+1);
  strcpy(s->name, name);
  s->value = 0;
  s->defined = 0;
  s->external = 0;
  s->public = 0;
  s->patches = 0;
  s->first_used = lineno;
  s->type = SYM_unknown;
  return s;
}

void
add_enum_element(Symbol * s)
{
  if (islocal(s->name) || istemp(s->name, 0))
  {
    djerror("Cannot have local or temporary labels within an enum");
  }
  else
  {
    char *id = alloca(strlen(s->name) + strlen(struct_sym) + 2);
    strcpy(id, struct_sym);
    strcat(id, ".");		/* should this be "_" to disambiguate enums
				   from structs? */
    strcat(id, s->name);
    if (!s->defined && !s->patches)
    {
      /* only delete fresh symbols */
      destroy_symbol(s, 0);
    }
    set_symbol(get_symbol(id, 1), struct_pc++);
  }
}

void add_struct_element(Symbol *s)
{
  if (islocal(s->name) || istemp(s->name,0)) {
    djerror("Cannot have local or temporary labels within a structure");
  } else {
    char *id=alloca(strlen(s->name)+strlen(struct_sym)+2);
    strcpy(id,struct_sym);
    strcat(id,".");
    strcat(id,s->name);
    if (!s->defined && !s->patches) {
      /* only delete fresh symbols */
      destroy_symbol(s,0);
    }
    if (struct_tp=='s') {
      /* .struct */
      set_symbol(get_symbol(id,1),struct_pc);
    } else {
      /* .union */
      set_symbol(get_symbol(id,1),0);
    }
  }
}

int is_structure(Symbol *s)
{
  char *n=s->name;
  size_t l=strlen(n);
  if (!s->next) {
    /* the elements of a struct or union always follow the symbol */
    return 0;
  }
  s=s->next;
  if (strncmp(n,s->name,l) || s->name[l]!='.') {
    /* Structure elements always have the structure name followed by a period before
     * the element name.
     */
    return 0;
  }
  return 1;
}

int set_structure_symbols(Symbol *ele, Symbol *struc, int tp, int base, int type)
{
  if (!struc->defined) {
    djerror("undefined symbol used in struct");
    return 0;
  }
  if (!is_structure(struc)) {
    djerror("symbol must be a .struct or .union");
    return 0;
  }
  set_symbol(ele,base)->type|=type;
  {
    int sLen=strlen(struc->name);
    int eLen=strlen(ele->name);
    Symbol *s=struc->next;
    while (s && !strncmp(s->name,struc->name,sLen) && s->name[sLen]=='.') {
      char *id=alloca(strlen(s->name)-sLen+eLen+1);
      strcpy(id,ele->name);
      strcpy(id+eLen,s->name+sLen);
      set_symbol(get_symbol(id,1),base+s->value)->type|=type;
      s=s->next;
    }
  }
  return 1;
}

void emit_struct(Symbol *ele, int tp, Symbol *struc)
{
  int i;

  if (set_structure_symbols(ele,struc,tp,pc,(pc?SYM_data:SYM_code)))
    for (i = 0; i < struc->value; i++)
      emitb(0); /* only unitialized structures supported */
}

void emit_struct_abs(Symbol *ele, int tp, Symbol *struc, int offset)
{
  /* NOTE: Does not actually emit any bytes! (by design) */
  set_structure_symbols(ele,struc,tp,offset,(offset?SYM_data:SYM_code));
}

void build_struct(Symbol *ele, int tp, Symbol *struc)
{
  if (ele && (islocal(ele->name) || istemp(ele->name,0))) {
    djerror("Cannot have local or temporary labels within a structure");
  } else {
    char *id=alloca((ele?strlen(ele->name):0)+strlen(struct_sym)+2);
    Symbol *sym;
    strcpy(id,struct_sym);
    if (ele) {
      strcat(id,".");
      strcat(id,ele->name);
      if (!ele->defined && !ele->patches) {
	/* only delete fresh symbols */
	destroy_symbol(ele,0);
      }
    }
    sym=get_symbol(id,1);
    if (!ele) {
	symtab=symtab->next;
	sym->next=0;
    }
    set_structure_symbols(sym,struc,tp,(struct_tp=='s')?struct_pc:0,SYM_abs);
    if (!ele) {
      destroy_symbol(sym,0);
    }
    if (struct_tp=='s')
      struct_pc+=struc->value;
    else
      struct_pc=MAX(struct_pc,struc->value);
  }
}
					
Symbol *set_symbol(Symbol *s, int value)
{
  if (!islocal(s->name) && !istemp(s->name,0))
    destroy_locals();
  if (istemp(s->name, 'b'))
    s->defined = 0;
  if (s->defined)
    fprintf(stderr,"%s:%d: warning: symbol %s redefined\n", inname, lineno, s->name);
  s->value = value;
  s->defined = 1;
  while (s->patches)
  {
    int v=0, o=0;
    unsigned char *cp;
    Patch *p = s->patches;
    s->patches = s->patches->next;
    switch (p->rel)
    {
    case REL_abs:
    case REL_abs32:
      v = value;
      break;
    case REL_16:
      v = value - p->location - 2;
      break;
    case REL_8:
      v = value - p->location - 1;
      break;
    }
    cp = outbin + p->location;
    switch (p->rel)
    {
    case REL_abs32:
      o = (signed long)(cp[0] | (cp[1] << 8) | (cp[2] << 16) | (cp[3] << 24));
      break;
    case REL_abs:
    case REL_16:
      o = (signed short)(cp[0] | (cp[1] << 8));
      break;
    case REL_8:
      o = (signed char)(cp[0]);
      break;
    }
    o += v;
    switch (p->rel)
    {
    case REL_abs32:
      cp[3] = o>>24;
      cp[2] = o>>16;
      /* fall through */
    case REL_abs:
    case REL_16:
      cp[1] = o>>8;
      cp[0] = o;
      break;
    case REL_8:
      if (o > 127 || o < -128)
      {
	/* So far away from me
	   So far I just can't see
	   So far away from me
	   You're so far away from me
	   -- from `So far away' by Mark Knopfler.  */
	fprintf(stderr, "%s:%d: 8-bit relocation too big (%d); use long form\n", p->filename, p->lineno, o);
	total_errors++;
      }
      cp[0] = o;
      break;
    }
    free(p);
  }
  if (istemp(s->name, 'f'))
    s->defined = 0;
  return s;
}

void destroy_symbol(Symbol *sym, int undef_error)
{
  Symbol **s=&symtab;
  while (*s)
  {
    if (*s==sym)
    {
      Symbol *_s=*s;
      if (undef_error && !_s->defined && _s->patches)
      {
	Patch *p,*_p;
	for (p=_s->patches; p; p=_p) {
	  fprintf(stderr,"%s:%d: undefined symbol `%s'\n", p->filename, p->lineno, _s->name);
	  _p=p->next;
	  free(p);
	}
	undefs++;
      }
      _s=(*s)->next;
      free(*s);
      *s=_s;
    }
    else
    {
      s=&(*s)->next;
    }
  }
}

void destroy_locals(void)
{
  Symbol **s=&symtab;
  while (*s)
  {
    if (islocal((*s)->name))
    {
      Symbol *_s=*s;
      if (!_s->defined && _s->patches)
      {
	Patch *p,*_p;
	for (p=_s->patches; p; p=_p) {
	  fprintf(stderr,"%s:%d: undefined symbol `%s'\n", p->filename, p->lineno, _s->name);
	  _p=p->next;
	  free(p);
	}
	undefs++;
      }
      _s=(*s)->next;
      free(*s);
      *s=_s;
    }
    else
    {
      s=&(*s)->next;
    }
  }
}

void sortsyms(int (*sortf)(void const *,void const *))
{
  int ns, i;
  Symbol *s, **st;
  if (!symtab)
    return;
  for (s=symtab, ns=0; s; s=s->next)
    ns ++;
  st = (Symbol **)malloc(sizeof(Symbol *) * ns);
  for (s=symtab, ns=0; s; s=s->next, ns++)
    st[ns] = s;
  qsort(st, ns, sizeof(Symbol *), sortf);
  for (i=0; i<ns-1; i++)
    st[i]->next = st[i+1];
  st[i]->next = 0;
  symtab = st[0];
  free(st);
}

void emit(void *ptr, int len)
{
  while (pc + len > outsize)
  {
    outsize += 512;
    outbin = realloc(outbin, outsize);
  }
  set_lineaddr();
  memcpy(outbin+pc, ptr, len);
  pc += len;
}

void emitb(int b)
{
  unsigned char c = b;
  emit(&c, 1);
}

void emitw(int w)
{
  emitb(w);
  emitb(w>>8);
}

void emitd(long d)
{
  emitw(d);
  emitw(d>>16);
}

void emits(Symbol *s, int offset, int rel)
{
  Patch *p;
  int v;
  if (s->defined)
  {
    switch (rel)
    {
    case REL_abs32:
      v = s->value + offset;
      emitd(v);
      break;
    case REL_abs:
      v = s->value + offset;
      emitw(v);
      break;
    case REL_abs8:
      v = s->value + offset;
      emitb(v);
      break;
    case REL_16:
      v = s->value - pc - 2 + offset;
      emitw(v);
      break;
    case REL_8:
      v = s->value - pc - 1 + offset;
      if (v < -128 || v > 127)
      {
	fprintf(stderr, "%s:%d: 8-bit relocation too big (%d); use long form\n", inname, lineno, v);
	total_errors++;
      }
      emitb(v);
      break;
    }
    return;
  }
  p = (Patch *)malloc(sizeof(Patch));
  p->next = s->patches;
  s->patches = p;
  p->location = pc;
  p->lineno = lineno;
  p->filename = inname;
  p->rel = rel;
  switch (rel)
  {
  case REL_abs32:
    emitd(offset);
    break;
  case REL_abs:
  case REL_16:
    emitw(offset);
    break;
  case REL_8:
    if (offset < -128 || offset > 127)
    {
      fprintf(stderr, "%s:%d: 8-bit relocation offset too big (%d); use long form\n", inname, lineno, offset);
      total_errors++;
    }
    emitb(offset);
    break;
  }
}

void modrm(int mod, int reg, int rm)
{
  emitb((mod<<6) | (reg<<3) | rm);
}

int findreg(int regbits)
{
  int i=0;
  while (regbits) {
    regbits>>=1;
    i++;
  }
  return i?i-1:4;
}

int findscl(int sclbits)
{
  static int bits[]={0,0,1,0,2,0,0,0,3};
  return bits[sclbits];
}

int nooffset(int mbyte, int needsib)
{
    if (_modrm.offset == 0 && _modrm.nsyms == 0) {
      emitb(mbyte);
      if (needsib)
	emitb(mbyte>>8);
      if (mbyte&0100)
        emitb(0);
      _modrm.nsyms = _modrm.addr32 = _modrm.addr16 = _modrm.offset = _modrm.regs = 0;
      return 1;
    }
    return 0;
}

int reg2mbyte[] = { 0x48, 0x88, 0x60, 0xa0, 0x40, 0x80, 0x20, 0x08 };

void reg(int which)
{
  int i;
  int v;
  int mbyte = which << 3;
  int needsib = 0;

  if (_modrm.regs == 0) {
    /* This handles the case of displacement only addressing (no register
     * ofsets)
     */
    mbyte=movacc ? movacc : mbyte + (_modrm.addr32 ? 5 : 6);
    movacc=0;
  } else if (_modrm.regs == 0x20 && _modrm.offset == 0 && _modrm.nsyms == 0) {
    /* [bp+0] */
    nooffset(mbyte|0106,0);
    return;
  } else {
    if (_modrm.addr32) {
      if (_modrm.addr32&0xff) {
	int sib= findreg( _modrm.addr32     &0xff)    |
	        (findreg((_modrm.addr32>>8 )&0xff)<<3)|
	        (findscl((_modrm.addr32>>16)&0x0f)<<6);
	if (sib==045 && _modrm.offset == 0 && _modrm.nsyms == 0) {
	  /* [ebp+0] */
	  nooffset(mbyte|0104|(045<<8),1);
	  return;
	} else if (sib==044) {
	  /* [esp] */
	  mbyte|=(sib<<8)|004;
	  needsib=1;
	} else if ((sib&070)==0040) {
	  /* no index */
	  mbyte|=sib&007;
	} else if ((sib&007)==0005) {
	  /* ebp is base */
	  mbyte|=(sib<<8)|004;
	  needsib=1;
	  if (nooffset(mbyte|0100,1))
	    return;
	} else {
	  mbyte|=(sib<<8)|004;
	  needsib=1;
	}
	if (nooffset(mbyte,needsib))
	  return;
	mbyte|=0200;
      } else {
	int sib=(005				     )|
	        (findreg((_modrm.addr32>>8 )&0xff)<<3)|
		(findscl((_modrm.addr32>>16)&0x0f)<<6);
	mbyte&=070;
	mbyte|=(sib<<8)|004;
	needsib=1;
	if (nooffset(mbyte,1))
	  return;
      }
    } else {
      /* 16 bit addressing */
      for (i=0; i<8; i++)
	if (reg2mbyte[i] == _modrm.regs)
	{
	  mbyte |= i;
	  break;
	}
      if (i == 8)
      {
	fprintf(stderr,"%s:%d: Invalid registers in R/M\n", inname, lineno);
	total_errors ++;
      }
      if (nooffset(mbyte,needsib))
	return;
      mbyte|=0200;
    }
  }

  v = _modrm.offset;
  for (i=0; i<_modrm.nsyms; i++)
  {
    Symbol *s = _modrm.syms[i];
    if (s->defined)
      v += s->value;
    else
    {
      Patch *p;
      p = (Patch *)malloc(sizeof(Patch));
      p->next = s->patches;
      s->patches = p;
      p->location = pc+1+needsib; /* ALL bytes emitted below, accounts for yet to be emitted mbyte */
      p->lineno = lineno;
      p->filename = inname;
      p->rel = _modrm.addr32 ? REL_abs32 : REL_abs;
      _modrm.regs=0; /* force offset field to be full size (2/4 bytes rather than 1) */
    }
  }
  if (_modrm.regs && v>=-128 && v<=127) {
    emitb(mbyte^0300); /* change mod from 2/4 ((d)word offset) to 1 (byte offset) */
    if (needsib)
      emitb(mbyte>>8);
    emitb(v);
  } else {
    emitb(mbyte);
    if (needsib)
      emitb(mbyte>>8);
    if (_modrm.addr32)
      emitd(v);
    else
      emitw(v);
  }

  _modrm.nsyms = _modrm.addr32 = _modrm.addr16 = _modrm.offset = _modrm.regs = 0;
}

void addr32(int sib)
{
  char *err=0;

  if (_modrm.addr16) {
    err="Cannot mix 16 and 32 bit addressing";
  } else {
    if (!_modrm.addr32) emitb(0x67);
    _modrm.addr32|=0x1000000;
    if ((sib&0xf00)>0x100) {
      if ((sib&0xff)==0x10) {
	err="esp cannot be scaled";
      } else if (_modrm.addr32&0xff00) {
	err="scaled index already used";
      } else {
	_modrm.addr32|=sib<<8;
      }
    } else {
      if (!(_modrm.addr32&0xff)) {
	_modrm.addr32|=(sib&0xff)|0x1000000;
      } else if (!(_modrm.addr32&0xff00)) {
	if ((sib&0xff)==0x10) {
	  if ((_modrm.addr32&0xff)==0x10) {
	    err="esp cannot be the index";
	  } else {
	    _modrm.addr32=(_modrm.addr32&0xff)<<8;
	    _modrm.addr32|=(sib&0xff)|0x1010000;
	  }
	} else {
	  _modrm.addr32|=sib<<8;
	}
      } else {
	err="scaled index already used";
      }
    }
  }
  if (err) {
    djerror(err);
    _modrm.nsyms = _modrm.addr32 = _modrm.addr16 = _modrm.offset = _modrm.regs = 0;
  } else {
    _modrm.regs=-1;
  }
}

int yylex(void)
{
  last_tret = yylex1();
  return last_tret;
}

static struct {
  char c1, c2;
  int token;
} twochars[] = {
  {'=', '=', '='},
  {'>', '=', OP_GE},
  {'<', '=', OP_LE},
  {'<', '>', OP_NE},
  {'!', '=', OP_NE},
  {'&', '&', OP_AND},
  {'|', '|', OP_OR},
  {'<', '<', OP_SHL},
  {'>', '>', OP_SHR}
};

int yylex1(void)
{
  int c, c2, i, oldc;
  struct opcode *opp, op;

  do {
    c = fgetc(infile);
  } while (c == ' ' || c == '\t');

  switch (c)
  {
    case EOF:
      if (file_stack)
      {
        FileStack *tmp = file_stack;
        fclose(infile);
        /*free(inname);*/ /* needed by lineaddr_s and Patch */
        lineno = file_stack->line + 1; /* Correct for .include line */
        infile = file_stack->f;
        inname = file_stack->name;
        file_stack = file_stack->prev;
        free(tmp);
        return yylex1();
      }
      return 0;

    case 'a' ... 'z':
    case 'A' ... 'Z':
    case '_':
    case '$':
    case '.':
    case '@':
    case '?':
      if (c=='?')
	{
	  strbuf[0]=c;
	  fscanf(infile, "%[a-zA-Z0-9_$.@]", strbuf+1);
	}
      else
	{
	  ungetc(c, infile);
	  fscanf(infile, "%[a-zA-Z0-9_$.@]", strbuf);
	}
      strcpy(last_token, strbuf);
      if (strcmp(strbuf, ".") == 0)
        return PC;
      op.name = strbuf;
      opp = bsearch (&op,
		     opcodes, 
		     sizeof (opcodes) / sizeof (opcodes[0]),
		     sizeof (opcodes[0]),
		     opcode_compare);
      if (opp)
	{
	  yylval.i = opp->attr;
	  return opp->token;
	}
      else
	{
	  yylval.sym = get_symbol(strbuf,1);
	  return yylval.sym->defined ? KID : UID;
	}

    case '0' ... '9':
    #ifdef __linux
      /* fscanf "%i" doesn't work reliably with libc5.4.44 for large hex nubmers */
      if (c == '0')
        {
	  /* octal or hex */
	  yylval.i = 0;
	  c = fgetc (infile);
	  if (c == 'x' || c == 'X')
	    {
	      while (1)
		{
		  c = fgetc (infile);
		  if (!isxdigit (c))
		    {
		      ungetc(c, infile);
		      break;
		    }
		  c = toupper (c);
		  if (c > '9')
		    c -= 'A' - '9' - 1;
		  yylval.i *= 16;
		  yylval.i += c - '0';
		}
	    }
	  else if (c >= '0' && c <= '7')
	    {
	      yylval.i = c - '0';
	      while (1)
		{
		  c = fgetc (infile);
		  if (!(c >= '0' && c <= '7'))
		    {
		      ungetc(c, infile);
		      break;
		    }
		  yylval.i *= 8;
		  yylval.i += c - '0';
		}
	    }
	  else
	    ungetc(c, infile);
	}
      else
        {
	  yylval.i = c - '0';
	  while (1)
	    {
	      c = fgetc (infile);
	      if (!isdigit (c))
		{
		  ungetc(c, infile);
		  break;
		}
	      yylval.i *= 10;
	      yylval.i += c - '0';
	    }
        }
    #else
      ungetc(c, infile);
      fscanf(infile, "%i", &(yylval.i));
    #endif
      sprintf(last_token, "%d", yylval.i);
      return NUMBER;
      break;

    case '>':
    case '<':
    case '!':
    case '&':
    case '|':
    case '=':
      c2 = fgetc (infile);
      for (i = 0; i < 9; i++)
	if (c == twochars[i].c1 && c2 == twochars[i].c2)
	  return twochars[i].token;
      ungetc (c2, infile);
      return c;

    case '"':
    case '\'':
      oldc = c;
      i = 0;
      while (1)
      {
        c = fgetc(infile);
        if (c == oldc)
        {
          strcpy(last_token, strbuf);
          strbuflen = i;
          if (strbuflen == 1)
          {
            yylval.i = strbuf[0];
            return NUMBER;
          }
          return STRING;
	}
        switch (c)
        {
          case '\\':
            switch (c = fgetc(infile))
            {
              case '0':
                strbuf[i++] = 0;
                break;
              case 'n':
                strbuf[i++] = '\n';
                break;
              case 'r':
                strbuf[i++] = '\r';
                break;
              case 't':
                strbuf[i++] = '\t';
                break;
              default:
                strbuf[i++] = c;
                break;
            }
            break;
          default:
            strbuf[i++] = c;
            break;
        }
      }
      abort ();
    case ';':
      while (fgetc(infile) != '\n');
      c = '\n';
      /* Fall through.  */
    case '\n':
      strcpy(last_token, "NL");
      return c;
    default:
      sprintf(last_token, "<%c>", c);
      return c;
  }
}

int istemp(char *symname, char which)
{
  if (symname[0] != '@') return 0;
  if (which)
  {
    if (symname[1] != which) return 0;
  }
  else
  {
    if (symname[1] != 'f' && symname[1] != 'b') return 0;
  }
  if (!isdigit((unsigned char)symname[2])) return 0;
  if (symname[3]) return 0;
  return 1;
}

int islocal(char *symname)
{
  if (symname[0]!='?') return 0;
  return 1;
}

void do_sreg_pop(int sreg)
{
  switch (sreg)
  {
    case 0: /* es */
      emitb(0x07);
      break;
    case 1: /* cs */
      djerror("Cannot pop CS");
      break;
    case 2: /* ss */
      emitb(0x17);
      break;
    case 3: /* ds */
      emitb(0x1f);
      break;
    case 4: /* fs */
      emitb(0x0f);
      emitb(0xa1);
      break;
    case 5: /* gs */
      emitb(0x0f);
      emitb(0xa9);
      break;
  }
}

void do_sreg_push(int sreg)
{
  switch (sreg)
  {
    case 0: /* es */
      emitb(0x06);
      break;
    case 1: /* cs */
      emitb(0x0e);
      break;
    case 2: /* ss */
      emitb(0x16);
      break;
    case 3: /* ds */
      emitb(0x1e);
      break;
    case 4: /* fs */
      emitb(0x0f);
      emitb(0xa0);
      break;
    case 5: /* gs */
      emitb(0x0f);
      emitb(0xa8);
      break;
  }
}

void set_lineaddr()
{
  static int last_lineno = -1;
  if (lineno == last_lineno)
    return;
  last_lineno = lineno;
  if (num_lineaddr == max_lineaddr)
  {
    max_lineaddr += 32;
    if (lineaddr)
      lineaddr = (lineaddr_s *)realloc(lineaddr, max_lineaddr * sizeof(lineaddr_s));
    else
      lineaddr = (lineaddr_s *)malloc(max_lineaddr * sizeof(lineaddr_s));
  }
  lineaddr[num_lineaddr].line = lineno;
  lineaddr[num_lineaddr].addr = pc;
  lineaddr[num_lineaddr].name = inname;
  num_lineaddr++;
}

void do_align(int p2, int val)
{
  size_t offset;

  if (image_type == OUT_com)
    offset = 0;
  else
    offset = EXE_HEADER_SIZE;

  last_align_begin = pc;
  while ((pc+offset) % p2)
    emitb(val);
  last_align_end = pc;
}

void add_copyright(char *buf)
{
  char *tmp;
  if (copyright == 0)
  {
    copyright = (char *)malloc(strlen(buf)+1);
    strcpy(copyright, buf);
    return;
  }
  tmp = (char *)malloc(strlen(copyright) + strlen(buf) + 3);
  strcpy(tmp, copyright);
  strcat(tmp, "\r\n");
  strcat(tmp, buf);
  free(copyright);
  copyright = tmp;
}

void add_rcs_ident(char *buf)
{
  char tmp[500];
  time_t now;
  struct tm *tm;
  time(&now);
  tm = localtime(&now);
  sprintf(tmp, "%cId: %s built %04d-%02d-%02d %02d:%02d:%02d by djasm $\n",
	  '$', inname,
	  tm->tm_year + 1900,
	  tm->tm_mon + 1,
	  tm->tm_mday,
	  tm->tm_hour,
	  tm->tm_min,
	  tm->tm_sec);
  add_copyright(tmp);
  sprintf(tmp, "@(#) %s built %04d-%02d-%02d %02d:%02d:%02d by djasm\n",
	  inname,
	  tm->tm_year + 1900,
	  tm->tm_mon + 1,
	  tm->tm_mday,
	  tm->tm_hour,
	  tm->tm_min,
	  tm->tm_sec);
  add_copyright(tmp);
}

void set_out_type(char *t)
{
  int i;
  for (i=0; ext_types[i]; i++)
  {
    if (strcmp(ext_types[i], t) == 0)
    {
      out_type = i;
      return;
    }
  }
  fprintf(stderr,"Unknown output type: `%s'\n", t);
}

void set_image_type(char *t)
{
  int i;
  for (i=0; ext_types[i]; i++)
  {
    if (strcmp(ext_types[i], t) == 0)
    {
      if (i == OUT_com && image_type != OUT_com)
      {
        if (pc)
        {
          fprintf(stderr, "Cannot make com file without .type \"com\"\n");
          exit(1);
        }
        while (pc < 0x100)
          emitb(0x90);
      }
      image_type = i;
      return;
    }
  }
  fprintf(stderr,"Unknown output type: `%s'\n", t);
}

void do_include(char *fname)
{
  FILE *f;
  FileStack *fs;
  
  f = fopen(fname, "r");
  if (!f)
  {
    fprintf(stderr, "%s:%d: error openning `%s'", inname, lineno, fname);
    perror("");
    return;
  }
  fs = (FileStack *)malloc(sizeof(FileStack));
  fs->line = lineno;
  fs->prev = file_stack;
  fs->f = infile;
  fs->name = inname;
  file_stack = fs;

  infile = f;
  inname = (char *)malloc(strlen(fname)+1);
  strcpy(inname, fname);
  lineno = 1;
}

/* #define DEBUG_RELOC */

void do_linkcoff (char *filename)
{
  long len;
  int f;
  char *data, *p;
  char *coff_filename;
  FILHDR *header;
  SCNHDR *f_thdr;		/* Text section header */
  SCNHDR *f_dhdr;		/* Data section header */
  SCNHDR *f_bhdr;		/* Bss section header */
/*  AOUTHDR f_ohdr;*/		/* Optional file header (a.out) */
  SYMENT *symbol;
  RELOC *rp;
  int cnt;
  size_t i;
  void *base;
  int textbase, database, bssbase/*, delta*/;
  char smallname[9];
  unsigned char *cp;

  f = open (filename, O_RDONLY | O_BINARY);
  if (f < 0)
    {
      fprintf(stderr, "%s:%d: error openning `%s'", inname, lineno, filename);
      perror("");
      return;
    }
  len = lseek (f, 0L, SEEK_END);
  lseek (f, 0L, SEEK_SET);
  data = alloca (len);
  read (f, data, (unsigned)len);
  close (f);

  header = (FILHDR *) data;
  f_thdr = (void *)data + sizeof (FILHDR) + header->f_opthdr;
  f_dhdr = f_thdr + 1;
  f_bhdr = f_dhdr + 1;
  if (I386BADMAG (*header)
      || header->f_nscns != 3
      || strcmp (f_thdr->s_name, _TEXT)
      || strcmp (f_dhdr->s_name, _DATA)
      || strcmp (f_bhdr->s_name, _BSS))
    {
      fprintf (stderr, "%s:%d: `%s' is not a valid COFF file.\n", inname, lineno, filename);
      return;
    }

  textbase = pc;
  emit(data + f_thdr->s_scnptr, f_thdr->s_size);
  database = pc;
  emit(data + f_dhdr->s_scnptr, f_dhdr->s_size);
  bssbase = pc;
  for (i = 0; i < f_bhdr->s_size; i++)
    emitb (0);

#ifdef DEBUG_RELOC
  printf (stderr,"textbase is at %04x\n", textbase);
  printf (stderr,"database is at %04x\n", database);
  printf (stderr,"bssbase  is at %04x\n", bssbase);
#endif

  symbol = (void *) data + header->f_symptr;
  base = (void *) symbol + header->f_nsyms * SYMESZ;
  coff_filename = strdup (filename);
  for (cnt = header->f_nsyms; cnt > 0; symbol++, cnt--)
    {
      if (symbol->e.e.e_zeroes == 0)
	p = base + symbol->e.e.e_offset;
      else
	strncpy (p = smallname, symbol->e.e_name, 8),
	p[8] = 0;

      switch (symbol->e_sclass)
	{
	case C_EXT:
	  switch (symbol->e_scnum)
	    {
	    case 1:
	      set_symbol (get_symbol (p, 1),
			  textbase + symbol->e_value)->type |= SYM_code;
	      break;
	    case 2:
	      set_symbol (get_symbol (p, 1),
			  textbase + symbol->e_value)->type |= SYM_data;
	      break;
	    case 3:
	      set_symbol (get_symbol (p, 1),
			  textbase + symbol->e_value)->type |= SYM_data;
	      break;
	    case N_UNDEF:
	      if (symbol->e_value == 0)
		/*0*/;  /* Nothing -- external reference.  */
	      else if (!get_symbol (p, 0))
		{
		  /* New common variable.  */
		  set_symbol (get_symbol (p, 1), pc)->type |= SYM_data;
		  for (i = 0; i < symbol->e_value; i++)
		    emitb (0);
		}
	      break;
	    }
	  break;
	}
      cnt -= symbol->e_numaux;
      symbol += symbol->e_numaux;
    }

  symbol = (void *) data + header->f_symptr;
  for (i = 0; i < 2; i++)
    {
      if (i == 0)
	rp = (RELOC *) (data + f_thdr->s_relptr),
	cnt = f_thdr->s_nreloc;
      else
	rp = (RELOC *) (data + f_dhdr->s_relptr),
	cnt = f_dhdr->s_nreloc;

      for (; cnt > 0; cnt--, rp++)
	{
	  Symbol *s=0;
	  unsigned char *vaddr_ptr=outbin + textbase + rp->r_vaddr;
	  int vaddr;
	  int delta;

	  vaddr=vaddr_ptr[0] | (vaddr_ptr[1] << 8) |
		(vaddr_ptr[2] << 16) | (vaddr_ptr[3] << 24);


	  if (symbol[rp->r_symndx].e.e.e_zeroes == 0)
	    p = base + symbol[rp->r_symndx].e.e.e_offset;
	  else
	    strncpy (p = smallname, symbol[rp->r_symndx].e.e_name, 8),
	    p[8] = 0;

#ifdef DEBUG_RELOC
	  s = get_symbol (p, 0);
	  printf ("ofs=%04x  typ=%02x  sec=%d"
		  "  val=%08x  data=%08x"
		  "  name=%s\n",
		  rp->r_vaddr + textbase,
		  rp->r_type,
		  symbol[rp->r_symndx].e_scnum,
		  s ? s->value : 0, 
		  vaddr,
		  p);
#endif
	  if (!strcmp (p, _TEXT))
	    delta = textbase;
	  else if (!strcmp (p, _DATA))
	    delta = textbase;
	  else if (!strcmp (p, _BSS))
	    delta = textbase;
	  else
	    {
	      s = get_symbol (p, 1);
	      if (!s->defined)
		{
		  Patch *pat = (Patch *) malloc (sizeof (Patch));

		  if (rp->r_type == RELOC_REL32)
		    fprintf (stderr,"%s:%d: warning:"
			     "Call from COFF file to (yet) undefined "
			     "destination, %s, is not supported.\n", inname, lineno, p);
		  pat->next = s->patches;
		  s->patches = pat;
		  pat->location = textbase + rp->r_vaddr;
		  pat->lineno = -1;
		  pat->filename = coff_filename;
		  pat->rel = REL_abs32;
		}
	    }

	  switch (rp->r_type)
	    {
	    case RELOC_ADDR32:
	      if (symbol[rp->r_symndx].e_scnum > 0)
		delta = textbase;
	      else
		delta = s->value - symbol[rp->r_symndx].e_value;
	      break;
	    case RELOC_REL32:
	      if (symbol[rp->r_symndx].e_scnum > 0)
		delta = 0;
	      else
		delta = s->value - textbase;
	      break;
	    default:
	      fprintf (stderr, "%s:%d:"
		       "COFF file %s contains bad relocation "
		       "entry type (0x%02x).\n",
		       inname, lineno, filename, rp->r_type);
	      delta = 0;
	    }
	  cp = (unsigned char *)(outbin + textbase + rp->r_vaddr);
	  vaddr += delta;
	  vaddr_ptr[0]=vaddr;
	  vaddr_ptr[1]=vaddr>>8;
	  vaddr_ptr[2]=vaddr>>16;
	  vaddr_ptr[3]=vaddr>>24;
	}
    }
}

int write_BYTE(unsigned char byte, FILE *outfile, unsigned char *checksum)
{
  fputc(byte,outfile);
  *checksum-=byte;
  return 1;
}

int write_WORD(unsigned short word, FILE *outfile, unsigned char *checksum)
{
  return write_BYTE(word&0xff,outfile,checksum) +
	 write_BYTE((word>>8)&0xff,outfile,checksum);
}

int write_STRING(char *str, FILE *outfile, unsigned char *checksum)
{
  int length=0;
  int len=strlen(str);

  if (len>254)
    len=254;
  length+=write_BYTE(len,outfile,checksum);
  while (len--)
    length+=write_BYTE(*str++,outfile,checksum);
  return length;
}

int write_INDEX(int index, FILE *outfile, unsigned char *checksum)
{
  if (index>127)
    return write_WORD(index+0x8000,outfile,checksum);
  else
    return write_BYTE(index,outfile,checksum);
}

void write_THEADR(FILE *outfile, char *inname)
{
  unsigned char checksum=0;
  off_t lptr,cptr;
  int length;

  write_BYTE(0x80,outfile,&checksum);
  /* reserve space for the length field */
  lptr=ftell(outfile);
  write_WORD(0,outfile,&checksum); /* does not change checksum */

  length=write_STRING(inname,outfile,&checksum);
  cptr=ftell(outfile);
  fseek(outfile,lptr,0/*SEEK_SET*/);
  write_WORD(length+1,outfile,&checksum); /* plus 1 for checksum */
  fseek(outfile,cptr,0/*SEEK_SET*/);
  write_BYTE(checksum,outfile,&checksum); /* sets checksum to 0 */
}

void write_LNAMES(FILE *outfile, ...)
{
  va_list names;
  int written=0;
  int length=0;
  off_t lenptr=0;
  unsigned char checksum=0;
  char *name;

  va_start(names,outfile);
  name=va_arg(names,char*);
  
  while (name)
    {
      int len=strlen(name);
      /* truncate names to 254 characters (omf limitation) */
      if (len>254)
	len=254;
      /* make sure the record doesn't overflow */
      if (length+len>1020)
	{
	  off_t cptr=ftell(outfile);
	  fseek(outfile,lenptr,SEEK_SET);
	  write_WORD(length+1,outfile,&checksum); /* plus 1 for checksum */
	  fseek(outfile,cptr,SEEK_SET);
	  write_BYTE(checksum,outfile,&checksum); /* sets checksum to 0 */
	  length=0;
	  written=0;
	}
      if (!written)
	{
	  written=1;
	  write_BYTE(0x96,outfile,&checksum);
	  /* reserve space for the length field */
	  lenptr=ftell(outfile);
	  write_WORD(0,outfile,&checksum); /* does not change checksum */
	}
      length+=write_STRING(name,outfile,&checksum);
      name=va_arg(names,char*);
    }
  if (written)
    {
      off_t cptr=ftell(outfile);
      fseek(outfile,lenptr,SEEK_SET);
      write_WORD(length+1,outfile,&checksum); /* plus 1 for checksum */
      fseek(outfile,cptr,SEEK_SET);
      write_BYTE(checksum,outfile,&checksum); /* sets checksum to 0 */
    }
}

void write_SEGDEF(FILE *outfile, int size, int name, int class, int overlay)
{
  unsigned char checksum=0;
  write_BYTE(0x98,outfile,&checksum);
  write_WORD(7+(name>127)+(class>127)+(overlay>127),outfile,&checksum);
  /* A=2 (word), C=2 (public), B=?, P=0 */
  write_BYTE(0x48|((size==0x1000)<<1),outfile,&checksum);
  write_WORD(size,outfile,&checksum);
  write_INDEX(name,outfile,&checksum);
  write_INDEX(class,outfile,&checksum);
  write_INDEX(overlay,outfile,&checksum);
  write_BYTE(checksum,outfile,&checksum); /* sets checksum to 0 */
}

void write_EXTDEF(FILE *outfile, Symbol *symtab)
{
  int written=0;
  int length=0;
  off_t lenptr=0;
  unsigned char checksum=0;
  Symbol *sym=symtab;

  while (sym)
    {
      if (sym->external)
        {
	  int len=strlen(sym->name);
	  /* truncate names to 254 characters (omf limitation) */
	  if (len>254)
	    len=254;
	  /* make sure the record doesn't overflow */
	  if (length+len>1020)
	    {
	      off_t cptr=ftell(outfile);
	      fseek(outfile,lenptr,SEEK_SET);
	      write_WORD(length+1,outfile,&checksum); /* plus 1 for checksum */
	      fseek(outfile,cptr,SEEK_SET);
	      write_BYTE(checksum,outfile,&checksum); /* sets checksum to 0 */
	      length=0;
	      written=0;
	    }
	  if (!written)
	    {
	      written=1;
	      write_BYTE(0x96,outfile,&checksum);
	      /* reserve space for the length field */
	      lenptr=ftell(outfile);
	      write_WORD(0,outfile,&checksum); /* does not change checksum */
	    }
	  length+=write_STRING(sym->name,outfile,&checksum);
	}
      sym=sym->next;
    }
  if (written)
    {
      off_t cptr=ftell(outfile);
      fseek(outfile,lenptr,SEEK_SET);
      write_WORD(length+1,outfile,&checksum); /* plus 1 for checksum */
      fseek(outfile,cptr,SEEK_SET);
      write_BYTE(checksum,outfile,&checksum); /* sets checksum to 0 */
    }
}

void write_PUBDEF(FILE *outfile, Symbol *symtab, int bss_start)
{
  int length=0;
  off_t lenptr=0,cptr;
  unsigned char checksum=0;
  Symbol *sym=symtab;

  while (sym)
    {
      if (sym->public && sym->defined) /* silently ignore undefined pubdefs */
        {
	  write_BYTE(0x96,outfile,&checksum);
	  /* reserve space for the length field */
	  lenptr=ftell(outfile);
	  write_WORD(0,outfile,&checksum); /* does not change checksum */

	  length+=write_INDEX(0,outfile,&checksum); /* group index */
	  if (sym->type&SYM_abs)
	    {
	      length+=write_INDEX(0,outfile,&checksum);
	      length+=write_WORD(0,outfile,&checksum);
	      length+=write_STRING(sym->name,outfile,&checksum);
	    }
	  else
	    {
	      if (sym->value>=bss_start)
		{
		  length+=write_INDEX(5,outfile,&checksum);
		  length+=write_STRING(sym->name,outfile,&checksum);
		  length+=write_WORD(sym->value-bss_start,outfile,&checksum);
		}
	      else
	        {
		  length+=write_INDEX(4,outfile,&checksum);
		  length+=write_STRING(sym->name,outfile,&checksum);
		  length+=write_WORD(sym->value,outfile,&checksum);
		}
	    }
	  write_INDEX(0,outfile,&checksum);

	  cptr=ftell(outfile);
	  fseek(outfile,lenptr,SEEK_SET);
	  write_WORD(length+1,outfile,&checksum); /* plus 1 for checksum */
	  fseek(outfile,cptr,SEEK_SET);
	  write_BYTE(checksum,outfile,&checksum); /* sets checksum to 0 */
	  length=0;
	}
      sym=sym->next;
    }
}

void write_LEDATA(FILE *outfile, int segment, unsigned char *outbin, int size,
		  Symbol *symtab)
{
  /* does not yet support relocations :( */
  int len;
  int maxlen=1020-(segment>127);
  int offset=0;
  int length=0;
  off_t lenptr,cptr;
  unsigned char checksum=0;

  while (size)
    {
      len=size;
      if (len>maxlen)
	len=maxlen;
      write_BYTE(0xa0,outfile,&checksum);
      /* reserve space for the length field */
      lenptr=ftell(outfile);
      write_WORD(0,outfile,&checksum); /* does not change checksum */

      length+=write_INDEX(segment,outfile,&checksum);
      length+=write_WORD(offset,outfile,&checksum);
      offset+=len;
      size-=len;
      while (len--)
        length+=write_BYTE(*outbin++,outfile,&checksum);
      cptr=ftell(outfile);
      fseek(outfile,lenptr,SEEK_SET);
      write_WORD(length+1,outfile,&checksum); /* plus 1 for checksum */
      fseek(outfile,cptr,SEEK_SET);
      write_BYTE(checksum,outfile,&checksum); /* sets checksum to 0 */
      length=0;
      /* !!! write out fixups (none generated yet as extern not yet implemented)
       * also need to make sure the last bytes of the ledata are not a partial
       * relocation site.
       */
    }
}

void write_MODEND(FILE *outfile, int main_obj, int start_ptr)
{
  unsigned char checksum=0;

  write_BYTE(0x8a,outfile,&checksum);
  if (main_obj)
    {
      write_WORD(6,outfile,&checksum); /* five bytes plus 1 for checksum */
      write_BYTE(0xc1,outfile,&checksum); /* main, start, fixup */
      /* the following is a FIXUPP record for the start address */
      write_BYTE(0x50,outfile,&checksum);
      write_INDEX(1,outfile,&checksum);
      write_WORD(start_ptr,outfile,&checksum);
    }
  else
    {
      write_WORD(2,outfile,&checksum); /* one byte plus 1 for checksum */
      write_BYTE(1,outfile,&checksum); /* fixup only (eh? why not 0?) */
    }
  write_BYTE(checksum,outfile,&checksum);
}
