/* Copyright (C) 1993 DJ Delorie, see COPYING.DJ for details */
extern int can_longjmp;
extern jmp_buf debugger_jmpbuf;
void debugger(void);
